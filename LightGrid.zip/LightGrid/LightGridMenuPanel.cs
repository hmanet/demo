﻿using System;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Threading;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridMenuPanel : System.Windows.Controls.Grid
    {
        public LightGridMenuPanel()
        {
            hideAction = Delayed.Delay(TimeSpan.FromMilliseconds(500)).Dispatcher(Dispatcher).Action(Hide);
        }
        private readonly DelayedAction hideAction;

        public LightGrid Owner { get; internal set; }

        internal Popup Popup { get; set; }


        public new GridViewModel DataContext { get { return (GridViewModel)base.DataContext; } set { base.DataContext = value; } }

        public void Show()
        {
            Popup.PlacementTarget = Owner.ColumnHeadersPanel;

            Popup.IsOpen = true;
            hideAction.Start();
        }
        public void Hide()
        {
            Popup.IsOpen = false;
            hideAction.Stop();
        }
    }
}
