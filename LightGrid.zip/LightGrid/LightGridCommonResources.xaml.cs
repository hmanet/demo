﻿using System;
using Wells.Derivatives.Carina.Core.Presentation.View.OptionSelector;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGridCommonResources
    {
        public static readonly LightGridCommonResources Instance = new LightGridCommonResources();

        public LightGridCommonResources()
        {
            MergedDictionaries.Add(MenuResources.Instance);

            InitializeComponent();
        }
    }
}
