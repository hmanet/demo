using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using Wells.Derivatives.Carina.Core.Interfaces;
using Wells.Derivatives.Carina.Core.Metadata;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Model.Tree.Spec;
using Wells.Derivatives.Carina.Core.Presentation.Events;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.RoutedCommands;
using Wells.Derivatives.Carina.Core.Threading;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class SelectableToGridBridge : IDisposable
    {
        public SelectableToGridBridge(GridViewModel grid, IComponentContext componentContext, ObservableCollection<CommandBinding> commandBindings)
        {
            this.grid = grid;
            this.componentContext = componentContext;
            raiseEvent = Delayed.Action(RaiseEventDelayed).Delay(TimeSpan.FromSeconds(0.5)).Dispatcher(grid.Dispatcher);

            commandBindings.Add(new CommandBinding(CarinaCommands.ExpandCollapse, ExpandCollapse_Executed, ExpandCollapse_CanExecute));
            commandBindings.Add(new CommandBinding(CarinaCommands.Select, Select_Executed, Select_CanExecute));

            viewSpecChangedObservable = new SimpleObservable(new Binding("Spec.ViewSpec") { Source = this.grid, Mode = BindingMode.OneWay }, (d, e) => ViewSpec = e.NewValue as ViewSpec);
            ViewSpec = grid.Spec.ViewSpec;

            enableGrandTotalChangedObservable = new SimpleObservable(new Binding("Spec.EnableGrandTotal") { Source = this.grid, Mode = BindingMode.OneWay }, (d, e) => EnableGrandTotal = (bool)e.NewValue);
            EnableGrandTotal = grid.Spec.EnableGrandTotal;

            selectionChangedObservable = new SimpleObservable(new Binding("Spec.SelectionUnit") { Source = this.grid, Mode = BindingMode.OneWay }, (d, e) => SelectionUnit = (SelectionUnits?)e.NewValue ?? SelectionUnits.Full);
            SelectionUnit = grid.Spec.SelectionUnit;

            grandTotalFormatChangedObservable = new SimpleObservable(new Binding("GrandTotalFormat") { Source = this.grid.Spec, Mode = BindingMode.OneWay }, (d, e) => RaiseEvent());
            summaryRowFormatChangedObservable = new SimpleObservable(new Binding("SummaryRowFormat") { Source = this.grid.Spec, Mode = BindingMode.OneWay }, (d, e) => RaiseEvent());
            RaiseEvent();
        }

        private readonly SimpleObservable viewSpecChangedObservable;
        private readonly SimpleObservable enableGrandTotalChangedObservable;
        private readonly SimpleObservable selectionChangedObservable;
        private readonly SimpleObservable grandTotalFormatChangedObservable;
        private readonly SimpleObservable summaryRowFormatChangedObservable;
        private readonly IComponentContext componentContext;

        private readonly GridViewModel grid;
        private void ExpandCollapse_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void ExpandCollapse_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var args = (Dictionary<string, object>) e.Parameter;

            object buffer;
            if (args.TryGetValue("Action", out buffer))
            {
                var action = (string) buffer;
                switch (action)
                {
                    case "ShowLevel": ShowLevel(args); break;
                    case "ExpandAll": ExpandAll(args); break;
                    case "ExpandChildren": ExpandChildren(args); break;
                    case "CollapseAll": CollapseAll(args); break;
                    case "CollapseParent": CollapseParent(args); break;
                }
            }
        }
        private void ShowLevel(Dictionary<string, object> args)
        {
            object buffer;
            if (args.TryGetValue("VisibleLevel", out buffer))
            {
                var expandLevel = ((int)buffer) - 2;
                var collapseLevel = ((int)buffer) - 1;

                var levelsToExpand = expandLevel >= 0 && expandLevel < grid.Tree.ViewSpec.GroupingAttributes.Length ?
                    new[] { grid.Tree.ViewSpec.GroupingAttributes[expandLevel] } : new IAttributeDefinition[0];
                var levelsToCollapse = collapseLevel >= 0 && collapseLevel < grid.Tree.ViewSpec.GroupingAttributes.Length ?
                    grid.Tree.ViewSpec.GroupingAttributes.Where((a, i) => i >= collapseLevel).ToArray() : new IAttributeDefinition[0];

                grid.Tree.Builder.ExpandCollapse(levelsToExpand, levelsToCollapse);
            }
        }
        private void ExpandAll(Dictionary<string, object> args)
        {
            var levelsToExpand = new List<IAttributeDefinition>();

            object buffer;
            if (args.TryGetValue("Levels", out buffer))
            {
                var attributes = (string[])buffer;
                if (attributes != null)
                {
                    var groups = GetGroups();
                    levelsToExpand.AddRange(from attribute in attributes let found = groups.FirstOrDefault(a => a.Key.Name == attribute) where found != null || attribute == null select found);
                }

                grid.Tree.Builder.ExpandCollapse(levelsToExpand.ToArray(), new IAttributeDefinition[0]);
            }
        }
        private void ExpandChildren(Dictionary<string, object> args)
        {
            grid.Tree.Builder.ExpandChildren();
        }
        private void CollapseAll(Dictionary<string, object> args)
        {
            var levelsToCollapse = new List<IAttributeDefinition>();

            object buffer;
            if (args.TryGetValue("Levels", out buffer))
            {
                var attributes = (string[])buffer;
                if (attributes != null)
                {
                    var groups = GetGroups();
                    levelsToCollapse.AddRange(from attribute in attributes let found = groups.FirstOrDefault(a => a.Key.Name == attribute) where found != null || attribute == null select found);
                }

                grid.Tree.Builder.ExpandCollapse(new IAttributeDefinition[0], levelsToCollapse.ToArray());
            }
        }
        private void CollapseParent(Dictionary<string, object> args)
        {
            grid.Tree.Builder.CollapseParent();
        }

        private void Select_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void Select_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var args = (Dictionary<string, object>)e.Parameter;

            object buffer;
            if (args.TryGetValue("Action", out buffer))
            {
                var action = (string)buffer;
                switch (action)
                {
                    case "SelectAll": SelectAll(args); break;
                    case "SelectRows": SelectRows(args); break;
                    case "SelectCells": SelectCells(args); break;
                    case "GrandTotal": GrandTotal(args); break;
                    case "Compact": CompactGroup(); break;
                    case "FullSize": FullSizeGroup(); break;
                    case "GrandTotalFormatParam": FormatGrandTotal(args); break;
                    case "SummaryRowFormatParam": FormatSummaryRow(args); break;
                }
            }
        }

        private void CompactGroup()
        {
            grid.Spec.GroupingMode = GridSpec.GroupingModes.Compact;
        }

        private void FullSizeGroup()
        {
            grid.Spec.GroupingMode = GridSpec.GroupingModes.Full;
        }

        private void SelectAll(Dictionary<string, object> args)
        {
            var levelsToSelect = new List<IAttributeDefinition>();

            object buffer;
            if (args.TryGetValue("Levels", out buffer))
            {
                var attributes = (string[])buffer;
                if (attributes != null)
                {
                    var groups = GetGroups();
                    levelsToSelect.AddRange(from attribute in attributes let found = groups.FirstOrDefault(a => a.Key.Name == attribute) where found != null || attribute == null select found);
                }

                grid.SelectAll(levelsToSelect.ToArray());
            }
        }
        private void SelectRows(Dictionary<string, object> args)
        {
            selectionUnit = SelectionUnits.Full;
            grid.RowSelectableCommand.Execute();
        }
        private void SelectCells(Dictionary<string, object> args)
        {
            selectionUnit = SelectionUnits.Cell;
            grid.CellSelectableCommand.Execute();
        }
        private void GrandTotal(Dictionary<string, object> args)
        {
            var position = (TotalsPositions)args["Position"];
            var fixe = (bool)args["Fixed"];
            if (grid.Spec.GrandTotalPosition != position || grid.Spec.FixedGrandTotal != fixe)
            {
                grid.Spec.FixedGrandTotal = fixe;
                grid.Spec.GrandTotalPosition = position;
            }
        }

        private void FormatGrandTotal(Dictionary<string, object> args)
        {
            object buffer;
            if (args.TryGetValue("Format", out buffer)) grid.Spec.GrandTotalFormat = Merge(grid.Spec.GrandTotalFormat, (SelectableChangedArgs.Format)buffer);
        }
        private void FormatSummaryRow(Dictionary<string, object> args)
        {
            object buffer;
            if (args.TryGetValue("Format", out buffer)) grid.Spec.SummaryRowFormat = Merge(grid.Spec.SummaryRowFormat, (SelectableChangedArgs.Format)buffer);
        }
        private TriggerStyle Merge(TriggerStyle style, SelectableChangedArgs.Format format)
        {
            var fontWeight = format.Bold != null && format.Bold.Value ? FontWeights.Bold : (FontWeight?)null;
            var fontStyle = format.Italic != null && format.Italic.Value ? FontStyles.Italic : (FontStyle?)null;
            var underline = format.Underline != null && format.Underline.Value ? true : (bool?)null;
            var strikethrough = format.Strikethrough != null && format.Strikethrough.Value ? true : (bool?)null;

            return new TriggerStyle(style.Editable, style.Foreground, style.Background, style.FontFamily, fontWeight, fontStyle, style.FontSize, style.Delay, style.Visible, strikethrough, underline, rowBorder: style.RowBorder, cellBorder: style.CellBorder);
        }

        public SelectionUnits SelectionUnit
        {
            get { return selectionUnit; }
            set
            {
                if (selectionUnit == value) return;
                selectionUnit = value;
                RaiseEvent();
            }
        }
        private SelectionUnits selectionUnit;

        public ViewSpec ViewSpec
        {
            get { return viewSpec; }
            set
            {
                if(viewSpec == value) return;
                viewSpec = value;
                RaiseEvent();
            }
        }
        private ViewSpec viewSpec;

        public bool EnableGrandTotal
        {
            get { return enableGrandTotal; }
            set
            {
                if(enableGrandTotal == value) return;
                enableGrandTotal = value;

                RaiseEvent();
            }
        }
        private bool enableGrandTotal;


        private List<IAttributeDefinition> GetGroups()
        {
            var groups = new List<IAttributeDefinition>();
            groups.Add(TreeBuilderModel.GrandTotalAttribute);
            groups.AddRange(grid.Tree.ViewSpec.GroupingAttributes);
            groups.Add(TreeBuilderModel.LeavesAttribute);

            return groups;
        }

        private void RaiseEvent()
        {
            raiseEvent.Execute();
        }
        private void RaiseEventDelayed()
        {
            if(disposed) return;

            IEnumerable<SelectableChangedArgs.Group> groups = new []
            {
                new SelectableChangedArgs.Group { Name = TreeBuilderModel.GrandTotalAttribute.Key.Name, Label = TreeBuilderModel.GrandTotalAttribute.Label }
            };

            var enableGrandTotal = false;
            var fixedGrandTotal = false;
            var enableExcelExport = false;
            var grandTotalPosition = TotalsPositions.Undefined;
            if (ViewSpec != null)
            {
                groups = groups.Concat(ViewSpec.GroupingAttributes.Select(a => new SelectableChangedArgs.Group { Name = a.Key.Name, Label = a.Label }));

                enableGrandTotal = ViewSpec.EnableGrandTotal;
                fixedGrandTotal = ViewSpec.FixedGrandTotal;
                grandTotalPosition = ViewSpec.GrandTotalPosition;
                enableExcelExport = true;
            }

            groups = groups.Concat(new [] { new SelectableChangedArgs.Group { Name = TreeBuilderModel.LeavesAttribute.Key.Name, Label = TreeBuilderModel.LeavesAttribute.Label } });

            var grandTotalFormat = grid.Spec.GrandTotalFormat;
            var summaryRowFormat = grid.Spec.SummaryRowFormat;
            var args = new SelectableChangedArgs(groups.ToArray(), SelectionUnit, enableGrandTotal, fixedGrandTotal, grandTotalPosition, enableExcelExport)
            {
                GrandTotalFormat = new SelectableChangedArgs.Format
                {
                    Bold = grandTotalFormat.FontWeight == null ? (bool?)null : grandTotalFormat.FontWeight == FontWeights.Bold,
                    Italic = grandTotalFormat.FontStyle == null ? (bool?)null : grandTotalFormat.FontStyle == FontStyles.Italic,
                    Underline = grandTotalFormat.Underline,
                    Strikethrough = grandTotalFormat.Strikethrough,
                },

                SummaryRowFormat = new SelectableChangedArgs.Format
                {
                    Bold = summaryRowFormat.FontWeight == null ? (bool?)null : summaryRowFormat.FontWeight == FontWeights.Bold,
                    Italic = summaryRowFormat.FontStyle == null ? (bool?)null : summaryRowFormat.FontStyle == FontStyles.Italic,
                    Underline = summaryRowFormat.Underline,
                    Strikethrough = summaryRowFormat.Strikethrough,
                }
            };

            var action = componentContext.RaiseEvent;
            if(action != null) action(new Event<SelectableChangedArgs>(null, args));
        }
        private readonly DelayedAction raiseEvent;

        public void Dispose()
        {
            ViewSpec = null;

            disposed = true;
        }
        private bool disposed;
    }
}
