﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Wells.Derivatives.Carina.Core.Codegen;
using Wells.Derivatives.Carina.Core.Interfaces;
using Wells.Derivatives.Carina.Core.Metadata;
using Wells.Derivatives.Carina.Core.Observable;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Formatting;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Query;
using Wells.Derivatives.Carina.Core.Query.Predicates;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGridFilterCell : Control
    {
        static LightGridFilterCell()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridFilterCell), new FrameworkPropertyMetadata(null, (d, v) => d));
        }
        public LightGridFilterCell(LightGrid owner)
        {
            Owner = owner;

            Resources.MergedDictionaries.Add(LightGridFilterCellResources.Instance);

            Template = LightGridFilterCellResources.Instance.Template;
            Style = LightGridFilterCellResources.Instance.Style;

            ApplyTemplate();

            border = (Border)Template.FindName("border", this);
            filterClearButton = (Button)Template.FindName("filterClearButton", this);
            filterTextBox = (LightGridFilterTextBox)Template.FindName("filterTextBox", this);
            filterCheckBox = (LightGridFilterCheckBox)Template.FindName("filterCheckBox", this);
            filterComboBox = (LightGridFilterComboBox)Template.FindName("filterComboBox", this);

            filterTextBox.Visibility = Visibility.Hidden;
            filterCheckBox.Visibility = Visibility.Hidden;
            filterComboBox.Visibility = Visibility.Hidden;

            Owner.FiltersPanel.Children.Add(this);

            Padding = new Thickness();
            Focusable = false;

            DataContext = this;
            ContextMenu = Owner.ContextMenu;

            filterClearButton.Click += filterClearButton_Click;
        }
        private readonly Border border;
        private readonly Button filterClearButton;
        private readonly LightGridFilterTextBox filterTextBox;
        private readonly LightGridFilterCheckBox filterCheckBox;
        private readonly LightGridFilterComboBox filterComboBox;
        public LightGrid Owner { get; private set; }

        public ColumnSpec Spec { get { return spec; } internal set { if(spec == value) return; var oldValue = spec; spec = value; OnSpecChanged(oldValue, spec); } } private ColumnSpec spec;
        private void OnSpecChanged(ColumnSpec oldValue, ColumnSpec newValue)
        {
            if (oldValue != null) oldValue.PropertyChanged -= Spec_PropertyChanged;

            if (newValue != null) newValue.PropertyChanged += Spec_PropertyChanged;

            Visibility = newValue != null ? Visibility.Visible : Visibility.Hidden;

            CalculateDependencies();
        }
        private void Spec_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            CalculateDependencies();
        }

        public GridViewModel Grid
        {
            get { return grid; }
            internal set
            {
                if (grid != null)
                {
                    grid.PropertyChanged -= Grid_PropertyChanged;
                    grid.PostFilterManager.Handler(() => grid.PostFilterManager.PostFilter).Changed -= Grid_PostFilterChanged;
                }

                grid = value;

                if (grid != null)
                {
                    grid.PropertyChanged += Grid_PropertyChanged;
                    grid.PostFilterManager.Handler(() => grid.PostFilterManager.PostFilter).Changed += Grid_PostFilterChanged;
                }

                if(grid != null)
                {
                    CalculateDependencies();
                }
            }
        }
        private GridViewModel grid;
        private void Grid_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if(e.PropertyName == "PostFilterManager") CalculateDependencies();
            else if(e.PropertyName == "LockedViewportSize") CalculateLastLockedSplitterLeft();
        }
        private void Grid_PostFilterChanged(IChangeArgs<IPredicate<AttributeKey, object>> args)
        {
            CalculateDependencies();
        }


        public int ZIndex { get { return zIndex; } set { if(zIndex == value) return; zIndex = value; Canvas.SetZIndex(this, value); } } private int zIndex;

        public double Left { get { return left; } set { if(left == value) return; left = value; OnLeftChanged(); Canvas.SetLeft(this, value); } } private double left;
        private void OnLeftChanged()
        {
            CalculateLastLockedSplitterLeft();
        }
        private void CalculateLastLockedSplitterLeft()
        {
            var lastLocked = Owner.DataContext.LockedColumns.LastOrDefault();
            if (lastLocked != null && Spec != lastLocked) return;

            Owner.FiltersPanel.Splitter.Left = Owner.DataContext.LockedViewportSize;
        }

        public new double Width { get { return width; } set { if(width == value) return; width = value; base.Width = value; } } private double width;


        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseDown(e);

            Owner.GridPanel.BeginSelection(this, e.OriginalSource, e.ChangedButton, PointToScreen(e.GetPosition(this)));
        }
        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseUp(e);

            Owner.GridPanel.EndSelection(this, e.OriginalSource, e.ChangedButton, PointToScreen(e.GetPosition(this)));
        }

        protected override void OnPreviewMouseWheel(MouseWheelEventArgs e)
        {
            base.OnPreviewMouseWheel(e);

            if(e.Delta == 0) return;

            var delta = -(e.Delta / Math.Abs(e.Delta));

            if (Keyboard.Modifiers == ModifierKeys.Alt)
            {
                Owner.DataContext.ViewportOffset += 50 * delta;
            }
        }

        protected override void OnPreviewGotKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            base.OnPreviewGotKeyboardFocus(e);

            Grid.ActiveFilterSpec = Spec;
        }

        private void filterClearButton_Click(object sender, RoutedEventArgs e)
        {
            Grid.PostFilterManager.ClearFilter(Spec);

            filterTextBox.Focus();
        }

        private void CalculateDependencies()
        {
            filterTextBox.Visibility = Visibility.Hidden;
            filterCheckBox.Visibility = Visibility.Hidden;
            filterComboBox.Visibility = Visibility.Hidden;

            if (Spec == null || Grid == null)
            {
                filterTextBox.Text = null;
                filterTextBox.Spec = null;

                filterCheckBox.IsChecked = null;
                filterCheckBox.Spec = null;

                filterComboBox.SelectedItem = null;
                filterComboBox.Spec = null;

                return;
            }

            if(filterComboBox_CalculateVisible())
            {
                filterTextBox.Text = null;
                filterTextBox.Spec = null;

                filterCheckBox.IsChecked = null;
                filterCheckBox.Spec = null;

                filterComboBox.Spec = Spec;
                filterComboBox.Visibility = Visibility.Visible;
            }
            else if(filterCheckBox_CalculateVisible())
            {
                filterTextBox.Text = null;
                filterTextBox.Spec = null;

                filterCheckBox.Spec = Spec;
                filterCheckBox.Visibility = Visibility.Visible;

                filterComboBox.SelectedItem = null;
                filterComboBox.Spec = null;
            }
            else
            {
                filterTextBox.Spec = Spec;
                filterTextBox.Visibility = Visibility.Visible;

                filterCheckBox.IsChecked = null;
                filterCheckBox.Spec = null;

                filterComboBox.SelectedItem = null;
                filterComboBox.Spec = null;
            }

            if(Grid.Spec.GroupingModeColumns.Grouped(Spec)) ZIndex = GridViewModel.LockedCellZIndex;
            else if(Spec.Locked) ZIndex = GridViewModel.LockedCellZIndex;
            else ZIndex = GridViewModel.CellZIndex;

            Left = Spec.Left;
            Width = Spec.Width;
            Height = Grid.RowHeight;
            filterTextBox.Height = Height;
            filterCheckBox.Height = Height;
            filterComboBox.Height = Height;

            ToolTip = Spec.FilterDescription;

            border_Background = Grid.PostFilterManager.PostFilter == BooleanPredicate.True ? LightGridResources.Instance.FilterNotPresentBackground : LightGridResources.Instance.FilterPresentBackground;
            clearFilterButton_Visibility = Checks.IsNullOrWhiteSpace(Spec.FilterValue) == false ? Visibility.Visible : Visibility.Collapsed;
        }

        private bool filterComboBox_CalculateVisible()
        {
            if (Spec == null) return false;

            if (Spec.DataType.IsBoolean() == false && Spec.DataType.IsEnum() == false)
                return false;

            var typeDescriptor = Spec.TypeDescriptor;
            if (typeDescriptor == NullTypeDescriptor.Instance)
                return false;

            if(Spec.DataType.IsEnum == false)
            {
                var boolDescriptor = typeDescriptor as BoolTypeDescriptor;
                if (boolDescriptor == null || boolDescriptor.IsDefault)
                    return false;
            }

            return Spec.ExpressionMode == ExpressionModes.Undefined;
        }
        private bool filterCheckBox_CalculateVisible()
        {
            if (Spec == null) return false;

            if (Spec.DataType != typeof(bool) && Spec.DataType != typeof(bool?))
                return false;

            var typeDescriptor = Spec.TypeDescriptor;
            if (typeDescriptor == NullTypeDescriptor.Instance)
                return false;

            return Spec.ExpressionMode != Codegen.ExpressionModes.Expression;
        }


        private Brush border_Background { get { return border_background; } set { if(border_background == value) return; border_background = value; border.Background = border_background; } } private Brush border_background;
        private Visibility clearFilterButton_Visibility { get { return clearFilterButton_visibility; } set { if(clearFilterButton_visibility == value) return; clearFilterButton_visibility = value; filterClearButton.Visibility = clearFilterButton_visibility; } } private Visibility clearFilterButton_visibility;


        #region nested classes

        protected override System.Windows.Automation.Peers.AutomationPeer OnCreateAutomationPeer()
        {
            return new AutomationPeer(this);
        }
        private class AutomationPeer : System.Windows.Automation.Peers.FrameworkElementAutomationPeer
        {
            public AutomationPeer(LightGridFilterCell owner) : base(owner)
            {
            }

            public new LightGridFilterCell Owner { get { return (LightGridFilterCell)base.Owner; } }

            protected override string GetClassNameCore()
            {
                return typeof(LightGridFilterCell).Name;
            }
            protected override System.Windows.Automation.Peers.AutomationControlType GetAutomationControlTypeCore()
            {
                return System.Windows.Automation.Peers.AutomationControlType.DataItem;
            }
            protected override string GetAutomationIdCore()
            {
                var spec = Owner.Spec;

                return spec == null ? "FilterCell_" : "FilterCell_" + spec.Name;
            }
        }

        #endregion
    }
}
