using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Formatting;
using Wells.Derivatives.Carina.Core.Threading;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class GlobalFormatToGridBridge : IDisposable
    {
        public GlobalFormatToGridBridge(LightGridPanel gridPanel)
        {
            this.gridPanel = gridPanel;
            gridPanel.AddHandler(Utilities.Events.FormatChangingEvent, (Utilities.Events.FormatChangingEventHandler)grid_FormatChanging, true);

            specChangedObservable = new SimpleObservable(new Binding("DataContext.Spec") { Source = this.gridPanel, Mode = BindingMode.OneWay }, (d, e) => Spec = (GridSpec)e.NewValue);

            raiseEvent = Delayed.Action(OnRaiseEvent).Delay(TimeSpan.FromMilliseconds(500)).Dispatcher(gridPanel.Dispatcher);
        }
        private readonly SimpleObservable specChangedObservable;


        private readonly LightGridPanel gridPanel;
        private void grid_FormatChanging(object sender, Utilities.Events.FormatEventArgs args)
        {
            if (args.Formattable == null) return;

            gridPanel.Dispatcher.BeginInvoke(()=>
            {
                isFromHost = args.Formattable.ContainsKey(FormatHelper.IS_FROM_HOST);

                var selected = Spec.SelectedColumns.ToArray();
                if (selected.Length == 0) return;

                if (args.Formattable.ContainsKey(FormatHelper.CLEAR_FORMATS))
                {
                    foreach (var next in selected) MappingHelper.MapToDefault(Spec, next);
                }
                else
                {
                    selected.UpdateFromDictionary(args.Formattable);
                }
            }, DispatcherPriority.Send);
        }
        private bool isFromHost;


        public GridSpec Spec
        {
            get { return spec; }
            set
            {
                if(spec == value) return;

                if (spec != null)
                {
                    spec.ColumnPropertyChanged -= Spec_ColumnPropertyChanged;
                    spec.Columns.CollectionChanged -= Spec_Columns_CollectionChanged;
                }

                spec = value;

                if (spec != null)
                {
                    spec.ColumnPropertyChanged += Spec_ColumnPropertyChanged;
                    spec.Columns.CollectionChanged += Spec_Columns_CollectionChanged;
                }
            }
        }
        private GridSpec spec;
        private void Spec_ColumnPropertyChanged(object o, PropertyChangedEventArgs propertyChangedEventArgs)
        {
            switch(propertyChangedEventArgs.PropertyName)
            {
                case "Selected"://Select property change can never be initiated from Host
                    raiseEvent.Execute(); break;
                case "Visible":
                case "HorizontalAlignment":
                case "Foreground":
                case "Background":
                case "FontFamily":
                case "FontWeight":
                case "FontStyle":
                case "FontSize":
                case "Scaling":
                case "DecimalPlaces":
                case "ExponentialNotationSelected":
                case "UseSeparator":
                case "Format":
                case "NumericFormat":
                case "TypeDescriptor":
                case "Underline":
                case "Strikethrough":
                    if (!isFromHost) raiseEvent.Execute();
                    break;
            }

            if (isFromHost) isFromHost = false;
        }
        private void Spec_Columns_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            raiseEvent.Execute();
        }


        private void OnRaiseEvent()
        {
            if(Spec == null) return;

            var formattable = new Dictionary<string, object>();

            var selected = Spec.SelectedColumns.ToArray();
            if (selected.Length > 0)
            {
                formattable.UpdateFromColumnSpecList(selected);
            }

            gridPanel.RaiseEvent(new Utilities.Events.FormatEventArgs
            {
                Formattable = formattable.Count > 0 ? formattable : null,
                RoutedEvent = Utilities.Events.FormatChangedEvent,
                Source = gridPanel,
            });
        }
        private readonly DelayedAction raiseEvent;


        public void Dispose()
        {
            Spec = null;
        }
    }
}
