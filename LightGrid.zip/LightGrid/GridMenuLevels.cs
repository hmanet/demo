﻿namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public static class GridMenuLevels
    {
        public const uint None = 0;
        public const uint Cell = 1;
        public const uint Column = 2;
        public const uint Row = 4;
        public const uint Grid = 8;
        public const uint Filter = 16;
        public const uint ToolBar = 32;
        public const uint Default = Column | Row | Grid;
        public const uint All = Cell | Column | Row | Grid | Filter;
    }
}
