using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Query.Predicates;
using Wells.Derivatives.Carina.Core.Threading;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridFilterTextBox : TextBox
    {
        static LightGridFilterTextBox()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridFilterTextBox), new FrameworkPropertyMetadata((d, a) => ((LightGridFilterTextBox)d).OnDataContextChanged((LightGridFilterCell)a.OldValue, (LightGridFilterCell)a.NewValue), (d, v) => v as LightGridFilterCell));
        }
        public LightGridFilterTextBox()
        {
            Margin = new Thickness();
            Padding = new Thickness();
            BorderThickness = new Thickness();
            Background = Brushes.Transparent;

            delayedApply = Delayed.Delay(TimeSpan.FromMilliseconds(300)).Dispatcher(Dispatcher);
        }
        private readonly DelayedAction delayedApply;

        public new LightGridFilterCell DataContext { get { return dataContext; } set { base.DataContext = value; } } private LightGridFilterCell dataContext;
        private void OnDataContextChanged(LightGridFilterCell oldValue, LightGridFilterCell newValue)
        {
            if(oldValue != null)
            {
                ContextMenu = null;
                Spec = null;
            }

            dataContext = newValue;

            if(newValue != null)
            {
                ContextMenu = newValue.ContextMenu;
                Spec = DataContext.Spec;
            }
        }

        public ColumnSpec Spec { get { return spec; } internal set { if(spec == value) return; var oldValue = spec; spec = value; OnSpecChanged(oldValue, spec); } } private ColumnSpec spec;
        private void OnSpecChanged(ColumnSpec oldValue, ColumnSpec newValue)
        {
            if (oldValue != null) oldValue.PropertyChanged -= Spec_PropertyChanged;

            if (newValue != null) newValue.PropertyChanged += Spec_PropertyChanged;

            if(newValue == null || (newValue.DataType == typeof(bool) || newValue.DataType == typeof(bool?) || newValue.DataType.IsEnum))
            {
                Visibility = Visibility.Hidden;
            }
            else
            {
                Visibility = Visibility.Visible;

                CalculateDependencies();
            }
        }
        private void Spec_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if(Spec == null) return;

            CalculateDependencies();
        }

        private void CalculateDependencies()
        {
            var filterValue = Spec.FilterValue == null ? string.Empty : Spec.FilterValue.ToString();

            Text = filterValue;

            Foreground = Spec.Filter == BooleanPredicate.True ? Brushes.Red : Brushes.Black;
        }


        protected override void OnTextChanged(TextChangedEventArgs e)
        {
            base.OnTextChanged(e);

            var text = Text;
            var spec = Spec;
            var grid = DataContext.Grid;

            if (grid == null) return;

            delayedApply.Action(() =>
            {
                if(spec != Spec) return;

                spec.FilterValue = text;
                grid.PostFilterManager.UpdateFilter(spec);
            }).Execute();
        }
    }
}
