﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid.Editor;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridRow : Control
    {
        public LightGridRow(LightGridPanel gridPanel)
        {
            GridPanel = gridPanel;

            foreach (var next in GridPanel.Columns)
            {
                var cell = new LightGridCell(gridPanel) { Row = this, TreeNode = TreeNode, Column = next, Spec = next.Spec };
                Cells.Add(cell);
                next.Cells.Add(cell);
            }
        }

        public LightGrid Owner { get { return GridPanel.Owner; } }
        public LightGridPanel GridPanel { get; private set; }

        internal readonly List<LightGridCell> Cells = new List<LightGridCell>();


        public GridViewModel Grid
        {
            get { return grid; }
            internal set
            {
                if(grid == value) return;

                if (grid != null) grid.PropertyChanged -= grid_PropertyChanged;

                grid = value;

                if (grid != null) grid.PropertyChanged += grid_PropertyChanged;
            }
        }
        private GridViewModel grid;
        private void grid_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case "RowBackground": foreach(var next in Cells) next.Model.CalculateBackground(); break;
                case "RowForeground": foreach(var next in Cells) next.Model.CalculateForeground(); break;
                case "ShowAlternatingRowColor": foreach(var next in Cells) next.Model.CalculateBackground(); break;
                case "AlternatingRowBackground": foreach(var next in Cells) next.Model.CalculateBackground(); break;
                case "AlternatingRowForeground": foreach(var next in Cells) next.Model.CalculateForeground(); break;
                case "SelectionBackground": foreach(var next in Cells) next.Model.CalculateBackground(); break;
                case "SelectionForeground": foreach(var next in Cells) next.Model.CalculateForeground(); break;
                case "GrandTotalRowBackground": foreach(var next in Cells) next.Model.CalculateBackground(); break;
                case "GrandTotalRowForeground": foreach(var next in Cells) next.Model.CalculateForeground(); break;
                case "SplitFilterRowBackground": foreach(var next in Cells) next.Model.CalculateBackground(); break;
                case "SplitFilterRowForeground": foreach(var next in Cells) next.Model.CalculateForeground(); break;

                //properties that should simply trigger refresh
                case "EditIndicator": break;
                case "SelectionMode": break;
                case "RowHeight": break;
                case "EnableSpinners": break;
                case "SpinnersLocation": break;

                //properties that don't affect refresh
                case "ActiveCell": return;
            }

            RefreshCellsDeferred();
        }

        public TreeNodeViewModel TreeNode
        {
            get { return treeNode; }
            set
            {
                if (treeNode == value) return;

                if (treeNode != null)
                {
                    treeNode.Changed -= TreeNode_Changed;
                }

                treeNode = value;

                if (treeNode != null)
                {
                    treeNode.Changed += TreeNode_Changed;
                }

                if (previousTreeNode == null) previousTreeNode = value.Model;

                foreach (var next in Cells) next.TreeNode = treeNode;
            }
        }
        private TreeNodeViewModel treeNode;
        private TreeNodeModel previousTreeNode;
        private void TreeNode_Changed(TreeNodeModel oldNode, TreeNodeModel newNode)
        {
            previousTreeNode = oldNode;

            if (GridPanel.CellEditMode == false) return;
            if (TreeNodeModel.IdEquals(newNode, oldNode)) return;
            if (TreeNodeModel.IdEquals(GridPanel.CellEditorViewModel.Model, oldNode) == false) return;

            GridPanel.EndEdit(false);
        }

        internal void RefreshAfterScroll()
        {
            if (treeNode == null) return;

            var triggers = GridPanel.DataContext.Triggers;

            foreach (var next in Cells)
            {
                if (next.Spec == null) continue;

                var attributeKey = next.Spec.Metadata.Key;
                if (attributeKey.Name.Contains("_group_") && treeNode.PivotAttribute != null)
                {
                    attributeKey = treeNode.PivotAttribute.Key;
                }

                next.Model.TriggerStyle = triggers.Evaluate(Owner.DataContext.Tree.Model, treeNode.Model, treeNode.Model, attributeKey, next.Spec);
            }

            RefreshCells();
        }

        internal void ProcessTriggersAndRefreshCells()
        {
            if(TreeNode == null) return;

            if (Cells.Count > 0)
            {
                Width = 0D;
                Height = Owner.DataContext.RowHeight;
                foreach (var c in Cells) Width += c.Width;
            }

            ProcessTriggers();
            RefreshCells();
        }
        internal void ProcessTriggers()
        {
            if (treeNode == null) return;

            var triggers = GridPanel.DataContext.Triggers;

            if(TreeNodeModel.IdEquals(previousTreeNode, treeNode.Model) == false)
            {
                for (var i = 0; i < Cells.Count; i++)
                {
                    var next = Cells[i];
                    if (next.Spec == null) continue;

                    var attributeKey = next.Spec.Metadata.Key;
                    if (attributeKey.Name.Contains("_group_") && treeNode.PivotAttribute != null)
                        attributeKey = treeNode.PivotAttribute.Key;

                    next.Model.TriggerStyle = triggers.Evaluate(Owner.DataContext.Tree.Model, treeNode.Model, treeNode.Model, attributeKey, next.Spec);
                }
                return;
            }

            for (var i = 0; i < Cells.Count; i++)
            {
                var next = Cells[i];
                if (next.Spec == null) continue;

                var attributeKey = next.Spec.Metadata.Key;
                if (attributeKey.Name.Contains("_group_") && treeNode.PivotAttribute != null)
                    attributeKey = treeNode.PivotAttribute.Key;

                var newStyle = triggers.Evaluate(Owner.DataContext.Tree.Model, previousTreeNode, treeNode.Model, attributeKey, next.Spec);
                if (next.Model.TriggerEndTime != default(DateTime) && Owner.Timer.Enabled(next.Model.TriggerEndTime))
                {
                    if (newStyle.Delay == null) continue;

                    Owner.Timer.Stop(next.Model.TriggerEndTime);
                }

                next.Model.TriggerStyle = newStyle;
                if (next.Model.TriggerStyle.Delay != null)
                {
                    next.Model.TriggerEndTime = Owner.Timer.Start((TimeSpan) next.Model.TriggerStyle.Delay, () =>
                    {
                        if (TreeNodeViewModel.IdEquals(previousTreeNode, treeNode) == false || next.Spec == null) return;

                        next.Model.TriggerStyle = triggers.Evaluate(Owner.DataContext.Tree.Model, treeNode.Model, treeNode.Model, attributeKey, next.Spec);

                        RefreshCellsDeferred();
                    });
                }
            }
        }


        internal void RefreshCellsDeferred()
        {
            if (refreshingCells) return;
            refreshingCells = true;

            Dispatcher.BeginInvoke(() => { refreshingCells = false; RefreshCells(); }, DispatcherPriority.Background);
        }
        private bool refreshingCells;

        internal void RefreshCells()
        {
            if (TreeNode == null) return;

            for (var i = 0; i < Cells.Count; ++i)
            {
                var next = Cells[i];
                if(next.Spec == null) continue;

                next.Model.CalculateDependencies();
                next.DrawCell();
            }
        }


        protected override void OnMouseWheel(MouseWheelEventArgs e)
        {
            e.Handled = true;
        }
    }
}
