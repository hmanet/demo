﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGridResources
    {
        public static readonly LightGridResources Instance = new LightGridResources();

        public DataTemplate FilterRowDataTemplate { get { return (DataTemplate)this["FilterRowTemplate"]; } }
        public DataTemplate HeaderRowDataTemplate { get { return (DataTemplate)this["HeaderRowTemplate"]; } }
        public DataTemplate ColumnSpecDataTemplate { get { return (DataTemplate)this["ColumnSpecDataTemplate"]; } }
        public DataTemplate GroupColumnViewModelDataTemplate { get { return (DataTemplate)this["GroupColumnViewModelDataTemplate"]; } }


        public Style MenuActionStyle { get { return (Style)this["MenuActionStyle"]; } }
        public Style SplitScrollBarStyle { get { return (Style)this["SplitScrollBarStyle"]; } }
        public ControlTemplate SplitterTemplate { get { return (ControlTemplate)this["SplitterTemplate"]; } }

        public Brush DarkBorderBrush { get; private set; }
        public Brush LightBorderBrush { get; private set; }
        public Brush HeaderBrush { get; private set; }
        public Color LockedHeaderColor { get { return (Color)this["LockedHeaderColor"]; } }
        public Brush FilterPresentBackground { get; private set; }
        public Brush FilterNotPresentBackground { get; private set; }


        public LightGridResources()
        {
            MergedDictionaries.Add(LightGridCommonResources.Instance);

            InitializeComponent();

            DarkBorderBrush = (Brush)this["DarkBorderBrush"]; DarkBorderBrush.Freeze();
            LightBorderBrush = (Brush)this["LightBorderBrush"]; LightBorderBrush.Freeze();
            HeaderBrush =(Brush)this["HeaderBrush"]; HeaderBrush.Freeze();
            FilterPresentBackground = (Brush)this["FilterPresentBackground"]; FilterPresentBackground.Freeze();
            FilterNotPresentBackground = (Brush)this["FilterNotPresentBackground"]; FilterNotPresentBackground.Freeze();
        }

        private void ToolBarButton_PreviewDragEnter(object sender, DragEventArgs e)
        {
            var button = (Button)sender;
            SetButtonBackground(button);
            SetButtonBorderBrush(button);
        }

        private void ToolBarButton_PreviewDragLeave(object sender, DragEventArgs e)
        {
            var button = (Button)sender;
            ResetButtonBackground(button);
            ResetButtonBorderBrush(button);
        }

        private void ToolBarButton_Unloaded(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            ResetButtonBackground(button);
            ResetButtonBorderBrush(button);

            button.PreviewDragEnter -= ToolBarButton_PreviewDragEnter;
            button.PreviewDragLeave -= ToolBarButton_PreviewDragLeave;
            button.Unloaded -= ToolBarButton_Unloaded;
        }

        private void SetButtonBackground(Button button)
        {
            button.Background = (SolidColorBrush)this["ToolBarButtonBackground"];
        }

        private void ResetButtonBackground(Button button)
        {
            button.Background = Brushes.Transparent;
        }

        private void SetButtonBorderBrush(Button button)
        {
            button.BorderBrush = (SolidColorBrush)this["ToolBarButtonBorderBrush"];
        }

        private void ResetButtonBorderBrush(Button button)
        {
            button.BorderBrush = Brushes.Transparent;
        }
    }

    //just for resource related code
    public partial class LightGrid
    {
    }

    //just for resource related code
    public partial class LightGridPanel
    {
    }
}
