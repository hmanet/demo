﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    [DebuggerDisplay("{Spec}")]
    public class LightGridColumn : DependencyObject
    {
        public LightGridColumn(LightGridPanel gridPanel)
        {
            GridPanel = gridPanel;

            Header = new LightGridColumnHeader(gridPanel.Owner);

            foreach (var next in GridPanel.Rows)
            {
                var cell = new LightGridCell(gridPanel) { Row = next, TreeNode = next.TreeNode, Column = this, Spec = Spec };
                Cells.Add(cell);
                next.Cells.Add(cell);
            }
        }

        public LightGrid Owner { get { return GridPanel.Owner; } }
        public LightGridPanel GridPanel { get; private set; }

        public LightGridColumnHeader Header { get; private set; }

        internal readonly List<LightGridCell> Cells = new List<LightGridCell>();


        public bool GridEditable
        {
            get { return gridEditable; }
            set
            {
                if(gridEditable == value) return;

                gridEditable = value;

                foreach (var next in Cells)
                    next.Model.CalculateEditable();
            }
        }
        private bool gridEditable;


        public GridViewModel Grid
        {
            get { return grid; }
            internal set
            {
                if(grid == value) return;

                grid = value;

                Header.Grid = Grid;
            }
        }
        private GridViewModel grid;

        public ColumnSpec Spec
        {
            get { return spec; }
            set
            {
                if(spec == value) return;

                if (spec != null)
                {
                    spec.PropertyChanged -= Spec_PropertyChanged;

                    if (spec == Grid.Spec.GroupColumn)
                    {
                        ((INotifyCollectionChanged)Grid.Spec.Groups).CollectionChanged -= Grid_Spec_Groups_CollectionChanged;
                        SetGroups(Extensions<ColumnSpec>.EmptyArray);
                    }
                }

                spec = value;

                if (spec != null)
                {
                    spec.PropertyChanged += Spec_PropertyChanged;

                    if (spec == Grid.Spec.GroupColumn)
                    {
                        SetGroups(Grid.Spec.Groups.ToArray<ColumnSpec>());
                        ((INotifyCollectionChanged)Grid.Spec.Groups).CollectionChanged += Grid_Spec_Groups_CollectionChanged;
                    }
                }

                foreach (var next in Cells) next.Spec = Spec;

                Header.Spec = Spec;
            }
        }
        private ColumnSpec spec;
        private void Spec_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            switch (e.PropertyName)
            {
                case "Editable": foreach(var next in Cells) next.Model.CalculateEditable(); break;
                case "Visible": foreach(var next in Cells) next.Model.CalculateVisibility(); break;
                case "Strikethrough": foreach(var next in Cells) next.Model.CalculateStrikethrough(); break;
                case "Underline": foreach(var next in Cells) next.Model.CalculateUnderline(); break;
                case "HorizontalAlignment": case "Grouped": foreach (var next in Cells) next.Model.CalculateHorizontalAlignment(); break;
                case "Background": foreach(var next in Cells) next.Model.CalculateBackground(); break;
                case "Foreground": foreach(var next in Cells) next.Model.CalculateForeground(); break;
                case "Border": foreach (var next in Cells) next.Model.CalculateCellBorder(); break;
                case "NumericFormat": foreach (var next in Cells) next.Model.CalculateNumericFormat(); break;
                case "FontFamily": foreach(var next in Cells) next.Model.CalculateFontFamily(); break;
                case "FontWeight": foreach(var next in Cells) next.Model.CalculateFontWeight(); break;
                case "FontSize": foreach(var next in Cells) next.Model.CalculateFontSize(); break;
                case "FontStyle": foreach(var next in Cells) next.Model.CalculateFontStyle(); break;

                //properties that should simply trigger refresh
                case "Selected": break;
                case "DecimalPlaces": break;
                case "FormatInfo": break;
                case "Scaling": break;
                case "TypeDescriptor": break;
                case "Metadata": break;

                //properties that don't affect refresh
                default: return;
            }

            RefreshCellsDeferred();
        }

        private ColumnSpec[] groups = Extensions<ColumnSpec>.EmptyArray;
        private void SetGroups(ColumnSpec[] value)
        {
            foreach(var next in groups) next.PropertyChanged -= Spec_PropertyChanged;

            groups = value;

            foreach(var next in groups) next.PropertyChanged += Spec_PropertyChanged;
        }
        private void Grid_Spec_Groups_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            SetGroups(Grid.Spec.Groups.ToArray<ColumnSpec>());
        }


        internal void RefreshCellsDeferred()
        {
            if (Cells.Count == 0) return;
            if(Spec == null) return;

            if (refreshingCells) return;
            refreshingCells = true;

            Dispatcher.BeginInvoke(() =>
            {
                refreshingCells = false;
                if(Spec == null) return;

                RefreshCells();
            }, DispatcherPriority.DataBind);
        }
        private bool refreshingCells;

        internal void RefreshCells()
        {
            for (var i = 0; i < Cells.Count; i++)
            {
                var next = Cells[i];
                if (next.TreeNode == null) continue;

                next.Model.CalculateDependencies();
                next.DrawCell();
            }
        }
    }
}
