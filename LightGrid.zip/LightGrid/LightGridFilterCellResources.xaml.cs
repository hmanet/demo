﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGridFilterCellResources
    {
        public static readonly LightGridFilterCellResources Instance = new LightGridFilterCellResources();

        public ControlTemplate Template { get { return (ControlTemplate)this["LightGridFilterCellTemplate"]; } }
        public Style Style { get { return (Style)this["LightGridFilterCellStyle"]; } }

        public ControlTemplate FilterCheckBoxTemplate { get { return (ControlTemplate)this["LightGridFilterCheckBoxTemplate"]; } }

        public LightGridFilterCellResources()
        {
            MergedDictionaries.Add(LightGridCommonResources.Instance);

            InitializeComponent();
        }
    }

    //just for resource related code
    public partial class LightGridFilterCell
    {
    }
}
