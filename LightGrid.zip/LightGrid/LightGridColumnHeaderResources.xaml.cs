﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGridColumnHeaderResources
    {
        public static readonly LightGridColumnHeaderResources Instance = new LightGridColumnHeaderResources();

        public ControlTemplate Template { get { return (ControlTemplate)this["LightGridColumnHeaderTemplate"]; } }
        public Style Style { get { return (Style)this["LightGridColumnHeaderStyle"]; } }

        public LightGridColumnHeaderResources()
        {
            MergedDictionaries.Add(LightGridCommonResources.Instance);

            InitializeComponent();
        }
    }

    //just for resource related code
    public partial class LightGridColumnHeader
    {
    }
}
