﻿using System;
using System.Windows;
using System.Windows.Controls;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridFiltersPanel : Canvas
    {
        static LightGridFiltersPanel()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridFiltersPanel), new FrameworkPropertyMetadata((d, a) => ((LightGridFiltersPanel)d).OnDataContextChanged((GridViewModel)a.OldValue, (GridViewModel)a.NewValue), (d, v) => v as GridViewModel));
        }
        public LightGridFiltersPanel()
        {
            Children.Add(Splitter);
        }

        public new GridViewModel DataContext { get { return dataContext; } set { base.DataContext = value; } } private GridViewModel dataContext;
        private void OnDataContextChanged(GridViewModel oldValue, GridViewModel newValue)
        {
            dataContext = newValue;
        }

        internal readonly LightGridColumnHeadersPanel.Thumb Splitter = new LightGridColumnHeadersPanel.Thumb();


        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
        {
            base.OnRenderSizeChanged(sizeInfo);

            Splitter.Height = ActualHeight;
        }
    }
}
