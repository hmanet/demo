﻿using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.OptionSelector;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGridToolBar : UserControl
    {
        #region Constructor
        static LightGridToolBar()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridToolBar), new FrameworkPropertyMetadata((d, a) => ((LightGridToolBar)d).OnDataContextChanged((GridViewModel)a.OldValue, (GridViewModel)a.NewValue), (d, v) => v as GridViewModel));
        }

        public LightGridToolBar()
        {
            ToolBarItems = new ObservableCollection<object>();
            InitializeComponent();
        }

        #endregion

        #region Properties
        public ObservableCollection<object> ToolBarItems { get; private set; }
        #endregion

        #region Private Methods
        private void OnDataContextChanged(GridViewModel oldValue, GridViewModel newValue)
        {
            if (oldValue != null)
            {
                oldValue.Menu.Items.CollectionChanged -= ToolBarCollectionChanged;
                ToolBarItems.Clear();
            }

            if (newValue != null)
            {
                newValue.Menu.Items.CollectionChanged += ToolBarCollectionChanged;
                ToolBarCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, newValue.Menu.Items));
            }
        }

        private void ToolBarCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            ToolBarCollectionChanged(e);
        }

        private void ToolBarCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    foreach (var menu in e.NewItems.OfType<MenuAction>())
                    {
                        if (menu.Level.HasFlag(GridMenuLevels.ToolBar))
                        {
                            ToolBarItems.Add(menu);
                        }
                    }
                    break;
                case NotifyCollectionChangedAction.Remove:
                    foreach (var menu in e.OldItems.OfType<MenuAction>())
                    {
                        if (ToolBarItems.Contains(menu))
                        {
                            ToolBarItems.Remove(menu);
                        }
                    }
                    break;
            }
        }
        #endregion
    }
}
