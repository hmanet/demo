﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid.Editor;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor
{
    public abstract class EditorControl : Control
    {
        static EditorControl()
        {
            DataContextProperty.OverrideMetadata(typeof(EditorControl), new FrameworkPropertyMetadata((d, a) => ((EditorControl)d).OnDataContextChanged((LightGridCellEditorViewModel)a.OldValue, (LightGridCellEditorViewModel)a.NewValue), (d, v) => v as LightGridCellEditorViewModel));
        }
        public EditorControl()
        {
            Focusable = false;
        }
        internal TextBox editorTextBox { get; private set; }

        public new LightGridCellEditorViewModel DataContext { get { return (LightGridCellEditorViewModel)base.DataContext; } set { base.DataContext = value; } }
        protected virtual void OnDataContextChanged(LightGridCellEditorViewModel oldValue, LightGridCellEditorViewModel newValue)
        {
            if (newValue != null)
            {
                Dispatcher.BeginInvoke(() =>
                {
                    if (newValue.Spec == null) return;

                    editorTextBox = this.FindChild<FrameworkElement>(EditorConstant.PART_EDITOR) as TextBox;
                    if(editorTextBox == null) return;

                    if (!string.IsNullOrWhiteSpace(newValue.PreviewInputText))
                        editorTextBox.SetCurrentValue(TextBox.TextProperty, ApplyCasing(newValue.PreviewInputText, editorTextBox.CharacterCasing));

                    if (newValue.SelectAllOnStart) editorTextBox.SelectAll();
                    else if (editorTextBox.Text != null) editorTextBox.CaretIndex = editorTextBox.Text.Length;

                    editorTextBox.HorizontalContentAlignment = newValue.Spec.HorizontalAlignment;

                    editorTextBox.Focus();
                }, DispatcherPriority.Background);
            }
        }

        protected static string ApplyCasing(string input, CharacterCasing casing)
        {
            switch (casing)
            {
                case CharacterCasing.Upper: return input.ToUpperInvariant();
                case CharacterCasing.Lower: return input.ToLowerInvariant();
            }

            return input;
        }

        public static readonly DependencyProperty IsErrorProperty = DependencyProperty.Register("IsError", typeof(bool), typeof(CellEditorControl));
        public bool IsError
        {
            get { return (bool)GetValue(IsErrorProperty); }
            set { SetValue(IsErrorProperty, value); }
        }

        public abstract object GetEditData();
        public abstract void UpdateEditData();

        /// <summary>
        /// Grid control can raise this method to check if editor control needs this event. 
        /// If true Grid won't handle the event and let the editor handle the event.
        /// This is useful for preview events conflict resolution
        /// </summary>
        /// <param name="args">Event argument</param>
        /// <returns></returns>
        public virtual bool NeedEvent(EventArgs args)
        {
            return false;
        }
    }
}
