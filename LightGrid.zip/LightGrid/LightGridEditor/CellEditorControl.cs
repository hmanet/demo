﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using CefSharp.Wpf.Internals;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid.Editor;
using Wells.Derivatives.Carina.Core.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor
{
    /// <summary>
    /// Base control for light grid cell editors
    /// </summary>
    [TemplatePart(Name = PART_CONTENT, Type = typeof(ContentControl))]
    public sealed class CellEditorControl : EditorControl
    {
        private const string PART_CONTENT = "PART_Content";

        static CellEditorControl()
        {
            DataContextProperty.OverrideMetadata(typeof(CellEditorControl), new FrameworkPropertyMetadata((d, a) => ((CellEditorControl)d).OnDataContextChanged((LightGridCellEditorViewModel)a.OldValue, (LightGridCellEditorViewModel)a.NewValue), (d, v) => v as LightGridCellEditorViewModel));
        }
        public CellEditorControl()
        {
            Resources.MergedDictionaries.Add(LightGridCellEditorResources.Instance);

            ZIndex = GridViewModel.EditorZIndex;
            Visibility = Visibility.Hidden;

            AddHandler(KeyDownEvent, new KeyEventHandler(OnKeyDown), true);
        }

        private static bool hasTemplates;
        private static ControlTemplate textEditTemplate;
        private static ControlTemplate numericSpinnerEditTemplate;
        private static ControlTemplate dateEditTemplate;
        private static ControlTemplate optionEditTemplate;
        private static ControlTemplate enumEditTemplate;

        private EditorControl editorControl;

        protected override void OnDataContextChanged(LightGridCellEditorViewModel oldValue, LightGridCellEditorViewModel newValue)
        {
            base.OnDataContextChanged(oldValue, newValue);

            var content = (ContentControl)GetTemplateChild(PART_CONTENT);
            if (content == null) throw new NotSupportedException("PART_CONTENT not found in CellEditorControl");

            if (oldValue != null)
            {
                Visibility = Visibility.Hidden;

                content.DataContext = null;

                if (editorControl != null)
                {
                    editorControl.DataContext = null;
                }
            }

            if (newValue != null)
            {
                // Apply content
                content.DataContext = newValue;
                content.Template = TryFindResource(newValue.CellEditTemplateKey) as ControlTemplate;
                content.ApplyTemplate();
                ZIndex = newValue.Spec.Locked ? GridViewModel.LockedEditorZIndex : GridViewModel.EditorZIndex;
                editorControl = this.FindVisualChild<EditorControl>();
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    if (editorControl != null)
                    {
                        editorControl.DataContext = DataContext;

                        // Focus PART_Editor if present
                        var element = this.FindChild<FrameworkElement>(EditorConstant.PART_EDITOR);
                        if (element != null && element.GetType() != typeof(EditorComboBox))
                            Keyboard.Focus(element);
                        else
                            MoveFocus(new TraversalRequest(FocusNavigationDirection.First));
                    }
                    else
                    {
                        MoveFocus(new TraversalRequest(FocusNavigationDirection.First));
                    }

                }), DispatcherPriority.Background);

                Visibility = Visibility.Visible;
            }
        }

        public override object GetEditData()
        {
            return editorControl == null ? null : editorControl.GetEditData();
        }
        public override void UpdateEditData()
        {
            if (editorControl != null) editorControl.UpdateEditData();
        }

        public bool NeedEvent(MouseWheelEventArgs args)
        {
            return editorControl != null && editorControl.NeedEvent(args);
        }


        public CellViewModel Cell
        {
            get { return cell; }
            set
            {
                if (cell == value) return;

                if (cell != null)
                {
                    cell.Edited = false;

                    Spec = null;
                    TreeNode = null;
                }

                cell = value;

                if (cell != null)
                {
                    cell.Edited = true;

                    Top = cell.Top;
                    Left = cell.Left;
                    Width = cell.Width;
                    Height = cell.Height;

                    Spec = cell.Spec;
                    TreeNode = cell.TreeNode.Model;
                }
            }
        }
        private CellViewModel cell;

        public int ZIndex { get { return zIndex; } set { if (zIndex == value) return; zIndex = value; Canvas.SetZIndex(this, value); } } private int zIndex;
        public double Left { get { return left; } set { if (left == value) return; left = value; Canvas.SetLeft(this, value); } } private double left;
        public double Top { get { return top; } set { if (top == value) return; top = value; Canvas.SetTop(this, value); } } private double top;

        public ColumnSpec Spec { get; private set; }
        public TreeNodeModel TreeNode { get; private set; }


        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (DataContext == null || DataContext.CommitCommand == null) return;

            var parent = ((DependencyObject) e.OriginalSource).FindParent<CellEditorControl>();
            if(parent != this) return;

            if(IsCommitKey(e.Key)) UpdateEditData();

            switch (e.Key)
            {
                case Key.Enter: DataContext.CommitCommand.Execute(EditCompleteTrigger.Enter); e.Handled = true; break;
                case Key.Tab: DataContext.CommitCommand.Execute(((Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.Shift) ? EditCompleteTrigger.ShiftTab : EditCompleteTrigger.Tab); e.Handled = true; break;
                case Key.Escape: DataContext.RevertCommand.Execute(EditCompleteTrigger.Esc); e.Handled = true; break;
            }
        }

        private bool IsCommitKey(Key key)
        {
            return key == Key.Enter || key == Key.Tab;
        }
    }

    public static class EditorConstant
    {
        public const string PART_EDITOR = "PART_Editor";
    }

}
