﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Presentation.Controls;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid.Editor;
using TextBox = System.Windows.Controls.TextBox;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor
{
    [TemplatePart(Name = EditorConstant.PART_EDITOR, Type = typeof(DoubleUpDown))]
    public class NumericSpinnerEditorControl : EditorControl
    {
        private const string PART_TEXTBOX = "PART_TextBox";

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            editorControl = (DoubleUpDown)GetTemplateChild(EditorConstant.PART_EDITOR);
        }

        private DoubleUpDown editorControl;

        protected override void OnDataContextChanged(LightGridCellEditorViewModel oldValue, LightGridCellEditorViewModel newValue)
        {
            base.OnDataContextChanged(oldValue, newValue);

            if (newValue == null) return;

            Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
            {
                var textBox = editorControl.FindChild<WatermarkTextBox>(PART_TEXTBOX);
                if (textBox == null) return;

                textBox.Margin = new Thickness(0, -2, 0, 0);
                textBox.Background = LightGridCellEditorResources.Instance.EditorTextBoxColor;

                if (newValue.Spec != null) textBox.HorizontalContentAlignment = newValue.Spec.HorizontalAlignment;

                if (!string.IsNullOrWhiteSpace(DataContext.PreviewInputText))
                    textBox.SetCurrentValue(TextBox.TextProperty, DataContext.PreviewInputText);

                if (DataContext.SelectAllOnStart) textBox.SelectAll();
                else if (textBox.Text != null) textBox.CaretIndex = textBox.Text.Length;

                textBox.Focus();
            }));
        }

        public override object GetEditData()
        {
            return editorControl == null ? null : editorControl.Value;
        }
        public override void UpdateEditData()
        {
            if (editorControl == null) return;

            var binding = editorControl.GetBindingExpression(DoubleUpDown.ValueProperty);
            binding.UpdateSource();
        }
        public override bool NeedEvent(EventArgs args)
        {
            return args is MouseWheelEventArgs;
        }
    }
}
