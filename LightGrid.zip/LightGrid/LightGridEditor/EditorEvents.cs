﻿using System;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid.Editor;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor
{
    public delegate void EditorStartEventHandler(object sender, EditStartEventArgs args);

    public delegate void EditorEndEventHandler(object sender, EditEndEventArgs args);
}
