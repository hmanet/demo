using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor
{
    public class EditorComboBox : ComboBox
    {
        public static readonly DependencyProperty FocusBrushProperty = DependencyProperty.Register("FocusBrush", typeof(Brush), typeof(EditorComboBox), new PropertyMetadata(Brushes.LightGray));
        public Brush FocusBrush { get { return (Brush)GetValue(FocusBrushProperty); } set { SetValue(FocusBrushProperty, value); } }

        private int _currentItemIndex;
        protected override void OnDropDownOpened(EventArgs e)
        {
            _currentItemIndex = base.SelectedIndex;

            if (_currentItemIndex >= 0)
            {
                var currentItem = (ComboBoxItem) ItemContainerGenerator.ContainerFromIndex(_currentItemIndex);
                if (currentItem != null)
                    currentItem.Background = FocusBrush;
            }

            base.OnDropDownOpened(e);
        }
        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if(base.IsDropDownOpen)
            {
                if(e.Key == Key.Up || e.Key == Key.Down)
                {
                    ComboBoxItem currentItem;

                    if(_currentItemIndex > -1)
                    {
                        currentItem = (ComboBoxItem)ItemContainerGenerator.ContainerFromIndex(_currentItemIndex);
                        currentItem.Background = Brushes.Transparent;
                    }

                    if(e.Key == Key.Up)
                    {
                        _currentItemIndex -= 1;
                        if(_currentItemIndex < 0)
                        {
                            _currentItemIndex = 0;
                        }
                    }
                    else if(e.Key == Key.Down)
                    {
                        _currentItemIndex += 1;
                        if(_currentItemIndex > Items.Count - 1)
                        {
                            _currentItemIndex = Items.Count - 1;
                        }
                    }


                    currentItem = (ComboBoxItem)ItemContainerGenerator.ContainerFromIndex(_currentItemIndex);

                    currentItem.Background = FocusBrush;
                    currentItem.BringIntoView();

                    e.Handled = true;
                    return;
                }
                if(e.Key == Key.Enter)
                {
                    SetCurrentValue(SelectedValueProperty, Items[_currentItemIndex]);
                    var count = base.Items.Count;
                    for(var i = 0; i < count; i++)
                    {
                        var item = (ComboBoxItem)ItemContainerGenerator.ContainerFromIndex(i);
                        item.Background = Brushes.Transparent;
                    }
                }
            }
            base.OnPreviewKeyDown(e);
        }
        protected override void OnDropDownClosed(EventArgs e)
        {
            if(_currentItemIndex > -1 && Items != null && Items.Count > 0)
            {
                ComboBoxItem currentItem = (ComboBoxItem)ItemContainerGenerator.ContainerFromIndex(_currentItemIndex);
                currentItem.Background = Brushes.Transparent;
            }
            base.OnDropDownClosed(e);
        }
    }
}