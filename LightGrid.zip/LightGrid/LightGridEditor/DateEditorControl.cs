﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Presentation.Controls;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid.Editor;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor
{
    [TemplatePart(Name = EditorConstant.PART_EDITOR, Type = typeof(DateTimePicker))]
    public class DateEditorControl : EditorControl
    {
        protected override void OnDataContextChanged(LightGridCellEditorViewModel oldValue, LightGridCellEditorViewModel newValue)
        {
            if(oldValue != null)
            {
                DetachEventHandlers();
            }

            if(newValue != null)
            {
                Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
                {
                    ApplyTemplate();
                    DetachEventHandlers();
                    editorControl = (DateTimePicker)GetTemplateChild(EditorConstant.PART_EDITOR);
                    AttachEventHandlers();

                    var textBox = editorControl.FindChildNamed<TextBox>("PART_TextBox");
                    textBox.Focus();

                    if (!string.IsNullOrWhiteSpace(newValue.PreviewInputText))
                    {
                        textBox.SetCurrentValue(TextBox.TextProperty, ApplyCasing(newValue.PreviewInputText, textBox.CharacterCasing));
                        textBox.CaretIndex = textBox.Text.Length;
                    }

                    textBox.HorizontalContentAlignment = DataContext.Spec.HorizontalAlignment;
                }));
            }
        }

        private void AttachEventHandlers()
        {
            if (editorControl == null) return;
            if (DataContext == null || DataContext.Spec == null) return;

            editorControl.ValueChanged += dateTimePicker_ValueChanged;
          }
        private void DetachEventHandlers()
        {
            if (editorControl == null) return;

            editorControl.ValueChanged -= dateTimePicker_ValueChanged;
        }

        private DateTimePicker editorControl;


        private void dateTimePicker_ValueChanged(object sender, RoutedPropertyChangedEventArgs<object> routedPropertyChangedEventArgs)
        {
            if (editorControl.IsOpen)
                DataContext.CommitCommand.Execute(EditCompleteTrigger.Click);
        }


        public override object GetEditData()
        {
            return editorControl == null ? null : editorControl.Value;
        }

        public override void UpdateEditData()
        {
            if (editorControl == null) return;

            var binding = editorControl.GetBindingExpression(DateTimePicker.ValueProperty);
            if (binding != null) binding.UpdateSource();
        }
    }
}
