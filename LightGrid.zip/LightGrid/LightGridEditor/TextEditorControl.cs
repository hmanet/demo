﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid.Editor;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor
{
    [TemplatePart(Name = EditorConstant.PART_EDITOR, Type = typeof(TextBox))]
    public class TextEditorControl : EditorControl
    {
        static TextEditorControl()
        {
            DataContextProperty.OverrideMetadata(typeof(TextEditorControl), new FrameworkPropertyMetadata((d, a) => ((TextEditorControl)d).OnDataContextChanged((LightGridCellEditorViewModel)a.OldValue, (LightGridCellEditorViewModel)a.NewValue), (d, v) => v as LightGridCellEditorViewModel));
        }

        public override object GetEditData()
        {
            return editorTextBox == null ? null : editorTextBox.Text;
        }
        public override void UpdateEditData()
        {
            if(editorTextBox == null) return;

            var binding = editorTextBox.GetBindingExpression(TextBox.TextProperty);
            if (binding == null) return;

            binding.UpdateSource();
        }

        protected override void OnDataContextChanged(LightGridCellEditorViewModel oldValue, LightGridCellEditorViewModel newValue)
        {
            base.OnDataContextChanged(oldValue, newValue);

            if (oldValue != null)
            {
                editorTextBox.TextChanged -= editorTextBox_TextChanged;
            }

            if (newValue != null)
            {
                Dispatcher.BeginInvoke(() =>
                {
                    if (newValue.Spec == null) return;

                    editorTextBox.CharacterCasing = newValue.CharacterCasing;
                    editorTextBox.TextChanged += editorTextBox_TextChanged;

                }, DispatcherPriority.Background);
            }
        }

        private void editorTextBox_TextChanged(object sender, TextChangedEventArgs textChangedEventArgs)
        {
            var binding = BindingOperations.GetBinding(editorTextBox, TextBox.TextProperty);
            if (binding == null) return;

            IsError = DataContext.Validate(editorTextBox.Text);

            if (DataContext.UpdateEditDataOnKeyDown) UpdateEditData();
        }
    }
}
