﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid.Editor;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor
{
    [TemplatePart(Name = EditorConstant.PART_EDITOR, Type = typeof(ComboBox))]
    public class LightGridOptionEditorControl : EditorControl
    {
        protected override void OnDataContextChanged(LightGridCellEditorViewModel oldValue, LightGridCellEditorViewModel newValue)
        {
            base.OnDataContextChanged(oldValue, newValue);
              if(oldValue != null)
            {
                DetachEventHandlers();
            }

            if (newValue != null)
            {
                Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
                {
                    ApplyTemplate();
                    DetachEventHandlers();
                    editorControl = (ComboBox) GetTemplateChild(EditorConstant.PART_EDITOR);
                    AttachEventHandlers();

                    var textBox = editorControl.FindChildNamed<TextBox>("PART_EditableTextBox");
                    textBox.Focus();

                    if (!string.IsNullOrWhiteSpace(newValue.PreviewInputText))
                    {
                        textBox.SetCurrentValue(TextBox.TextProperty, ApplyCasing(newValue.PreviewInputText, textBox.CharacterCasing));
                        textBox.CaretIndex = textBox.Text.Length;
                    }

                    textBox.HorizontalContentAlignment = DataContext.Spec.HorizontalAlignment;
                }));
            }
        }
        private void AttachEventHandlers()
        {
            if (editorControl == null) return;

            if (DataContext == null || DataContext.Spec == null) return;


            editorControl.Loaded += editorControl_Loaded;
            editorControl.SelectionChanged += editorControl_SelectionChanged;
        }
        private void DetachEventHandlers()
        {
            if (editorControl == null) return;

            editorControl.Loaded -= editorControl_Loaded;
            editorControl.SelectionChanged -= editorControl_SelectionChanged;
        }

        private ComboBox editorControl;
        private void editorControl_Loaded(object sender, RoutedEventArgs routedEventArgs)
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
            {
                var editorTextBox = editorControl.FindChildNamed<TextBox>("PART_EditableTextBox");
                if(editorTextBox == null) return;
 
                editorTextBox.Focus();
            }));
        }
        private void editorControl_SelectionChanged(object sender, SelectionChangedEventArgs args)
        {
            if (editorControl.IsDropDownOpen)
                DataContext.CommitCommand.Execute(EditCompleteTrigger.Click);
        }

        public override object GetEditData()
        {
            return editorControl == null ? null : editorControl.SelectedValue;
        }
        public override void UpdateEditData()
        {
            if(editorControl == null) return;

            var binding = editorControl.GetBindingExpression(Selector.SelectedValueProperty);
            if(binding != null) binding.UpdateSource();
        }
    }
}
