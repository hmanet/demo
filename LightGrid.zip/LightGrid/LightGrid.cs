﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Common.Logging;
using Wells.Derivatives.Carina.Core.Metadata;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Presentation.CarinaDragDrop;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGrid : Control
    {
        private static readonly ILog Log = LogManager.GetLogger(typeof(LightGrid));

        static LightGrid()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGrid), new FrameworkPropertyMetadata((d, a) => ((LightGrid)d).OnDataContextChanged((GridViewModel)a.OldValue, (GridViewModel)a.NewValue), (d, v) => v as GridViewModel));
            BackgroundProperty.OverrideMetadata(typeof(LightGrid), new FrameworkPropertyMetadata(Brushes.Transparent));
        }
        public LightGrid()
        {
            Resources.MergedDictionaries.Add(LightGridResources.Instance);
            Resources.MergedDictionaries.Add(LightGridCellEditorResources.Instance);
            ContextMenu = new ContextMenu();
            ContextMenu.PlacementTarget = this;

            ApplyTemplate();

            GridPanel = (LightGridPanel)Template.FindName("GridPanel", this);
            GridPanel.Owner = this;

            ColumnHeadersPanel = (LightGridColumnHeadersPanel)Template.FindName("ColumnHeadersPanel", this);
            FiltersPanel = (LightGridFiltersPanel)Template.FindName("FiltersPanel", this);

            MenuPanel = (LightGridMenuPanel)Template.FindName("MenuPanel", this);
            MenuPanel.Popup = (Popup)Template.FindName("MenuPanelPopup", this);
            MenuPanel.Owner = this;

            GridBarPanel = (LightGridGridBarPanel)Template.FindName("GridBarPanel", this);
            GridBarPanel.Owner = this;

            ToolBarPanel = (LightGridToolBar)Template.FindName("ToolBarPanel", this);

            LayoutGrid = (System.Windows.Controls.Grid) Template.FindName("LayoutGrid", this);

            SizeChanged += (a, b) => CalculateViewportSize();

            verticalScrollBar = (ScrollBar)Template.FindName("verticalScrollBar", this);
            verticalScrollBar.IsVisibleChanged += (a, b) => CalculateViewportSize();
            verticalScrollBar.SizeChanged += (a, b) => CalculateViewportSize();

            horizontalScrollBar = (ScrollBar)Template.FindName("horizontalScrollBar", this);
            horizontalScrollBar.IsVisibleChanged += (a, b) => CalculateViewportSize();
            horizontalScrollBar.SizeChanged += (a, b) => CalculateViewportSize();
            horizontalScrollBar.Scroll += (a, b) => GridPanel.Focus();


            DragDropHandler = new LightGridDragDropHandler();

            //TODO: move the below code in the change handler of DragDrop
            DragDrop = new LightDragDrop(this);
            DragDrop.DragAreas.AddRange(new[]
            {
                new LightDragDrop.FrameworkElementTypeArea(typeof(LightGridColumnHeader), drag: (visual, Point) => ((LightGridColumnHeader)visual).Grid.EnableColumReordering ? ((LightGridColumnHeader)visual).Grid.Spec.SelectedColumns.ToArray() : null),
                new LightDragDrop.FrameworkElementTypeArea(typeof(LightGridGridBarPanel), drag: (visual, Point) => ((LightGridGridBarPanel)visual).DataContext.EnableColumReordering ? ((LightGridGridBarPanel)visual).DataContext.Spec.SelectedColumns.ToArray() : null),
                //new LightDragDrop.FrameworkElementTypeArea(typeof(LightGridCell), drag: (visual, Point) => ((LightGridCell)visual).Grid.EnableRowDrag && ((LightGridCell)visual).Grid.SelectionMode != SelectionModes.Drag ? ((LightGridCell)visual).Grid.Tree.ActiveNode : null),
            });
            DragDrop.HoverAreas.AddRange(new[]
            {
                (LightDragDrop.Area)new LightDragDrop.FrameworkElementArea(MenuPanel, hover: (a, b) => { MenuPanel.Show(); return true; }),
                new LightDragDrop.FrameworkElementArea(MenuPanel.Popup, hover: (a, b) => { MenuPanel.Show(); return true; }),

                new LightDragDrop.RectArea(this, new Rect(20, 0, 10, 25), HorizontalAlignment.Left, VerticalAlignment.Top, hover: (data, Point) => { DragDrop.StartSpeedAcceleration(); DataContext.ViewportOffset -= (int)DragDrop.Speed; return true; }),
                new LightDragDrop.RectArea(this, new Rect(20, 0, 10, 25), HorizontalAlignment.Right, VerticalAlignment.Top, hover: (data, Point) => { DragDrop.StartSpeedAcceleration(); DataContext.ViewportOffset += (int)DragDrop.Speed; return true; }),

                new LightDragDrop.RectArea(GridPanel, new Rect(0, 0, 10, 0), HorizontalAlignment.Left, VerticalAlignment.Stretch, hover: (data, Point) => { DragDrop.StartSpeedAcceleration(); DataContext.ViewportOffset -= (int)DragDrop.Speed; GridPanel.DragSelection(Point); return true; }),
                new LightDragDrop.RectArea(GridPanel, new Rect(0, 0, 10, 0), HorizontalAlignment.Right, VerticalAlignment.Stretch, hover: (data, Point) => { DragDrop.StartSpeedAcceleration(); DataContext.ViewportOffset += (int)DragDrop.Speed; GridPanel.DragSelection(Point); return true; }),
                new LightDragDrop.RectArea(GridPanel, new Rect(0, 0, 0, 10), HorizontalAlignment.Stretch, VerticalAlignment.Top, hover: (data, Point) => { DragDrop.StartSpeedAcceleration(); DataContext.Tree.ViewportOffset -= (int)DragDrop.Speed; GridPanel.DragSelection(Point); return true; }),
                new LightDragDrop.RectArea(GridPanel, new Rect(0, 0, 0, 10), HorizontalAlignment.Stretch, VerticalAlignment.Bottom, hover: (data, Point) => { DragDrop.StartSpeedAcceleration(); DataContext.Tree.ViewportOffset += (int)DragDrop.Speed; GridPanel.DragSelection(Point); return true; }),

                new LightDragDrop.RectArea(this, new Rect(0, 0, 0, 0), HorizontalAlignment.Stretch, VerticalAlignment.Stretch, hover: (data, Point) => { DragDrop.StopSpeedAcceleration(); return true; }),
            });

            Unloaded += OnUnloaded;
            Loaded += OnLoaded;

            DragDrop.DragEnded += () => MenuPanel.Hide();
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                if (GridPanel.DataContext == null)
                    GridPanel.DataContext = prevDataContext;

                prevDataContext = null;
                if (DragDropHandler is LightGridDragDropHandler)
                {
                    MenuPanel.Popup.SetValue(DragDropProperties.DragDropHandlerProperty, DragDropHandler);
                    ColumnHeadersPanel.SetValue(DragDropProperties.DragDropHandlerProperty, DragDropHandler);
                    GridBarPanel.SetValue(DragDropProperties.DragDropHandlerProperty, DragDropHandler);
                    GridPanel.SetValue(DragDropProperties.DragDropHandlerProperty, DragDropHandler);
                }

            }, DispatcherPriority.Background);
        }
        private void OnUnloaded(object sender, RoutedEventArgs e)
        {
            Dispatcher.BeginInvoke(() =>
            {
                if (GridPanel.DataContext != null)
                    prevDataContext = GridPanel.DataContext;

                GridPanel.DataContext = null;
            }, DispatcherPriority.Background);
        }
        private GridViewModel prevDataContext;
        private readonly ScrollBar verticalScrollBar;
        private readonly ScrollBar horizontalScrollBar;

        private readonly LightGridMenuPanel MenuPanel;
        internal readonly LightGridPanel GridPanel;
        internal readonly LightGridColumnHeadersPanel ColumnHeadersPanel;
        internal readonly LightGridFiltersPanel FiltersPanel;
        private readonly LightGridGridBarPanel GridBarPanel;
        internal readonly LightGridToolBar ToolBarPanel;
        internal readonly TimerManager Timer = new TimerManager();
        private readonly System.Windows.Controls.Grid LayoutGrid;


        public new GridViewModel DataContext { get { return dataContext; } set { base.DataContext = value; } } private GridViewModel dataContext;
        private void OnDataContextChanged(GridViewModel oldValue, GridViewModel newValue)
        {
            if (oldValue != null)
            {
                oldValue.PropertyChanged -= DataContext_PropertyChanged;
                oldValue.Spec.PropertyChanged -= DataContext_Spec_PropertyChanged;
                oldValue.Tree.EndChanges -= DataContext_Tree_EndChanges;
                oldValue.Tree.SelectionChanged -= DataContext_Tree_SelectionChange;
                

                if (oldValue.CellScreenPosition == CalculateCellScreenPosition) oldValue.CellScreenPosition = null;

                DragDropHandler.Detach(oldValue);

                var bindings = oldValue.CommandBindings;
                if (bindings != null)
                {
                    foreach (var next in bindings) CommandBindings.Remove(next);
                    bindings.CollectionChanged -= DataContext_CommandBindings_CollectionChanged;
                }

                TeardownContextMenu();
            }

            dataContext = newValue;

            MenuPanel.DataContext = newValue;
            GridPanel.DataContext = newValue;
            ColumnHeadersPanel.DataContext = newValue;
            FiltersPanel.DataContext = newValue;
            ToolBarPanel.DataContext = newValue;

            if (newValue != null)
            {
                newValue.PropertyChanged += DataContext_PropertyChanged;
                newValue.Spec.PropertyChanged += DataContext_Spec_PropertyChanged;
                newValue.Tree.EndChanges += DataContext_Tree_EndChanges;
                newValue.Tree.SelectionChanged += DataContext_Tree_SelectionChange;

                newValue.CellScreenPosition = CalculateCellScreenPosition;

                DragDropHandler.Attach(newValue);

                var bindings = newValue.CommandBindings;
                if (bindings != null)
                {
                    CommandBindings.AddRange(bindings.ToArray());
                    bindings.CollectionChanged += DataContext_CommandBindings_CollectionChanged;
                }

                SetupContextMenu();
            }

            CalculateViewportSize();

        }
        private void DataContext_CommandBindings_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    CommandBindings.AddRange(e.NewItems);
                    break;
                case NotifyCollectionChangedAction.Remove:
                    foreach (CommandBinding item in e.OldItems) CommandBindings.Remove(item);
                    break;
                case NotifyCollectionChangedAction.Replace:
                    foreach (CommandBinding item in e.OldItems) CommandBindings.Remove(item);
                    CommandBindings.AddRange(e.NewItems);
                    break;
                case NotifyCollectionChangedAction.Reset:
                    CommandBindings.Clear();
                    CommandBindings.AddRange(DataContext.CommandBindings);
                    break;
            }
        }
        private void DataContext_Spec_PropertyChanged(object sender, PropertyChangedEventArgs args)
        {
            switch (args.PropertyName)
            {
                case "EnableFilterRow": Spec_EnableFilterRowChanged(); break;
            }
        }
        private void Spec_EnableFilterRowChanged() { CalculateViewportSize(); }

        private void DataContext_PropertyChanged(object sender, PropertyChangedEventArgs args)
        {
            switch (args.PropertyName)
            {
                case "RowHeight": DataContext_RowHeightChanged(); break;
            }
        }
        private void DataContext_RowHeightChanged() { CalculateViewportSize(); }
        
        private void DataContext_Tree_EndChanges()
        {
            if (oldViewportOffset != DataContext.Tree.ViewportOffset)
            {
                oldViewportOffset = DataContext.Tree.ViewportOffset;

                Timer.StopAll();

                foreach (var next in Rows)
                    next.RefreshAfterScroll();
            }
        }
        private double oldViewportOffset;

        private void DataContext_Tree_SelectionChange(ChangeEventArgs<TreeNodeModel> nodeArgs, ChangeEventArgs<AttributeKey> attributeArgs)
        {
            if(DataContext.Tree.Builder.SelectedCount == 0 && !DataContext.Spec.SelectedColumns.Any())
                CommandManager.InvalidateRequerySuggested();//Escape key press was not triggering InvalidateRequerySuggested
        }

        internal IEnumerable<LightGridColumn> Columns { get { if (GridPanel == null) yield break; foreach (var next in GridPanel.Columns) yield return next; } }
        internal IEnumerable<LightGridRow> Rows { get { var column = Columns.FirstOrDefault(x => x.Spec != null); if (column == null) yield break; foreach (var next in column.Cells) yield return next.Row; } }


        public DragDropActions DragDropHandler { get; set; }
        public readonly LightDragDrop DragDrop;


        public static readonly DependencyProperty HideMenuPanelProperty = DependencyProperty.Register("HideMenuPanel", typeof(bool), typeof(LightGrid), new FrameworkPropertyMetadata((d, a) => ((LightGrid)d).OnHideMenuPanelChanged()));
        public bool HideMenuPanel { get { return (bool)GetValue(HideMenuPanelProperty); } set { SetValue(HideMenuPanelProperty, value); } }
        private void OnHideMenuPanelChanged()
        {
            MenuPanel.Visibility = HideMenuPanel ? Visibility.Collapsed : Visibility.Visible;
        }


        public static readonly DependencyProperty EditOnEnterProperty = DependencyProperty.Register("EditOnEnter", typeof(bool), typeof(LightGrid));
        public bool EditOnEnter { get { return (bool)GetValue(EditOnEnterProperty); } set { SetValue(EditOnEnterProperty, value); } }


        public static readonly RoutedEvent RowDoubleClickEvent = EventManager.RegisterRoutedEvent("RowDoubleClick", RoutingStrategy.Bubble, typeof(LightGridRoutedEventHandler), typeof(LightGrid));
        public event LightGridRoutedEventHandler RowDoubleClick { add { AddHandler(RowDoubleClickEvent, value); } remove { RemoveHandler(RowDoubleClickEvent, value); } }

        public static readonly RoutedEvent ColumnDoubleClickEvent = EventManager.RegisterRoutedEvent("ColumnDoubleClick", RoutingStrategy.Bubble, typeof(LightGridRoutedEventHandler), typeof(LightGrid));
        public event LightGridRoutedEventHandler ColumnDoubleClick { add { AddHandler(ColumnDoubleClickEvent, value); } remove { RemoveHandler(ColumnDoubleClickEvent, value); } }

        private void CalculateViewportSize()
        {
            if (GridPanel == null) return;
            if (DataContext == null) return;
            if (horizontalScrollBar == null) return;
            if (verticalScrollBar == null) return;

            var hsHeight = horizontalScrollBar.Visibility == Visibility.Visible ? horizontalScrollBar.ActualHeight : 0;
            var vsWidth = verticalScrollBar.Visibility == Visibility.Visible ? verticalScrollBar.ActualWidth : 0;
            var frHeight = DataContext.Spec.EnableFilterRow ? DataContext.RowHeight : 0;
            var hbHeight = DataContext.HeadersHeight;

            DataContext.TotalViewportSize = (int)Math.Max(LayoutGrid.ActualWidth - vsWidth - 2, 0);
            DataContext.Tree.TotalViewportSize = (int)(Math.Max(LayoutGrid.ActualHeight - hsHeight - frHeight - hbHeight - 2, 0) / DataContext.RowHeight);
        }

        private Rect CalculateCellScreenPosition(TreeNodeModel node, ColumnSpec spec)
        {
            if (node == null) return default(Rect);

            foreach (var row in Rows)
            {
                if (TreeNodeViewModel.IdEquals(row.TreeNode, node) == false) continue;

                foreach (var cell in row.Cells)
                {
                    if (cell.Model.Spec != spec) continue;

                    return new Rect(cell.PointToScreen(new Point()), new Size(cell.ActualWidth, cell.ActualHeight));
                }

                break;
            }

            return default(Rect);
        }


        private void UpdateMenuState(object source)
        {
            var level = GridMenuLevels.Row | GridMenuLevels.Cell;

            if (source != null)
            {
                if (((DependencyObject)source).FindParentObjectByType<LightGridMenuPanel>() != null)
                {
                    level = GridMenuLevels.Grid;
                }
                else if (((DependencyObject)source).FindParentObjectByType<LightGridFilterCell>() != null)
                {
                    level = GridMenuLevels.Filter;
                }
                else if (((DependencyObject) source).FindParentObjectByType<LightGridColumnHeader>() != null)
                {
                    level = GridMenuLevels.Column;
                }
                else if (((DependencyObject) source).FindParentObjectByType<LightGridCell>() != null)
                {
                    if (DataContext.Spec.SelectionUnit == SelectionUnits.Cell) level = GridMenuLevels.Cell;
                    else level = GridMenuLevels.Row | GridMenuLevels.Cell;
                }
                else if (((DependencyObject) source).FindParentObjectByType<LightGridGridBarPanel>() != null)
                {
                    if (DataContext.Spec.SelectionUnit == SelectionUnits.Cell) level = GridMenuLevels.Column | GridMenuLevels.Cell;
                    else level = GridMenuLevels.Column;
                }
            }

            DataContext.Menu.Level = level;
        }
        private void SetupContextMenu()
        {
            ContextMenu.ItemsSource = DataContext.Menu.Items;
            ContextMenu.IsOpen = DataContext.Menu.IsOpen;
            ContextMenu.ItemContainerStyle = LightGridResources.Instance.MenuActionStyle;

            BindingOperations.SetBinding
            (
                ContextMenu,
                ContextMenu.IsOpenProperty,
                new Binding
                {
                    Source = DataContext.Menu,
                    Path = new PropertyPath("IsOpen"),
                    UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
                }
            );
        }
        private void TeardownContextMenu()
        {
            ContextMenu.ItemsSource = null;
            ContextMenu.IsOpen = false;
            ContextMenu.ItemContainerStyle = null;

            BindingOperations.ClearBinding(ContextMenu, ContextMenu.IsOpenProperty);
        }


        protected override void OnContextMenuOpening(ContextMenuEventArgs e)
        {
            base.OnContextMenuOpening(e);

            e.Handled = true;

            UpdateMenuState(e.OriginalSource);

            DataContext.Menu.IsOpen = true;
        }

        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseDown(e);

            if (IsKeyboardFocusWithin == false)
            {
                Dispatcher.BeginInvoke(() =>
                {
                    if (IsKeyboardFocusWithin == false) Focus();
                }, DispatcherPriority.Input);
            }
        }

        protected override void OnPreviewMouseDoubleClick(MouseButtonEventArgs e)
        {
            if (e.ChangedButton != MouseButton.Left)
            {
                base.OnPreviewMouseDoubleClick(e);
                return;
            }
            if (e.OriginalSource == null) return;

            var cell = e.OriginalSource as LightGridCell;
            if (cell != null)
            {
                RaiseRowDoubleClickEvent(cell.Model.TreeNode, cell.Model.Spec);
                base.OnPreviewMouseDoubleClick(e);
                return;
            }
            var columnHeader = (e.OriginalSource as DependencyObject).FindParent<LightGridColumnHeader>();
            if (columnHeader != null)
            {
                RaiseColumnDoubleClickEvent(columnHeader);
            }

            base.OnPreviewMouseDoubleClick(e);
        }
        private void RaiseRowDoubleClickEvent(TreeNodeViewModel nodeViewModel, ColumnSpec spec)
        {
            RaiseEvent(new LightGridEventArgs(RowDoubleClickEvent, nodeViewModel, spec));
        }
        private void RaiseColumnDoubleClickEvent(LightGridColumnHeader columnHeader)
        {
            RaiseEvent(new LightGridEventArgs(ColumnDoubleClickEvent, null, columnHeader.Spec));

            RotateCycleColumns(columnHeader);
        }
        private void RotateCycleColumns(LightGridColumnHeader columnHeader)
        {
            var columnSpec = columnHeader.Spec;
            if (columnSpec.Cycle == null) return;

            var cycles = GridPanel.DataContext.Spec.Cycles;
            var chains = GridPanel.DataContext.Spec.Chains;

            if (!columnSpec.IsColumnChained)
            {
                columnSpec.Cycle.Next(GridPanel.DataContext.Spec, columnSpec);
                columnHeader.Spec = columnSpec.Cycle.SelectedColumn;
            }
            else
            {
                Debug.Assert(columnSpec.ChainColor != null, "Chained column has to have color!");

                var chain = chains[columnSpec.ChainColor.Value];
                if (chain == null) return;

                chain.Columns.Where(c => c.Cycle != null && c.Visible).ForEach(c =>
                {
                    var currentCycle = cycles.FirstOrDefault(cy => cy == c.Cycle);
                    if (currentCycle == null) return;

                    currentCycle.Next(GridPanel.DataContext.Spec);
                });
            }
        }

        protected override void OnGotFocus(RoutedEventArgs e)
        {
            GridPanel.Focus();
        }
    }

    public class LightGridEventArgs : RoutedEventArgs
    {
        public TreeNodeViewModel TreeNode { get; private set; }
        public ColumnSpec ColumnSpec { get; private set; }

        public LightGridEventArgs(RoutedEvent routedEvent, TreeNodeViewModel nodeViewModel, ColumnSpec columnSpec) : base(routedEvent)
        {
            TreeNode = nodeViewModel;
            ColumnSpec = columnSpec;
        }
    }

    public delegate void LightGridRoutedEventHandler(object sender, LightGridEventArgs e);
}
