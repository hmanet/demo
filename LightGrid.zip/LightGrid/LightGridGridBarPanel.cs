﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridGridBarPanel : Canvas
    {
        static LightGridGridBarPanel()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridGridBarPanel), new FrameworkPropertyMetadata((d, a) => ((LightGridGridBarPanel)d).OnDataContextChanged((GridViewModel)a.OldValue, (GridViewModel)a.NewValue), (d, v) => v as GridViewModel));
        }
        public LightGridGridBarPanel()
        {
            AllowDrop = true;

            Background = Brushes.LightGray;
        }

        public LightGrid Owner { get; internal set; }

        public new GridViewModel DataContext { get { return (GridViewModel)base.DataContext; } set { base.DataContext = value; } }
        private void OnDataContextChanged(GridViewModel oldValue, GridViewModel newValue)
        {
            if (oldValue != null)
            {
                oldValue.Spec.PropertyChanged -= DataContext_Spec_PropertyChanged;
            }

            if (newValue != null)
            {
                newValue.Spec.PropertyChanged += DataContext_Spec_PropertyChanged;

                Height = DataContext.HeadersHeight;

                CalculateGroupColumns();
            }
        }


        private void DataContext_Spec_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "EnableGridBar")
            {
                Visibility = DataContext.Spec.EnableGridBar ? Visibility.Visible : Visibility.Collapsed;
            }
        }


        private void CalculateGroupColumns()
        {
            Visibility = DataContext.Spec.EnableGridBar ? Visibility.Visible : Visibility.Collapsed;

            var border = new Border
            {
                Padding = new Thickness(2),
                Background = Brushes.Transparent
            };

            var contentControl = new ContentControl
            {
                ContentTemplate = LightGridResources.Instance.GroupColumnViewModelDataTemplate,
                Content = new GroupColumnViewModel(DataContext, false),
            };
            SetLeft(contentControl, 0);
            Children.Add(contentControl);
            SetZIndex(contentControl, 1);

            border.Height = Height;
            SetLeft(border, 0);
            SetZIndex(border, 0);

            Children.Add(border);
        }
    }
}
