﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public abstract class RoutedCommandToGridBridge
    {
        protected readonly GridViewModel Grid;

        protected RoutedCommandToGridBridge(GridViewModel grid, ICommand command, ObservableCollection<CommandBinding> commandBindings)
        {
            Grid = grid;
            Grid.Tree.Builder.SendingCommand += OnBuilderCommand;
            commandBindings.Add(new CommandBinding(command, Executed, CanExecute));
        }

        private void CanExecute(object sender, CanExecuteRoutedEventArgs args)
        {
            OnCanExecute(sender, args);
            args.Handled = true;
        }

        private void Executed(object sender, ExecutedRoutedEventArgs args)
        {
            OnBeforeExecute(sender, args);
            if (args.Handled)
                return;

            ScheduleExport();
            args.Handled = true;
        }

        private void OnBuilderCommand(object obj)
        {
            if (!Equals(obj))
                return;

            var bridge = (RoutedCommandToGridBridge) obj;
            bridge.OnExecuted();
        }

     /*   protected static ISteppedProgressElement CreateProgressElement(INotificationService notificationService,
            string key, int numSteps, string prefix, string source)
        {
            var transmitter = notificationService.ProgressNotifier
                .CreateTransmitter<ISteppedProgressElement>(key, source);

            transmitter.ProgressElement.Start(numSteps, prefix);
            return transmitter.ProgressElement;
        }
        */

        protected void ScheduleExport()
        {
            Grid.Tree.Builder.SendCommand(this);
        }

        protected abstract void OnExecuted();
        protected abstract void OnBeforeExecute(object sender, ExecutedRoutedEventArgs args);
        protected abstract void OnCanExecute(object sender, CanExecuteRoutedEventArgs args);

    }
}
