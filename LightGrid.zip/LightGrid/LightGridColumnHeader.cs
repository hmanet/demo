﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Presentation.Converters;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGridColumnHeader : Control
    {
        static LightGridColumnHeader()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridColumnHeader), new FrameworkPropertyMetadata(null, (d, v) => d));
        }
        public LightGridColumnHeader(LightGrid owner)
        {
            Owner = owner;

            Resources.MergedDictionaries.Add(LightGridColumnHeaderResources.Instance);

            Template = LightGridColumnHeaderResources.Instance.Template;
            Style = LightGridColumnHeaderResources.Instance.Style;

            ApplyTemplate();
            border = (Border)Template.FindName("border", this);
            chainBorder = (Border)Template.FindName("chainBorder", this);
            contentControl = (ContentControl)Template.FindName("contentControl", this);
            Owner.ColumnHeadersPanel.Children.Add(this);
            Owner.ColumnHeadersPanel.Children.Add(Splitter);

            DataContext = this;
            ContextMenu = Owner.ContextMenu;

            Filter = new LightGridFilterCell(owner);
        }
        private readonly Border border;
        private readonly Border chainBorder;
        private readonly ContentControl contentControl;
        internal readonly LightGridColumnHeadersPanel.Thumb Splitter = new LightGridColumnHeadersPanel.Thumb() { Opacity = .3 };


        public LightGrid Owner { get; private set; }

        public ColumnSpec Spec { get { return spec; } internal set { if(spec == value) return; var oldValue = spec; spec = value; OnSpecChanged(oldValue, spec); } } private ColumnSpec spec;
        private void OnSpecChanged(ColumnSpec oldValue, ColumnSpec newValue)
        {
            if (oldValue != null) oldValue.PropertyChanged -= Spec_PropertyChanged;

            if (newValue != null) newValue.PropertyChanged += Spec_PropertyChanged;

            if(newValue == null)
            {
                Visibility = Splitter.Visibility = Visibility.Hidden;
                Splitter.Spec = null;
                Filter.Spec = null;
            }
            else
            {
                Visibility = Splitter.Visibility = Visibility.Visible;
                Splitter.Spec = newValue;
                Filter.Spec = newValue;

                BeginCalculateContent();
                BeginCalculateChainBorder();
                CalculateDependencies();
            }
        }
        private void Spec_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            CalculateDependencies();

            if (e.PropertyName == "ChainColor")
            {
                BeginCalculateChainBorder();
            }
        }

        public GridViewModel Grid
        {
            get { return grid; }
            internal set
            {
                if (grid != null) grid.PropertyChanged -= Grid_PropertyChanged;

                grid = value;

                if (grid != null) grid.PropertyChanged += Grid_PropertyChanged;

                if(grid != null)
                {
                    BeginCalculateContent();
                    CalculateDependencies();
                }

                Splitter.Grid = Grid;
                Filter.Grid = Grid;
            }
        }
        private GridViewModel grid;
        private void Grid_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            CalculateDependencies();
        }


        public LightGridFilterCell Filter { get; private set; }


        public int ZIndex { get { return zIndex; } set { if(zIndex == value) return; zIndex = value; OnZIndexChanged(); Canvas.SetZIndex(this, value); } } private int zIndex;
        private void OnZIndexChanged()
        {
            Splitter.ZIndex = ZIndex + 1;
        }

        public double Left { get { return left; } set { if(left == value) return; left = value; OnLeftChanged(); Canvas.SetLeft(this, value); } } private double left;
        private void OnLeftChanged()
        {
            CalculateSplitterLeft();
        }
        private void CalculateSplitterLeft()
        {
            if (Spec == null) return;

            Splitter.Left = Left + Spec.Width;
        }

        public new double Width { get { return width; } set { if(width == value) return; width = value; base.Width = value; } } private double width;


        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseDown(e);

            if (e.ChangedButton == MouseButton.Right && e.ClickCount == 1)
                Owner.GridPanel.DataContext.CurrentSpec = Spec;

            if (!(IsFocused || IsKeyboardFocusWithin))
                Focus();

            Owner.GridPanel.BeginSelection(this, e.OriginalSource, e.ChangedButton, PointToScreen(e.GetPosition(this)));
        }
        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseUp(e);

            Owner.GridPanel.EndSelection(this, e.OriginalSource, e.ChangedButton, PointToScreen(e.GetPosition(this)));
        }

        protected override void OnPreviewMouseWheel(MouseWheelEventArgs e)
        {
            base.OnPreviewMouseWheel(e);

            if(e.Delta == 0) return;

            var delta = -(e.Delta / Math.Abs(e.Delta));

            if (Keyboard.Modifiers == ModifierKeys.Alt)
            {
                Owner.DataContext.ViewportOffset += 50 * delta;
            }
        }

        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);

            ToolTip = Owner.GridPanel.DataContext.GetColumnToolTip(Spec);

        }

        protected override void OnContextMenuOpening(ContextMenuEventArgs e)
        {
            base.OnContextMenuOpening(e);

            Owner.GridPanel.BeginSelection(this, e.OriginalSource, MouseButton.Right, PointToScreen(Mouse.GetPosition(this)));
        }


        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
        {
            base.OnRenderSizeChanged(sizeInfo);

            Splitter.Height = ActualHeight;
        }


        private void BeginCalculateContent() { Dispatcher.ThrottleInvoke(CalculateContent, DispatcherPriority.DataBind); }
        private void CalculateContent()
        {
            if(Spec == null) return;
            if(Grid == null) return;

            if(Spec.Name == "_group_")
            {
                contentControl_ContentTemplate = LightGridResources.Instance.GroupColumnViewModelDataTemplate;
                contentControl_Content = Grid.GroupColumnViewModel;
            }
            else
            {
                contentControl_ContentTemplate = LightGridResources.Instance.ColumnSpecDataTemplate;
                contentControl_Content = Spec;
            }
        }

        private void BeginCalculateChainBorder() { Dispatcher.ThrottleInvoke(CalculateChainBorder, DispatcherPriority.DataBind); }
        private void CalculateChainBorder()
        {
            if (Spec == null) return;
            //if (Spec.Name == "_group_") return;
            if (Spec.DataType == null) return;

            if (Spec.IsColumnChained)
            {
                var color = Spec.ChainColor.HasValue ? new SolidColorBrush(Spec.ChainColor.Value):null;
                chainBorder.Background = color;
                chainBorder.BorderBrush = color;
                chainBorder.Visibility = Visibility.Visible;
            }
            else
            {
                chainBorder.Visibility = Visibility.Collapsed;
            }
        }

        private DataTemplate contentControl_ContentTemplate { get { return contentControl_contentTemplate; } set { if(contentControl_contentTemplate == value) return; contentControl_contentTemplate = value; contentControl.ContentTemplate = contentControl_contentTemplate; } } DataTemplate contentControl_contentTemplate;
        private object contentControl_Content { get { return contentControl_content; } set { if(contentControl_content == value) return; contentControl_content = value; contentControl.Content = contentControl_content; } } object contentControl_content;

        private void CalculateDependencies()
        {
            if(Spec == null) return;
            if(Grid == null) return;

            if(Grid.Spec.GroupingModeColumns.Grouped(Spec)) ZIndex = GridViewModel.LockedCellZIndex;
            else if(Spec.Locked) ZIndex = GridViewModel.LockedCellZIndex;
            else ZIndex = GridViewModel.CellZIndex;

            CalculateSplitterLeft();

            Left = Spec.Left;
            Width = Spec.Width;

            SelectionForeground = Spec.Selected ? Grid.SelectionForeground : Grid.HeaderForeground;
            HeaderFontSize = Grid.HeaderFontSize;
            HeaderFontFamily = Grid.HeaderFontFamily;
            HeaderFontStyle = Grid.HeaderFontStyle;
            HeaderFontWeight = Grid.HeaderFontWeight;
            HeaderFontStretch = Grid.HeaderFontStretch;

            border_Padding = false
                || Spec.Name == "_group_"
                || Spec.GroupedIndex == 1
                || (Grid.LockedColumnsCount == 0 && Grid.Columns.FirstOrDefault() == Spec && !Owner.HideMenuPanel)
                ? new Thickness(GridViewModel.GRID_MENU_ICON_SIZE, 0, 0, 0)
                : new Thickness(0, 0, 0, 0);

            border_Background = CalculateBrush(Spec, LightGridResources.Instance.HeaderBrush, LightGridResources.Instance.LockedHeaderColor, Grid.SelectionBackground);
        }
        private Color SelectionForeground { get { return selectionForeground; } set { if(selectionForeground == value) return; selectionForeground = value; SetValue(TextElement.ForegroundProperty, new SolidColorBrush(selectionForeground)); } } Color selectionForeground;
        private double HeaderFontSize { get { return headerFontSize; } set { if(headerFontSize == value) return; headerFontSize = value; SetValue(TextElement.FontSizeProperty, headerFontSize); } } double headerFontSize;
        private FontFamily HeaderFontFamily { get { return headerFontFamily; } set { if(headerFontFamily == value) return; headerFontFamily = value; SetValue(TextElement.FontFamilyProperty, headerFontFamily); } } FontFamily headerFontFamily;
        private FontStyle HeaderFontStyle { get { return headerFontStyle; } set { if(headerFontStyle == value) return; headerFontStyle = value; SetValue(TextElement.FontStyleProperty, headerFontStyle); } } FontStyle headerFontStyle;
        private FontWeight HeaderFontWeight { get { return headerFontWeight; } set { if(headerFontWeight == value) return; headerFontWeight = value; SetValue(TextElement.FontWeightProperty, headerFontWeight); } } FontWeight headerFontWeight;
        private FontStretch HeaderFontStretch { get { return headerFontStretch; } set { if(headerFontStretch == value) return; headerFontStretch = value; SetValue(TextElement.FontStretchProperty, headerFontStretch); } } FontStretch headerFontStretch;
        private Thickness border_Padding { get { return border_padding; } set { if(border_padding == value) return; border_padding = value; border.Padding = border_padding; } } private Thickness border_padding;
        private Brush border_Background { get { return border_background; } set { if(border_background == value) return; border_background = value; border.Background = border_background; } } private Brush border_background;

        private Brush CalculateBrush(ColumnSpec spec, Brush brush, Color lockColor, Color selectionColor)
        {
            var selected = spec.Selected;
            var grouped = Grid.Spec.GroupingModeColumns.Grouped(spec);
            var locked = spec.Locked;

            var columnInfo = GridHelper.CalculateColumnBackgroundHeader(brush, lockColor, selectionColor, selected,
                locked, grouped);

            if (selected || grouped || locked)
            {
                var key = new Key { First = columnInfo.Item1, Last = columnInfo.Item2 };

                if(!brushesCache.TryGetValue(key, out brush))
                {
                    brush = new LinearGradientBrush(key.First, key.Last, columnInfo.Item3);
                    brush.Freeze();
                    LinearGradientBrush eBrush = brush as LinearGradientBrush;
                    
                    brushesCache[key] = brush;
                }
            }

            return brush;
        }
        private static readonly Dictionary<Key, Brush> brushesCache = new Dictionary<Key, Brush>(); 
        private struct Key
        {
            public Color First;
            public Color Last;
        }



        public Geometry Rectangle(Rect rect)
        {
            if (rect != rectangleRect)
            {
                rectangleRect = rect;
                rectangleGeometry = new RectangleGeometry(rectangleRect);
            }

            return rectangleGeometry;
        }
        private Rect rectangleRect = new Rect(double.NaN, double.NaN, double.NaN, double.NaN);
        private RectangleGeometry rectangleGeometry;

        public GeometryDrawing CalculateIconChecked(Color foreground)
        {
            if (iconStyledChecked == null || ((SolidColorBrush) iconStyledChecked.Brush).Color != foreground)
                iconStyledChecked = new GeometryDrawing(new SolidColorBrush(foreground), LightGridCell.IconChecked.Pen, LightGridCell.IconChecked.Geometry);

            return iconStyledChecked;
        }
        private GeometryDrawing iconStyledChecked;

        public GeometryDrawing CalculateIconUnchecked(Color foreground)
        {
            if (iconStyledUnchecked == null || ((SolidColorBrush)iconStyledUnchecked.Pen.Brush).Color != foreground)
                iconStyledUnchecked = new GeometryDrawing(LightGridCell.IconUnchecked.Brush, new Pen(new SolidColorBrush(foreground), 1), LightGridCell.IconUnchecked.Geometry);

            return iconStyledUnchecked;
        }
        private GeometryDrawing iconStyledUnchecked;



        #region nested classes

        protected override System.Windows.Automation.Peers.AutomationPeer OnCreateAutomationPeer()
        {
            return new AutomationPeer(this);
        }
        private class AutomationPeer : System.Windows.Automation.Peers.FrameworkElementAutomationPeer
        {
            public AutomationPeer(LightGridColumnHeader owner) : base(owner)
            {
            }

            public new LightGridColumnHeader Owner { get { return (LightGridColumnHeader)base.Owner; } }

            protected override string GetClassNameCore()
            {
                return typeof(LightGridColumnHeader).Name;
            }
            protected override System.Windows.Automation.Peers.AutomationControlType GetAutomationControlTypeCore()
            {
                return System.Windows.Automation.Peers.AutomationControlType.DataItem;
            }
            protected override string GetAutomationIdCore()
            {
                var spec = Owner.Spec;

                return spec == null ? "ColumnHeader_" : "ColumnHeader_" + spec.Name;
            }
        }

        #endregion
    }
}
