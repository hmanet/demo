﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using Wells.Derivatives.Carina.Core.Metadata;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Presentation.CarinaDragDrop;
using Wells.Derivatives.Carina.Core.Presentation.CarinaDragDrop.Adorners;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridDragDropHandler : DragDropActions
    {
        public LightGridDragDropHandler()
        {
            HandlerAttachMode = AttachMode.Preview;

            ValidElementsToStartDrag.Add(typeof(LightGridCell), DataRowDrag);

            IsDataRowDragDisabled = false;
        }

        private DragInfo DataRowDrag(FrameworkElement dataRow, Point currentPosition)
        {
            var ourDragInfo = new DragInfo();

            if (!IsDataRowDragDisabled)
            {
                ourDragInfo.DataObject = new DataObject();
                ourDragInfo.VisualSource = dataRow;
                ourDragInfo.Effects = DragDropEffects.Move;
                var lightGrid = dataRow.FindParentObjectByType<LightGridPanel>();
                var activeNode = lightGrid.DataContext.Tree.ActiveNode;
                if (activeNode != null) ourDragInfo.DataObject.SetData(DragDropConstants.ROW_DATA, activeNode);
            }

            return ourDragInfo;
        }

        public override void DragDropValueChanged(object oldValue, object newValue)
        {
            InProcessDraggedObject = newValue;
        }

        internal override void Attach(GridViewModel gridViewModel)
        {
            ValidDropElements.Add(typeof(Popup), new ToolBarDropHandler());

            if (gridViewModel.EnableColumReordering)
            {
                ValidDropElements.Add(typeof(LightGridGridBarPanel), new ColumnDropHandler(gridViewModel.EnableColumReordering));
                ValidDropElements.Add(typeof(LightGridColumnHeader), new ColumnDropHandler(gridViewModel.EnableColumReordering));

                if(gridViewModel.EnableColumnsChange) ValidDropElements.Add(typeof(LightGridPanel), new GridDropHandler());
            }

            ValidDropElements.Add(typeof(LightGridCell), new DataRowDropHandler());
        }
        internal override void Detach(GridViewModel gridViewModel)
        {
            ValidDropElements.Remove(typeof (Popup));
            ValidDropElements.Remove(typeof(LightGridGridBarPanel));
            ValidDropElements.Remove(typeof(LightGridColumnHeader));
            ValidDropElements.Remove(typeof(LightGridPanel));
            ValidDropElements.Remove(typeof(LightGridCell));
        }
    }

    internal class ColumnDropHandler : DropHandler
    {
        private readonly DroppedColumnsBuilder builder;
        private readonly bool allowColumnChanges;
        public ColumnDropHandler(bool allowColumnChanges)
        {
            this.allowColumnChanges = allowColumnChanges;
            AcceptedDataTypes = new[] { DragDropConstants.ATTRIBUTE, DragDropConstants.DYNAMIC_ATTRIBUTE, DragDropConstants.COLUMNSPEC, DragDropConstants.DATA };
            CanDropFunc = () => Data.GetFormats().Any(f => AcceptedDataTypes.Contains(f));
            DropAction = a => OnDropColumns(a, this);
            ShowAdornerAction = () =>
            {
                var dragAction = KeyStates.HasFlag(DragDropKeyStates.ControlKey) ? ColumnDragAction.Copy : ColumnDragAction.Move;
                if (CurrentAdorner == null)
                {
                    {
                        var cell = DropOnElement as LightGridColumnHeader;
                        if (cell != null)
                        {
                            var gridControl = cell.Owner;
                            CurrentAdorner = new LightGridColumnAdorner(gridControl, builder.Build(), dragAction);
                            CurrentAdorner.ShowAdorner(DropPosition);
                        }
                    }
                    {
                        var cell = DropOnElement as LightGridGridBarPanel;
                        if (cell != null)
                        {
                            var gridControl = cell.Owner;
                            CurrentAdorner = new LightGridColumnAdorner(gridControl, builder.Build(), dragAction);
                            CurrentAdorner.ShowAdorner(DropPosition);
                        }
                    }
                }
                if (CurrentAdorner != null)
                {
                    ((LightGridColumnAdorner)CurrentAdorner).DragAction = dragAction;
                    CurrentAdorner.UpdatePosition(DropOnElement.TranslatePoint(DropPosition, CurrentAdorner.AdornedElement));
                }
            };
            builder = new DroppedColumnsBuilder(this);
        }

        private void OnDropColumns(bool inProcess, DropHandler columnDropHandler)
        {
            if (inProcess)
            {
                if (columnDropHandler.KeyStates == DragDropKeyStates.ControlKey && !allowColumnChanges) return;

                var columnHeader = columnDropHandler.DropOnElement as LightGridColumnHeader;
                if (columnHeader != null)
                {
                    var grid = columnHeader.Owner.GridPanel;
                    if (grid == null || grid.DataContext == null) return;

                    var position = new Point(columnDropHandler.DropPosition.X, columnDropHandler.DropPosition.Y);
                    var hitElement = (DependencyObject)columnHeader.InputHitTest(position);
                    if (hitElement == null) return;

                    var data = columnDropHandler.Data.GetData(DragDropConstants.DATA) as ColumnSpec[];
                    var addAction = columnDropHandler.KeyStates == DragDropKeyStates.ControlKey
                        ? AttributesAddAction.Copy
                        : data != null ? AttributesAddAction.MoveUnique : AttributesAddAction.Move;
                    var droppedColumns = builder.Build();

                    if (columnHeader.Spec.Name.Equals("_group_", StringComparison.InvariantCultureIgnoreCase))
                    {
                        var listBoxItem = hitElement.FindParentObjectByType<ListBoxItem>();
                        if (listBoxItem != null)
                        {
                            var columnSpec = (ColumnSpec)listBoxItem.DataContext;
                            var relativePoint = columnHeader.TranslatePoint(position, listBoxItem);

                            grid.DropColumns(columnSpec, relativePoint.X > listBoxItem.ActualWidth / 2, droppedColumns.Where(spec => spec.GroupedCanChange).ToList(), addAction);
                        }
                    }
                    else
                    {
                        grid.DropColumns(columnHeader.Spec, position.X > columnHeader.Width / 2, droppedColumns, addAction);
                    }
                    return;
                }

                var gridBar = columnDropHandler.DropOnElement as LightGridGridBarPanel;
                if (gridBar != null)
                {
                    var grid = gridBar.Owner.GridPanel;
                    if (grid == null || grid.DataContext == null) return;

                    var position = new Point(columnDropHandler.DropPosition.X, columnDropHandler.DropPosition.Y);
                    var hitElement = (DependencyObject)gridBar.InputHitTest(position) as FrameworkElement;
                    if (hitElement == null) return;

                    var data = columnDropHandler.Data.GetData(DragDropConstants.DATA) as ColumnSpec[];
                    var addAction = columnDropHandler.KeyStates == DragDropKeyStates.ControlKey
                        ? AttributesAddAction.Copy
                        : data != null ? AttributesAddAction.MoveUnique : AttributesAddAction.Move;
                    var droppedColumns = builder.Build();

                    var targetSpecElement = hitElement.FindDataContextHost(typeof(ColumnSpec));
                    if(targetSpecElement == null)
                    {
                        grid.DataContext.InsertColumns(null, false, droppedColumns.Where(spec => spec.GroupedCanChange).ToList(), addAction, GridViewModel.ColumnTypes.Group);
                    }
                    else
                    {
                        var targetSpec = (ColumnSpec)targetSpecElement.DataContext;
                        grid.DropColumns(targetSpec, targetSpecElement.PointFromScreen(gridBar.PointToScreen(position)).X > targetSpecElement.ActualWidth / 2, droppedColumns, addAction);
                    }
                }
            }
        }
    }

    internal class ToolBarDropHandler : DropHandler
    {
        private const string GROUP_ICON = "GroupIcon";
        private const string LOCK_ICON = "LockIcon";
        private const string MOVE_TO_FIRST_ICON = "MoveToFirstIcon";
        private const string MOVE_TO_LAST_ICON = "MoveToLastIcon";

        private readonly DroppedColumnsBuilder builder;
        public ToolBarDropHandler()
        {
            AcceptedDataTypes = new[] { DragDropConstants.ATTRIBUTE, DragDropConstants.DYNAMIC_ATTRIBUTE, DragDropConstants.COLUMNSPEC, DragDropConstants.DATA };
            CanDropFunc = () => Data.GetFormats().Any(f => AcceptedDataTypes.Contains(f));
            DropAction = a => OnDropColumns(a, this);
            builder = new DroppedColumnsBuilder(this);
        }

        private void OnDropColumns(bool inProcess, DropHandler columnDropHandler)
        {
            // columnDropHandler.DropPosition
            if (inProcess)
            {
                var popup = DropOnElement as Popup;
                var grid = popup.PlacementTarget as LightGrid ?? popup.PlacementTarget.FindParentObjectByType<LightGrid>();
                if (grid == null || grid.DataContext == null) return;
                var gridVM = grid.DataContext;

                var position = popup.PlacementTarget.TranslatePoint(columnDropHandler.DropPosition, popup.Child);
                var hitElement = (DependencyObject)popup.Child.InputHitTest(position);
                if (hitElement == null) return;

                var droppedOnElement = hitElement as Button ?? hitElement.FindParentObjectByType<Button>();
                if (droppedOnElement == null) return;

                var data = columnDropHandler.Data.GetData(DragDropConstants.DATA) as ColumnSpec[];
                var addAction = columnDropHandler.KeyStates == DragDropKeyStates.ControlKey
                    ? AttributesAddAction.Copy
                    : data != null ? AttributesAddAction.MoveUnique : AttributesAddAction.Move;
                var droppedColumns = builder.Build();

                switch (droppedOnElement.Name)
                {
                    case LOCK_ICON:
                    {
                        gridVM.InsertColumns(null, false, droppedColumns, addAction, GridViewModel.ColumnTypes.Lock);
                        break;
                    }
                    case GROUP_ICON:
                    {
                        if (gridVM.EnableGrouping) gridVM.InsertColumns(null, false, droppedColumns.Where(spec => spec.GroupedCanChange).ToList(), addAction, GridViewModel.ColumnTypes.Group);
                        break;
                    }
                    case MOVE_TO_FIRST_ICON:
                    {
                        var columns = gridVM.Spec.Columns;
                        var targetColumn = columns.FirstOrDefault(x => !x.Grouped && !x.Locked);

                        gridVM.InsertColumns(targetColumn, false, droppedColumns, addAction);
                        break;
                    }
                    case MOVE_TO_LAST_ICON:
                    {
                        var columns = gridVM.Spec.Columns;
                        var targetColumn = columns.Count == 0 ? null : columns[columns.Count -1];

                        gridVM.InsertColumns(targetColumn, true, droppedColumns, addAction);
                        break;
                    }
                }

                gridVM.ToolBarVisible = false;
            }
        }
    }

    internal class DroppedColumnsBuilder
    {
        private readonly DropHandler dropHandler;
        public DroppedColumnsBuilder(DropHandler handler)
        {
            dropHandler = handler;
        }

        public List<ColumnSpec> Build()
        {
            var droppedCols = new List<ColumnSpec>();

            var data = dropHandler.Data.GetData(DragDropConstants.DATA) as ColumnSpec[];
            if (data != null)
            {
                droppedCols.AddRange(data);
            }
            else
            {
                var colSpecs = DragDropActions.InProcessDraggedObject as IEnumerable<ColumnSpec>;
                if (colSpecs != null)
                {
                    droppedCols.AddRange(colSpecs);
                }
                else
                {
                    var attributes = DragDropActions.InProcessDraggedObject as IEnumerable<AttributeMetadata>;
                    if (attributes != null)
                    {
                        var popup = dropHandler.DropOnElement as Popup;
                        var element = popup != null ? popup.PlacementTarget : dropHandler.DropOnElement;
                        var gridControl = element.FindParentObjectByType<LightGrid>();
                        if (gridControl != null)
                        {
                            var gridSpec = gridControl.DataContext.Spec;
                            foreach (var attribute in attributes)
                            {
                                var column = gridSpec.Columns.FirstOrDefault(spec => spec.Key.Id == attribute.Key.Id);
                                if (column != null) droppedCols.Add(column);
                                else
                                {
                                    var attr = gridSpec.Attributes.First(m => m.Key.Id == attribute.Key.Id);
                                    droppedCols.Add(new ColumnSpec(attr) {CustomColumn = attr.CanSimulate && attr.Dynamic});
                                }
                            }
                        }
                    }
                }
            }

            return droppedCols;
        }
    }

    public class DataRowDropHandler : DropHandler
    {
        public DataRowDropHandler()
        {
            AcceptedDataTypes = new[] { DragDropConstants.ROW_DATA };
            CanDropFunc = () => Data.GetFormats().Any(f => AcceptedDataTypes.Contains(f) && Data.GetData(f) is TreeNodeModel);
            DropAction = a => ProcessDroppedData(a, this);
            ShowAdornerAction = () =>
            {
                if (CurrentAdorner == null)
                {
                    var cell = DropOnElement as LightGridCell;
                    if (cell != null)
                    {
                        var grid = cell.GridPanel;
                        CurrentAdorner = new DataRowAdorner(grid);
                        CurrentAdorner.ShowAdorner(DropPosition);
                    }
                }
                if (CurrentAdorner != null)
                    CurrentAdorner.UpdatePosition(DropOnElement.TranslatePoint(DropPosition, CurrentAdorner.AdornedElement));
            };
        }

        private void ProcessDroppedData(bool inProcess, DropHandler dropHandler)
        {
            if (!inProcess) return;

            var position = new Point(dropHandler.DropPosition.X, dropHandler.DropPosition.Y);
            var cell = DropOnElement as LightGridCell;
            if (cell != null)
            {
                if (cell.GridPanel != null && cell.TreeNode != null)
                    cell.GridPanel.DataContext.MoveSelectedNodes(cell.TreeNode.Model, position.Y < cell.Height / 2);
            }
        }
    }

    internal class GridDropHandler : DropHandler
    {
        public GridDropHandler()
        {
            AcceptedDataTypes = new[] { DragDropConstants.DATA };
            CanDropFunc = () => Data.GetFormats().Any(f => AcceptedDataTypes.Contains(f) && Data.GetData(f) is ColumnSpec[]);
            DropAction = a => OnDropColumns(a, this);
            ShowAdornerAction = () =>
            {
                if (CurrentAdorner == null)
                {
                    var gridControl = DropOnElement as LightGridPanel;
                    if (gridControl != null)
                    {
                        CurrentAdorner = new LightGridColumnAdorner(gridControl, gridControl.DataContext.Spec.SelectedColumns, ColumnDragAction.Remove);
                        CurrentAdorner.ShowAdorner(DropPosition);
                    }
                }
                if (CurrentAdorner != null)
                    CurrentAdorner.UpdatePosition(DropPosition);
            };
        }

        private void OnDropColumns(bool inProcess, DropHandler dropHandler)
        {
            var dataType = dropHandler.GetDataType();
            switch (dataType)
            {
                case DragDropConstants.DATA:
                    PublishDropValue(inProcess, dropHandler);
                    break;
            }
        }

        private void PublishDropValue(bool inProcess, DropHandler dropHandler)
        {
            if (!inProcess) return;

            var dropValues = dropHandler.Data.GetData(DragDropConstants.DATA) as ColumnSpec[];

            if (dropValues != null)
            {
                var grid = dropHandler.DropOnElement as LightGridPanel;
                if (grid != null) grid.DataContext.Spec.RemoveSelectedColumns();
            }
        }
    }
}
