﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGridCellEditorResources
    {
        public static readonly LightGridCellEditorResources Instance = new LightGridCellEditorResources();

        public ControlTemplate Template { get { return (ControlTemplate)this["cellEditorControlTemplate"]; } }
        public Brush EditorTextBoxColor { get { return (Brush)this["EditorTextBoxColor"]; } }

        public LightGridCellEditorResources()
        {
            InitializeComponent();
        }

        private void Border_Loaded(object sender, RoutedEventArgs e)
        {
            var sv = (ScrollViewer)sender;

            sv.Margin = sv.Padding = new Thickness();
        }
    }
}
