﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridColumnHeadersPanel : Canvas
    {
        static LightGridColumnHeadersPanel()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridColumnHeadersPanel), new FrameworkPropertyMetadata((d, a) => ((LightGridColumnHeadersPanel)d).OnDataContextChanged((GridViewModel)a.OldValue, (GridViewModel)a.NewValue), (d, v) => v as GridViewModel));
        }

        public new GridViewModel DataContext { get { return dataContext; } set { base.DataContext = value; } } private GridViewModel dataContext;
        private void OnDataContextChanged(GridViewModel oldValue, GridViewModel newValue)
        {
            dataContext = newValue;
        }


        #region nested classes

        public class Thumb : System.Windows.Controls.Primitives.Thumb
        {
            public Thumb()
            {
                Cursor = Cursors.SizeWE;

                IsEnabled = false;
                ZIndex = GridViewModel.SeparatorZIndex;

                DragStarted += OnDragStarted;
                DragDelta += OnDragDelta;
                DragCompleted += OnDragCompleted;

                Template = LightGridResources.Instance.SplitterTemplate;
            }


            public GridViewModel Grid { get; set; }

            public ColumnSpec Spec
            {
                get { return spec; }
                set
                {
                    if(spec == value) return;

                    spec = value;

                    IsEnabled = spec != null;
                }
            }
            private ColumnSpec spec;


            public int ZIndex { get { return zIndex; } set { if(zIndex == value) return; zIndex = value; Canvas.SetZIndex(this, value); } } private int zIndex;

            public double Left { get { return left; } set { if(left == value) return; left = value; Canvas.SetLeft(this, value); } } private double left;


            private void OnDragStarted(object sender, DragStartedEventArgs e)
            {
                if (Spec.FixedWidth) return;
                dragSpec = Spec;

                Grid.ResizingColumns = true;
            }

            private void OnDragDelta(object sender, DragDeltaEventArgs args)
            {
                if (Spec.FixedWidth) return;

                var x = Mouse.GetPosition(this).X;
                var diff = x - ActualWidth;
                if (dragSpec.Width + diff < ColumnSpec.MinWidth) diff = ColumnSpec.MinWidth - dragSpec.Width;

                dragSpec.Width += diff;
            }
            private ColumnSpec dragSpec;

            private void OnDragCompleted(object sender, DragCompletedEventArgs e)
            {
                if (Spec.FixedWidth) return;

                Grid.ResizingColumns = false;

                dragSpec = null;
            }

            // AutoFit
            protected override void OnPreviewMouseDoubleClick(MouseButtonEventArgs e)
            {
                if (Spec == null) return;

                if (Spec.FixedWidth) return;

                var controlPressed = Keyboard.Modifiers.Equals(ModifierKeys.Control);
                var fitToUse = controlPressed ? Grid.AlternativeAutoFitUnit : Grid.DefaultAutoFitUnit;
                    
                if (Spec.Selected)
                {
                    foreach (var next in Grid.Spec.GroupingModeColumns.SelectedColumns)
                        next.Width = Grid.CalculateWidth(next, fitToUse);
                }
                else
                {
                    Spec.Width = Grid.CalculateWidth(Spec, fitToUse);
                }

                if (fitToUse == GridViewModel.FitUnits.Header)
                {
                    var first = Grid.Spec.GroupingModeColumns.VisibleColumns.FirstOrDefault();

                    if (first != null && (Spec.Selected && Grid.Spec.GroupingModeColumns.SelectedColumns.Contains(first) || Spec == first))
                        first.Width += GridViewModel.GRID_MENU_ICON_SIZE;
                }
            }
        }

        #endregion
    }
}
