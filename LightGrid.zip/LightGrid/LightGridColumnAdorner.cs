﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using Wells.Derivatives.Carina.Core.Presentation.CarinaDragDrop.Adorners;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    internal class LightGridColumnAdorner : CarinaDragDropAdorner
    {
        private const double EM_SIZE = 12;
        private const int ICON_OFFSET = 3;
        private const string FONT_NAME = "Calibri";
        private const double ADORNER_OPACITY = 0.7;
        private const string DELETE_ICON = "iconDelete";
        private const string MOVE_ICON = "iconMoveHorizontal";
        private const string COPY_ICON = "iconCopyItem";
        private const string BACKGROUND_BRUSH = "columnManagerCellBrush";

        private static readonly Typeface typeface;
        private static readonly Brush foregroundBrush;
        private static readonly Brush backgroundBrush;
        private static readonly Pen rectBorderPen;
        private static readonly Pen columnInsertPen;
        private static readonly ImageSource iconDelete;
        private static readonly ImageSource iconMove;
        private static readonly ImageSource iconCopy;

        static LightGridColumnAdorner()
        {
            typeface = new Typeface(FONT_NAME);

            foregroundBrush = Brushes.Black;
            foregroundBrush.Freeze();

            var brush = (Brush)Application.Current.FindResource(BACKGROUND_BRUSH);
            backgroundBrush = brush.CloneCurrentValue();
            backgroundBrush.Opacity = ADORNER_OPACITY;
            backgroundBrush.Freeze();

            rectBorderPen = new Pen(Brushes.DarkGray, 1);
            rectBorderPen.Freeze();

            columnInsertPen = new Pen(Brushes.Blue, 4);
            columnInsertPen.Freeze();

            iconDelete = IconSource.ConvertResourceToImageSource(DELETE_ICON);
            iconMove = IconSource.ConvertResourceToImageSource(MOVE_ICON);
            iconCopy = IconSource.ConvertResourceToImageSource(COPY_ICON);
        }

        internal LightGridColumnAdorner(UIElement gridElement, IEnumerable<ColumnSpec> columns, ColumnDragAction columnDragAction = ColumnDragAction.Move)
            : base(gridElement)
        {
            columnNames = columns.StringJoin(" | ", x => x.Metadata.Label);
            DragAction = columnDragAction;
        }
        private readonly string columnNames;
        public ColumnDragAction DragAction { get; set; }

        public override void ShowAdorner(Point currentPosition)
        {
            ValidAdornerLayer = AdornerLayer.GetAdornerLayer(AdornedElement);
            ValidAdornerLayer.Add(this);
            IsHitTestVisible = false;
        }

        public override void HideAdorner()
        {
            ValidAdornerLayer.Remove(this);
        }

        protected override void OnRender(DrawingContext drawingContext)
        {
            if (string.IsNullOrEmpty(columnNames)) return;
            var hitElement = AdornedElement.InputHitTest(CurrentPoint) as FrameworkElement;
            if (hitElement == null) return;

            // Column names
            var position = AdornedElement.TranslatePoint(CurrentPoint, AdornedElement);
            var formattedText = new FormattedText(columnNames, CultureInfo.InvariantCulture, FlowDirection.LeftToRight, typeface, EM_SIZE, foregroundBrush);
            var textPosition = new Point(position.X - formattedText.Width / 2, position.Y - formattedText.Height);
            var rectPosition = new Point(textPosition.X - 2, textPosition.Y - 2);
            var rect = new Rect(rectPosition, new Size(formattedText.Width + 4, formattedText.Height + 4));
            drawingContext.DrawRectangle(backgroundBrush, rectBorderPen, rect);
            drawingContext.DrawText(formattedText, textPosition);

            // Icon to indicate drag action.
            var icon = GetIcon(DragAction);
            var iconArea = new Rect(rect.X + rect.Width + ICON_OFFSET, rect.Y, icon.Width, icon.Height);
            drawingContext.DrawImage(icon, iconArea);

            // Column insert indicator
            var cellElement = (DependencyObject)AdornedElement.InputHitTest(position);
            var cell = hitElement as LightGridColumnHeader ?? cellElement.FindParentObjectByType<LightGridColumnHeader>();
            if (cell != null)
            {
                FrameworkElement targetElement = cell;
                if (cell.Spec.Name.Equals("_group_", StringComparison.InvariantCultureIgnoreCase))
                    targetElement = hitElement.FindParentObjectByType<ListBoxItem>();

                if (targetElement == null) return;

                var targetPosition = targetElement.TransformToAncestor(AdornedElement).Transform(new Point());
                var relativeDropPosition = AdornedElement.TranslatePoint(position, targetElement);
                // Adjust xPosition based on insert before or after.
                var xPosition = targetPosition.X + (relativeDropPosition.X > targetElement.ActualWidth / 2 ? targetElement.ActualWidth : 0);

                drawingContext.DrawLine(columnInsertPen, new Point(xPosition, targetPosition.Y), new Point(xPosition, targetPosition.Y + targetElement.ActualHeight));
            }
        }

        private ImageSource GetIcon(ColumnDragAction columnDragAction)
        {
            ImageSource imageSource = null;
            switch (columnDragAction)
            {
                case ColumnDragAction.Remove: imageSource = iconDelete; break;
                case ColumnDragAction.Move: imageSource = iconMove; break;
                case ColumnDragAction.Copy: imageSource = iconCopy; break;
            }
            return imageSource;
        }
    }

    internal enum ColumnDragAction
    {
        Copy,
        Move,
        Remove
    }
}
