﻿using System;
using System.Windows.Controls;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class ThinGridResources
    {
        public static readonly ThinGridResources Instance = new ThinGridResources();

        public ControlTemplate ThinGridControlTemplate { get { return (ControlTemplate)this["ThinGridControlTemplate"]; } }

        public ControlTemplate ThinGridTemplate { get { return (ControlTemplate)this["ThinGridTemplate"]; } }

        public ThinGridResources()
        {
            InitializeComponent();
        }
    }

    //just for resource related code
    public partial class ThinGridControl
    {
    }
}
