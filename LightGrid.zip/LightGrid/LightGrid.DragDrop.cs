﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Threading;
using Wells.Derivatives.Carina.Core.Presentation.CarinaDragDrop;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Threading;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGrid
    {
        public class LightDragDrop : IDisposable
        {
            public LightDragDrop(FrameworkElement target)
            {
                this.target = target;

                target.PreviewMouseLeftButtonDown += target_PreviewMouseLeftButtonDown;
                target.PreviewDragOver += target_PreviewDragOver;

                stopAccelerationDelayedAction
                    .Action(StopSpeedAcceleration)
                    .Dispatcher(this.target.Dispatcher);
            }
            private readonly FrameworkElement target;


            /// <summary>
            /// Add areas that should initiate drag/drop
            /// </summary>
            public readonly List<Area> DragAreas = new List<Area>();

            /// <summary>
            /// Add areas that should be invoked when hovering
            /// </summary>
            public readonly List<Area> HoverAreas = new List<Area>();

            /// <summary>
            /// Add areas that should be invoke when dropping
            /// </summary>
            public readonly List<Area> DropAreas = new List<Area>();


            public double MaxSpeed = 100;
            public double Speed { get; private set; }

            public void StartSpeedAcceleration()
            {
                if (Speed == 0)
                {
                    speedMilliseconds = (DateTime.Now - DateTime.MinValue).Ticks;
                    Speed = 1;
                }

                stopAccelerationDelayedAction.Start();

                var newMilliseconds = (DateTime.Now - DateTime.MinValue).Ticks;
                if(newMilliseconds - speedMilliseconds > TimeSpan.FromMilliseconds(100).Ticks)
                {
                    speedMilliseconds += TimeSpan.FromMilliseconds(100).Ticks;

                    Speed = Math.Min(Speed * 1.1, MaxSpeed);
                }
            }
            public void StopSpeedAcceleration()
            {
                if(Speed == 0) return;

                Speed = 0;

                stopAccelerationDelayedAction.Stop();
            }
            private long speedMilliseconds;
            private readonly DelayedAction stopAccelerationDelayedAction = Delayed.Delay(400);


            public event Action<Point, DragEventArgs> Hover;
            private void OnHover(Point screenPosition, DragEventArgs args)
            {
                var evt = Hover;
                if (evt != null) evt(screenPosition, args);
            }

            private void target_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs args)
            {
                HookHoverEvents();

                startPosition = args.GetPosition(target);
            }
            private void target_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs args) { UnhookHoverEvents(); }
            private static readonly Point infinityPosition = new Point(double.NegativeInfinity, double.NegativeInfinity);
            private Point startPosition = infinityPosition;

            private void target_PreviewMouseMove(object sender, MouseEventArgs args)
            {
                if (args.LeftButton != MouseButtonState.Pressed || Mouse.Captured != null || startPosition == infinityPosition)
                {
                    startPosition = infinityPosition;
                    UnhookHoverEvents();
                    return;
                }

                var position = args.GetPosition(target);

                if (OutsideTolerance(startPosition - position) == false)
                    return;

                var screenPosition = target.PointToScreen(position);

                var handled = false;
                foreach(var next in DragAreas)
                {
                    next.Drag(target, screenPosition, ref handled);

                    if (handled)
                    {
                        OnDragEnded();
                        break;
                    }
                }

                ScrollContinuously(target.PointToScreen(position), args);
            }
            private void target_PreviewDragOver(object sender, DragEventArgs args)
            {
                var position = args.GetPosition(target);
                var screenPosition = target.PointToScreen(position);

                Scroll(screenPosition, args);
            }

            private void HookHoverEvents()
            {
                target.PreviewMouseLeftButtonUp += target_PreviewMouseLeftButtonUp;
                target.PreviewMouseMove += target_PreviewMouseMove;
            }
            private void UnhookHoverEvents()
            {
                target.PreviewMouseLeftButtonUp -= target_PreviewMouseLeftButtonUp;
                target.PreviewMouseMove -= target_PreviewMouseMove;
            }
            private void Scroll(Point screenPosition, DragEventArgs args)
            {
                if(scrollTimer != null) scrollTimer.Stop();

                target_Hover(screenPosition, args);
            }
            private void ScrollContinuously(Point screenPosition, MouseEventArgs e)
            {
                scrollPosition = screenPosition;

                if (scrollTimer == null)
                {
                    scrollTimer = new DispatcherTimer(TimeSpan.FromMilliseconds(100), DispatcherPriority.Input, (s, a) =>
                    {
                        if (scrollPosition != target.PointToScreen(e.GetPosition(target)))
                        {
                            scrollTimer.Stop();
                            return;
                        }

                        target_Hover(scrollPosition, null);
                    }, target.Dispatcher);
                }

                scrollTimer.Start();

                target_Hover(scrollPosition, null);
            }
            private DispatcherTimer scrollTimer;
            private Point scrollPosition;

            private void target_Hover(Point screenPosition, DragEventArgs args)
            {
                //data format has to come from the area itself
                var data = args == null ? null : args.Data.GetData("Carina.Data");

                var handled = false;
                foreach (var next in HoverAreas)
                {
                    next.Hover(target, data, screenPosition, ref handled);

                    if (handled) break;
                }

                OnHover(screenPosition, args);
            }


            private bool OutsideTolerance(Vector diff) { return Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance || Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance; }


            public Action DragEnded;
            private void OnDragEnded()
            {
                var evt = DragEnded;
                if(evt != null) evt();
            }
            private static void DoDrag(object payload, FrameworkElement source)
            {
                var dragInfo = new DragInfo { DataObject = new DataObject(), VisualSource = source, Effects = DragDropEffects.Move };

                dragInfo.DataObject.SetData(DragDropConstants.PROCESSID, Process.GetCurrentProcess().Id);
                dragInfo.DataObject.SetData(DragDropConstants.DATA, payload);

                System.Windows.DragDrop.DoDragDrop(source, dragInfo.DataObject, dragInfo.Effects);
            }


            public void Dispose()
            {
                UnhookHoverEvents();
            }


            public abstract class Area
            {
                protected Area(Func<FrameworkElement, Point, object> drag, Func<object, Point, bool> hover = null, Func<object, Point, bool> drop = null)
                {
                    DragDelegate = drag;
                    HoverDelegate = hover;
                    DropDelegate = drop;
                }

                public abstract void Drag(FrameworkElement target, Point screenPosition, ref bool handled);
                public Func<FrameworkElement, Point, object> DragDelegate { get; private set; }

                public abstract void Hover(FrameworkElement target, object data, Point screenPosition, ref bool handled);
                public Func<object, Point, bool> HoverDelegate { get; private set; }

                public abstract void Drop(object data, Point screenPosition, ref bool handled);
                public Func<object, Point, bool> DropDelegate { get; private set; }
            }
            public class RectArea : Area
            {
                public readonly Rect Rect;
                public readonly HorizontalAlignment HorizontalAlignment;
                public readonly VerticalAlignment VerticalAlignment;

                public FrameworkElement Target { get; private set; }

                public RectArea(FrameworkElement target, Rect rect, HorizontalAlignment ha, VerticalAlignment va, Func<FrameworkElement, Point, object> drag = null, Func<object, Point, bool> hover = null, Func<object, Point, bool> drop = null)
                    : base(drag, hover, drop)
                {
                    Target = target;

                    Rect = rect;
                    HorizontalAlignment = ha;
                    VerticalAlignment = va;
                }

                public override void Drag(FrameworkElement target, Point screenPosition, ref bool handled)
                {
                    if (DragDelegate == null) return;
                }
                public override void Hover(FrameworkElement target, object data, Point screenPosition, ref bool handled)
                {
                    if (HoverDelegate == null) return;

                    var position = Target.PointFromScreen(screenPosition);
                    var targetSurface = new Size(Target.ActualWidth, Target.ActualHeight);

                    if (!CalculateRect(targetSurface).Contains(position)) return;

                    if (HoverDelegate(data, position)) handled = true;
                }
                public override void Drop(object data, Point screenPosition, ref bool handled)
                {
                    if (DropDelegate == null) return;

                    var position = Target.PointFromScreen(screenPosition);
                    var targetSurface = new Size(Target.ActualWidth, Target.ActualHeight);

                    if (!CalculateRect(targetSurface).Contains(position)) return;

                    if (DropDelegate != null) if (DropDelegate(data, position)) handled = true;
                }


                private Rect CalculateRect(Size targetSurface)
                {
                    var rect = Rect;

                    switch (HorizontalAlignment)
                    {
                        case HorizontalAlignment.Left: break;
                        case HorizontalAlignment.Right: rect.X = targetSurface.Width - Rect.X - Rect.Width; break;
                        case HorizontalAlignment.Stretch: rect.X = Rect.X; rect.Width = targetSurface.Width - Rect.Width; break;
                        default: throw new NotImplementedException();
                    }
                    switch (VerticalAlignment)
                    {
                        case VerticalAlignment.Top: break;
                        case VerticalAlignment.Bottom: rect.Y = targetSurface.Height - Rect.Y - Rect.Height; break;
                        case VerticalAlignment.Stretch: rect.Y = rect.Y; rect.Height = targetSurface.Height - Rect.Height; break;
                        default: throw new NotImplementedException();
                    }

                    return rect;
                }
            }
            public class FrameworkElementArea : Area
            {
                public FrameworkElementArea(FrameworkElement frameworkElement, Func<FrameworkElement, Point, object> drag = null, Func<object, Point, bool> hover = null, Func<object, Point, bool> drop = null)
                    : base(drag, hover, drop)
                {
                    FrameworkElement = frameworkElement;
                }

                public FrameworkElement FrameworkElement { get; private set; }


                public override void Drag(FrameworkElement target, Point screenPosition, ref bool handled)
                {
                    if(DragDelegate == null) return;
                }
                public override void Hover(FrameworkElement target, object data, Point screenPosition, ref bool handled)
                {
                    var frameworkElement = FrameworkElement is Popup ? (FrameworkElement)((Popup)FrameworkElement).Child : FrameworkElement;

                    if(frameworkElement.IsVisible == false)
                        return;
                    if (HoverDelegate == null)
                        return;

                    var position = frameworkElement.PointFromScreen(screenPosition);
                    var targetSurface = new Size(frameworkElement.ActualWidth, frameworkElement.ActualHeight);

                    if (!CalculateRect(targetSurface).Contains(position)) return;

                    if (HoverDelegate(data, position)) handled = true;
                }
                public override void Drop(object data, Point screenPosition, ref bool handled)
                {
                    if (DropDelegate == null) return;
                }


                private Rect CalculateRect(Size targetSurface)
                {
                    return new Rect(new Point(), targetSurface);
                }
            }
            public class DataContextTypeArea : Area
            {
                public DataContextTypeArea(Type dataContextType, Func<FrameworkElement, Point, object> drag = null, Func<object, Point, bool> hover = null, Func<object, Point, bool> drop = null)
                    : base(drag, hover, drop)
                {
                    DataContextType = dataContextType;
                }

                public Type DataContextType { get; private set; }


                public override void Drag(FrameworkElement target, Point screenPosition, ref bool handled)
                {
                    if(DragDelegate == null) return;

                    var position = target.PointFromScreen(screenPosition);

                    var hit = target.InputHitTest(position) as FrameworkElement;
                    if(hit == null) return;

                    var visual = hit.FindDataContextHost(DataContextType) as FrameworkElement;
                    if(visual == null) return;

                    var payload = DragDelegate(visual, position);
                    if(payload == null) return;

                    DoDrag(payload, visual);
                    handled = true;
                }
                public override void Hover(FrameworkElement target, object data, Point screenPosition, ref bool handled)
                {
                    if(HoverDelegate == null) return;
                }
                public override void Drop(object data, Point screenPosition, ref bool handled)
                {
                    if (DropDelegate == null) return;
                }
            }
            public class FrameworkElementTypeArea : Area
            {
                public FrameworkElementTypeArea(Type frameworkElementType, Func<FrameworkElement, Point, object> drag = null, Func<object, Point, bool> hover = null, Func<object, Point, bool> drop = null)
                    : base(drag, hover, drop)
                {
                    FrameworkElementType = frameworkElementType;
                }

                public Type FrameworkElementType { get; private set; }


                public override void Drag(FrameworkElement target, Point screenPosition, ref bool handled)
                {
                    if(DragDelegate == null) return;

                    var position = target.PointFromScreen(screenPosition);

                    var hit = target.InputHitTest(position) as DependencyObject;
                    if(hit == null) return;

                    var visual = (hit.GetType().Is(FrameworkElementType) ? hit : hit.FindParent(FrameworkElementType)) as FrameworkElement;
                    if(visual == null) return;

                    var payload = DragDelegate(visual, position);
                    if(payload == null) return;

                    DoDrag(payload, visual);
                    handled = true;
                }
                public override void Hover(FrameworkElement target, object data, Point screenPosition, ref bool handled)
                {
                    if(HoverDelegate == null) return;
                }
                public override void Drop(object data, Point screenPosition, ref bool handled)
                {
                    if (DropDelegate == null) return;
                }
            }
        }
    }
}
