﻿using System;
using System.Windows;
using System.Windows.Controls;
using Wells.Derivatives.Carina.Core.Presentation.Grid;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridColumnHeader_SortButton : Button
    {
        static LightGridColumnHeader_SortButton()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridColumnHeader_SortButton), new FrameworkPropertyMetadata(null, (d, v) => v as ColumnSpec));
        }

        public new ColumnSpec DataContext { get { return (ColumnSpec)base.DataContext;; } set { base.DataContext = value; } }


        #region nested classes

        protected override System.Windows.Automation.Peers.AutomationPeer OnCreateAutomationPeer()
        {
            return new AutomationPeer(this);
        }
        private class AutomationPeer : System.Windows.Automation.Peers.FrameworkElementAutomationPeer
        {
            public AutomationPeer(LightGridColumnHeader_SortButton owner) : base(owner)
            {
            }

            public new LightGridColumnHeader_SortButton Owner { get { return (LightGridColumnHeader_SortButton)base.Owner; } }

            protected override string GetClassNameCore()
            {
                return typeof(LightGridColumnHeader_SortButton).Name;
            }
            protected override System.Windows.Automation.Peers.AutomationControlType GetAutomationControlTypeCore()
            {
                return System.Windows.Automation.Peers.AutomationControlType.DataItem;
            }
            protected override string GetAutomationIdCore()
            {
                return "Sort";
            }
        }

        #endregion
    }
}
