﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Media;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class ThinGridTrigger : DependencyObject
    {
        public static readonly DependencyProperty InvertConditionProperty = DependencyProperty.Register("InvertCondition", typeof(bool), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public bool InvertCondition { get { return (bool)GetValue(InvertConditionProperty); } set { SetValue(InvertConditionProperty, value); } }

        public static readonly DependencyProperty TriggerAttributeProperty = DependencyProperty.Register("TriggerAttribute", typeof(string), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public string TriggerAttribute { get { return (string)GetValue(TriggerAttributeProperty); } set { SetValue(TriggerAttributeProperty, value); } }

        public static readonly DependencyProperty TargetAttributeProperty = DependencyProperty.Register("TargetAttribute", typeof(string), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public string TargetAttribute { get { return (string)GetValue(TargetAttributeProperty); } set { SetValue(TargetAttributeProperty, value); } }

        public static readonly DependencyProperty NameProperty = DependencyProperty.Register("Name", typeof(string), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public string Name { get { return (string)GetValue(NameProperty); } set { SetValue(NameProperty, value); } }

        public static readonly DependencyProperty EditableProperty = DependencyProperty.Register("Editable", typeof(bool), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public bool Editable { get { return (bool)GetValue(EditableProperty); } set { SetValue(EditableProperty, value); } }

        public static readonly DependencyProperty VisibleProperty = DependencyProperty.Register("Visible", typeof(bool), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public bool Visible { get { return (bool)GetValue(VisibleProperty); } set { SetValue(VisibleProperty, value); } }
        public static readonly DependencyProperty StrikethroughProperty = DependencyProperty.Register("Strikethrough", typeof(bool), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public bool Strikethrough { get { return (bool)GetValue(StrikethroughProperty); } set { SetValue(StrikethroughProperty, value); } }

        public static readonly DependencyProperty UnderlineProperty = DependencyProperty.Register("Underline", typeof(bool), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public bool Underline { get { return (bool)GetValue(UnderlineProperty); } set { SetValue(UnderlineProperty, value); } }

        public static readonly DependencyProperty HorizontalAlignmentProperty = DependencyProperty.Register("HorizontalAlignment", typeof(bool), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public HorizontalAlignment HorizontalAlignment { get { return (HorizontalAlignment)GetValue(HorizontalAlignmentProperty); } set { SetValue(HorizontalAlignmentProperty, value); } }

        public static readonly DependencyProperty BackgroundProperty = DependencyProperty.Register("Background", typeof(Color), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public Color Background { get { return (Color)GetValue(BackgroundProperty); } set { SetValue(BackgroundProperty, value); } }
        public static readonly DependencyProperty ForegroundProperty = DependencyProperty.Register("Foreground", typeof(Color), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public Color Foreground { get { return (Color)GetValue(ForegroundProperty); } set { SetValue(ForegroundProperty, value); } }
        public static readonly DependencyProperty FontFamilyProperty = DependencyProperty.Register("FontFamily", typeof(FontFamily), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public FontFamily FontFamily { get { return (FontFamily)GetValue(FontFamilyProperty); } set { SetValue(FontFamilyProperty, value); } }
        public static readonly DependencyProperty FontWeightProperty = DependencyProperty.Register("FontWeight", typeof(FontWeight), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public FontWeight FontWeight { get { return (FontWeight)GetValue(FontWeightProperty); } set { SetValue(FontWeightProperty, value); } }
        public static readonly DependencyProperty FontStyleProperty = DependencyProperty.Register("FontStyle", typeof(FontStyle), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public FontStyle FontStyle { get { return (FontStyle)GetValue(FontStyleProperty); } set { SetValue(FontStyleProperty, value); } }
        public static readonly DependencyProperty FontSizeProperty = DependencyProperty.Register("FontSize", typeof(double), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public double FontSize { get { return (double)GetValue(FontSizeProperty); } set { SetValue(FontSizeProperty, value); } }
        public static readonly DependencyProperty DelayProperty = DependencyProperty.Register("Delay", typeof(TimeSpan), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public TimeSpan Delay { get { return (TimeSpan)GetValue(DelayProperty); } set { SetValue(DelayProperty, value); } }
        public static readonly DependencyProperty BlendBackgroundProperty = DependencyProperty.Register("BlendBackground", typeof(bool), typeof(ThinGridTrigger), new PropertyMetadata(null));
        public bool BlendBackground { get { return (bool)GetValue(BlendBackgroundProperty); } set { SetValue(BlendBackgroundProperty, value); } }
    }

    public class ThinGridTriggerCollection : ObservableCollection<ThinGridTrigger>
    {
    }
}
