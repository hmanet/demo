﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.Grid.Superscript;
using Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridCell : FrameworkElement
    {
        private static readonly GeometryDrawing iconExpanded;
        private static readonly GeometryDrawing iconCollapsed;
        private static readonly GeometryDrawing iconDragBorder;
        private static readonly GeometryDrawing iconDragFill;
        private static readonly GeometryDrawing iconReadOnlyChecked;
        private static readonly GeometryDrawing iconReadOnlyUnchecked;
        private static readonly GeometryDrawing iconReadOnlyIntermediate;
        public static readonly GeometryDrawing IconChecked;
        public static readonly GeometryDrawing IconUnchecked;
        private static readonly GeometryDrawing iconIntermediate;
        private static readonly GeometryDrawing iconOverriddenChecked;
        private static readonly GeometryDrawing iconOverriddenUnchecked;


        static LightGridCell()
        {
            var iconBrush = new SolidColorBrush(Colors.Black); iconBrush.Freeze();
            var iconBrushNone = new SolidColorBrush(Color.FromArgb(50, 125, 125, 0)); iconBrushNone.Freeze();
            var iconBrushUnCheckedOverriden = new SolidColorBrush(Color.FromArgb(255, 100, 180, 255)); iconBrushUnCheckedOverriden.Freeze();
            var iconBrushReadOnly = new SolidColorBrush(Colors.Gray); iconBrushReadOnly.Freeze();
            var iconBrushOverridden = new SolidColorBrush(GridViewModel.ForegroundOverridden); iconBrushOverridden.Freeze();

            var iconPen = new Pen(Brushes.Black, 1); iconPen.Freeze();
            var iconPenNone = new Pen(Brushes.Black, 0); iconPenNone.Freeze();
            var iconPenReadOnly = new Pen(Brushes.Gray, 1); iconPenReadOnly.Freeze();
            var iconPenOverridden = new Pen(Brushes.Blue, 1); iconPenOverridden.Freeze();
            var iconPenBorder = new Pen(Brushes.White, GridViewModel.IconDragBorderSize); iconPen.Freeze();

            iconExpanded = new GeometryDrawing(iconBrushNone, iconPen, Geometry.Parse("M 0,0 L 0,10 10,10 10,0 Z M 1,5 H8").Clone()); iconExpanded.Freeze();
            iconCollapsed = new GeometryDrawing(iconBrushNone, iconPen, Geometry.Parse("M 0,0 L 0,10 10,10 10,0 Z M 5,1 V8 M 1,5 H8").Clone()); iconCollapsed.Freeze();

            iconDragBorder = new GeometryDrawing(iconBrush, iconPenBorder, Geometry.Parse("M 0,0 L 0," + GridViewModel.IconDragBorderSize + " " + GridViewModel.IconDragBorderSize + "," + GridViewModel.IconDragBorderSize + " " + GridViewModel.IconDragBorderSize + ",0 Z").Clone()); iconDragBorder.Freeze();
            iconDragFill = new GeometryDrawing(iconBrush, iconPen, Geometry.Parse("M 0,0 L 0," + GridViewModel.IconDragFillSize + " " + GridViewModel.IconDragFillSize + "," + GridViewModel.IconDragFillSize + " " + GridViewModel.IconDragFillSize + ",0 Z").Clone()); iconDragFill.Freeze();

            var checkPath = Geometry.Parse("M10.622,3.614 L9.208,2.2 4.084,7.324 2.294,5.536 0.88,6.95 4.084,10.152 4.624,9.612 z M0,12 L12,12 12,2.3692935E-08 0.064516129,2.3692935E-08 z");
            iconReadOnlyChecked = new GeometryDrawing(iconBrushReadOnly, iconPenNone, checkPath); iconReadOnlyChecked.Freeze();
            IconChecked = new GeometryDrawing(iconBrush, iconPenNone, checkPath); IconChecked.Freeze();
            iconOverriddenChecked = new GeometryDrawing(iconBrushOverridden, iconPenNone, checkPath); iconOverriddenChecked.Freeze();

            var uncheckPath = Geometry.Parse("M0.875,12.3125 L12.5,12.3125 12.5,0.6255 0.9375,0.6255 z");
            iconReadOnlyUnchecked = new GeometryDrawing(iconBrushNone, iconPenReadOnly, uncheckPath); iconReadOnlyUnchecked.Freeze();
            IconUnchecked = new GeometryDrawing(iconBrushNone, iconPen, uncheckPath); IconUnchecked.Freeze();
            iconOverriddenUnchecked = new GeometryDrawing(iconBrushUnCheckedOverriden, iconPenOverridden, uncheckPath); iconOverriddenUnchecked.Freeze();

            iconReadOnlyIntermediate = new GeometryDrawing(iconBrushReadOnly, iconPenReadOnly, uncheckPath); iconReadOnlyIntermediate.Freeze();
            iconIntermediate = new GeometryDrawing(iconBrush, iconPen, uncheckPath); iconIntermediate.Freeze();
        }
        public LightGridCell(LightGridPanel gridPanel)
        {
            Model = new CellViewModel(gridPanel.DataContext);

            GridPanel = gridPanel;

            UseLayoutRounding = true;
            SnapsToDevicePixels = true;

            RenderOptions.SetBitmapScalingMode(this, BitmapScalingMode.Linear);
            RenderOptions.SetEdgeMode(this, EdgeMode.Aliased);
            RenderOptions.SetClearTypeHint(this, ClearTypeHint.Enabled);
            TextOptions.SetTextRenderingMode(this, TextRenderingMode.ClearType);
            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);

            visuals = new VisualCollection(this) { borderVisual, foregroundVisual };

            GridPanel.Children.Add(this);
        }

        protected override Visual GetVisualChild(int index) { return visuals[index]; }
        protected override int VisualChildrenCount { get { return visuals.Count; } }
        private readonly VisualCollection visuals;

        private readonly DrawingVisual foregroundVisual = new DrawingVisual();
        private readonly DrawingVisual borderVisual = new DrawingVisual();


        //Override the dependency properties here to increase performance
        public new Visibility Visibility { get { return visibility; } private set { if (visibility == value) return; base.Visibility = visibility = value; } } private Visibility visibility;
        public int ZIndex { get { return zIndex; } private set { if (zIndex == value) return; zIndex = value; Canvas.SetZIndex(this, value); } } private int zIndex;
        public double Left { get { return left; } private set { if (left == value) return; left = value; Canvas.SetLeft(this, value); } } private double left;
        public double Top { get { return top; } private set { if (top == value) return; top = value; Canvas.SetTop(this, value); } } private double top;
        public new double Width { get { return width; } private set { if (width == value) return; width = value; base.Width = value; } } private double width;
        public new double Height { get { return height; } private set { if (height == value) return; height = value; base.Height = value; } } private double height;
        public new object ToolTip { get { return toolTip; } private set { if (toolTip == value) return; base.ToolTip = toolTip = value; } } private object toolTip;
        public int CellToolTipTimeout { get { return cellToolTipTimeout; } private set { if (cellToolTipTimeout == value) return; cellToolTipTimeout = value; SetValue(ToolTipService.ShowDurationProperty, value); } } private int cellToolTipTimeout;


        public LightGridPanel GridPanel { get; private set; }
        public LightGridRow Row { get; internal set; }
        public LightGridColumn Column { get; internal set; }

        public CellViewModel Model { get; private set; }

        public TreeNodeViewModel TreeNode { get { return Model.TreeNode; } internal set { Model.TreeNode = value; Visibility = Model.Visibility; } }
        public ColumnSpec Spec { get { return Model.Spec; } internal set { Model.Spec = value; Visibility = Model.Visibility; } }


        internal void DrawCell(bool initialLoad = false)
        {
            Visibility = Model.Visibility;
            ZIndex = Model.ZIndex;
            Left = Model.Left;
            Top = Model.Top;
            Width = Model.Width;
            Height = Model.Height;
            CellToolTipTimeout = Model.Grid.CellToolTipTimeout;

            if (Model.Initialized == false) return;

            var newIcon = IconToDrawing(Model.Icon);
            var groupIcon = (Drawing)IconToDrawing(Model.GroupIcon);

            //++draw border
            var lastWidth = DrawBorder_width;
            DrawBorder(Model.Active, Model.GlyphCache, Model.FormatSpec);

            if (Model.Visible == false)
            {
                foregroundVisual.RenderOpen().Close();//clear up the cell
                DefaultDrawCellState();//Remove previously saved states
                return;
            }

            if (DrawBorder_width == 0 || DrawBorder_height == 0)
            {
                foregroundVisual.RenderOpen().Close();//clear up the cell
                borderVisual.RenderOpen().Close();
                return;
            }
            //--draw border


            //++calculate glyph
            glyphRunDrawing = CalculateGlyphRunDrawing(Model.FormattedText, Width - Model.LeadingTextSpaceWidth, Model.GlyphCache, Model.Foreground);

            if (DrawCell_GlyphRunDrawing == glyphRunDrawing && DrawCell_icon == newIcon && DrawCell_CheckBoxIconXOffset == Model.CheckBoxIconXOffset && DrawCell_groupIcon == groupIcon &&
                DrawCell_leadingSpaceWidth == Model.LeadingSpaceWidth && DrawCell_Underline == Model.Underline && DrawCell_Strikethrough == Model.Strikethrough && DrawCell_LastSplitFilterRow == TreeNode.LastSplitViewportNode &&
                DrawCell_Active == Model.Active && lastWidth == Width && DrawCell_MultistateIconIndex == Model.MultiStateIconIndex && DrawCell_secondaryContent == Model.SuperscriptContent)
                return;
            //--calculate glyph

            //++draw foreground
            var foregroundContext = foregroundVisual.RenderOpen();

            DrawSplitFilterLine(foregroundContext, Model.GlyphCache);

            if (Model.IndentText)
            {
                foregroundContext.PushClip(Column.Header.Rectangle(new Rect(0, 0, DrawBorder_width, DrawBorder_height)));
                foregroundContext.PushTransform(new TranslateTransform(Model.LeadingSpaceWidth, Model.YOffset));
                if (groupIcon != null) foregroundContext.DrawDrawing(groupIcon);
                foregroundContext.PushTransform(new TranslateTransform(GridViewModel.GROUP_ICON_SIZE, -Model.YOffset));
            }

            if (newIcon != null)
            {
                if (newIcon is GeometryDrawing)
                {
                    foregroundContext.PushTransform(new TranslateTransform(Model.CheckBoxIconXOffset, Model.YOffset));
                    foregroundContext.DrawDrawing((GeometryDrawing)newIcon);
                    foregroundContext.Pop();
                }
                else
                {
                    if (Model.Index != null)
                    {
                        foregroundContext.PushTransform(new TranslateTransform(Model.CheckBoxIconXOffset, Model.YOffset));
                        foregroundContext.DrawImage((ImageSource)newIcon, new Rect(new Size(Model.IconSize, Model.IconSize)));
                        DrawIndexText(Model.Index, foregroundContext, Model.YOffset);
                        foregroundContext.PushTransform(new TranslateTransform(GridViewModel.GROUP_ICON_SIZE, -Model.YOffset));
                    }
                    else
                    {
                        foregroundContext.DrawImage((ImageSource)newIcon, new Rect(new Point(Model.CheckBoxIconXOffset, Model.YOffset), new Size(Model.IconSize, Model.IconSize)));
                    }
                }
            }

            if (Model.SuperscriptContent != null)
            {
                var superscriptHostWidth = (groupIcon != null || TreeNode.BottomTotal) ?  Spec.Width - Model.LeadingSpaceWidth - GridViewModel.GROUP_ICON_SIZE : DrawBorder_width;
                var superscriptHostHeight = Model.Grid.RowHeight;
                Model.SuperscriptContent.Draw(foregroundContext, superscriptHostHeight, superscriptHostWidth);
            }

            if (glyphRunDrawing != null)
            {
                foregroundContext.DrawDrawing(glyphRunDrawing);

                if (Model.Underline)
                {
                    var thickness = Model.GlyphCache.Typeface.UnderlineThickness;
                    if (thickness < 1) thickness = 1;
                    if (Model.GlyphCache.FontWeight == FontWeights.Bold) thickness = thickness * 1.5;

                    var glyphRun = glyphRunDrawing.GlyphRun;
                    var startPoint = glyphRun.BaselineOrigin;
                    startPoint.Y += 2;

                    var textWidth = CalculateTextWidth(glyphRun);
                    var endPoint = new Point(startPoint.X + textWidth, startPoint.Y);

                    var linePen = new Pen(GetGlyphRunDrawing_foreground_brush, thickness);
                    foregroundContext.DrawLine(linePen, startPoint, endPoint);
                }
                if (Model.Strikethrough)
                {
                    var thickness = Model.GlyphCache.Typeface.StrikethroughThickness;
                    if (thickness < 1) thickness = 1;
                    if (Model.GlyphCache.FontWeight == FontWeights.Bold) thickness = thickness * 1.5;

                    var glyphRun = glyphRunDrawing.GlyphRun;
                    var startPoint = glyphRun.BaselineOrigin;
                    startPoint.Y = startPoint.Y - Model.GlyphCache.FontSize / 2 + 2;

                    var textWidth = CalculateTextWidth(glyphRun);
                    var endPoint = new Point(startPoint.X + textWidth, startPoint.Y);

                    var linePen = new Pen(GetGlyphRunDrawing_foreground_brush, thickness);
                    foregroundContext.DrawLine(linePen, startPoint, endPoint);
                }
            }

            if (Model.Editable && Model.Grid.AutoFill.Enabled && Model.Active)
            {
                foregroundContext.PushTransform(new TranslateTransform(DrawBorder_width - GridViewModel.IconDragBorderSize - 1, Model.Grid.RowHeight - GridViewModel.IconDragBorderSize - 1));
                foregroundContext.DrawDrawing(iconDragBorder);
                foregroundContext.DrawDrawing(iconDragFill);
            }

            foregroundContext.Close();
            //--draw foreground

            DrawCell_Underline = Model.Underline;
            DrawCell_Strikethrough = Model.Strikethrough;
            DrawCell_leadingSpaceWidth = Model.LeadingSpaceWidth;
            DrawCell_groupIcon = groupIcon;
            DrawCell_icon = newIcon;
            DrawCell_CheckBoxIconXOffset = Model.CheckBoxIconXOffset;
            DrawCell_MultistateIconIndex = Model.MultiStateIconIndex;
            DrawCell_GlyphRunDrawing = glyphRunDrawing;
            DrawCell_Active = Model.Active;
            DrawCell_secondaryContent = Model.SuperscriptContent;
        }
        private void DefaultDrawCellState()
        {
            DrawCell_Underline = default(bool);
            DrawCell_Strikethrough = default(bool);
            DrawCell_leadingSpaceWidth = default(double);
            DrawCell_groupIcon = default(GeometryDrawing);
            DrawCell_icon = default(object);
            DrawCell_CheckBoxIconXOffset = default(double);
            DrawCell_MultistateIconIndex = default(object);
            DrawCell_GlyphRunDrawing = default(GlyphRunDrawing);
            DrawCell_Active = default(bool);
            DrawCell_secondaryContent = default(SuperscriptContent);
        }

        private void DrawIndexText(int? index, DrawingContext foregroundContext, double yOffset)
        {
            var isLocked = Model.IconParameters != null && Model.IconParameters.IsLocked;
            if (index.HasValue)
            {
                var indexText = new FormattedText(index.ToString(), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, new Typeface("Times New Roman"), 8, isLocked ? Brushes.Red : Brushes.Black);
                foregroundContext.DrawText(indexText, new Point(GridViewModel.GROUP_ICON_SIZE / 2 + 6, yOffset / 2 + 4));
            }
        }

        private double DrawCell_leadingSpaceWidth;
        private object DrawCell_groupIcon;
        private object DrawCell_icon;
        private object DrawCell_MultistateIconIndex;
        private double DrawCell_CheckBoxIconXOffset;
        private GlyphRunDrawing DrawCell_GlyphRunDrawing = glyphRunDrawingNull;
        private static readonly GlyphRunDrawing glyphRunDrawingNull = new GlyphRunDrawing();
        private bool DrawCell_Underline;
        private bool DrawCell_Strikethrough;
        private bool DrawCell_LastSplitFilterRow;
        private bool DrawCell_Active;
        private SuperscriptContent DrawCell_secondaryContent;
        private GlyphRunDrawing glyphRunDrawing;


        private double CalculateTextWidth(GlyphRun glyphRun)
        {
            double totalWidth = 0;

            var widths = glyphRun.AdvanceWidths;
            if (widths != null)
            {
                for (int i = 0, count = widths.Count; i < count; i++)
                    totalWidth += widths[i];
            }
            return totalWidth;
        }

        private GlyphRunDrawing CalculateGlyphRunDrawing(string text, double width, GlyphCache glyphCache, Color foreground)
        {
            var glyphRun = glyphCache.CalculateRun(text, width, Model.Grid.RowHeight, Model.ContentHorizontalAlignment);

            if (GetGlyphRunDrawing_foreground_color != foreground || GetGlyphRunDrawing_glyphRun != glyphRun)
            {
                if (GetGlyphRunDrawing_foreground_color != foreground)
                {
                    GetGlyphRunDrawing_foreground_color = foreground;
                    GetGlyphRunDrawing_foreground_brush = new SolidColorBrush(GetGlyphRunDrawing_foreground_color);
                    GetGlyphRunDrawing_foreground_brush.Freeze();
                }

                if (glyphRun == null)
                {
                    GetGlyphRunDrawing_return = null;
                }
                else
                {
                    GetGlyphRunDrawing_return = new GlyphRunDrawing(GetGlyphRunDrawing_foreground_brush, glyphRun);

                    GetGlyphRunDrawing_return.Freeze();
                }

                GetGlyphRunDrawing_glyphRun = glyphRun;
            }

            return GetGlyphRunDrawing_return;
        }
        private Brush GetGlyphRunDrawing_foreground_brush;
        private Color GetGlyphRunDrawing_foreground_color;
        private GlyphRun GetGlyphRunDrawing_glyphRun;
        private GlyphRunDrawing GetGlyphRunDrawing_return;

        private Pen CalculateCellBorderPen(bool focus, ColumnSpec formatSpec)
        {
            if (Model.Editable && !formatSpec.HideEditableBorder && !formatSpec.DataType.IsBoolean())
                return focus ? GridPanel.EditIndicator_penFocused : GridPanel.EditIndicator_pen;

            return focus ? LightGridPanel.PenFocused : LightGridPanel.Pen;
        }

        private void DrawSplitFilterLine(DrawingContext drawingContext, GlyphCache glyphCache)
        {
            if (TreeNode.LastSplitViewportNode)
            {
                var lineDrawing = glyphCache.CalculateLineDrawing(new Point(0, Model.Grid.RowHeight - 1), Width, GridViewModel.BrushLastSplitFilterNodeLine, 2);
                if (lineDrawing != null) drawingContext.DrawDrawing(lineDrawing);
            }

            DrawCell_LastSplitFilterRow = TreeNode.LastSplitViewportNode;
        }

        private void DrawBorder(bool focus, GlyphCache glyphCache, ColumnSpec formatSpec)
        {
            var background = Model.Background;
            var cellBorderPen = CalculateCellBorderPen(focus, formatSpec);
            var rowBorder = Model.RowBorder;
            var cellBorder = Model.CellBorder;

            if (Model.Visible == false)
            {
                cellBorderPen = LightGridPanel.Pen;
                cellBorder = null;
            }

            if (DrawBorder_width == Width && DrawBorder_height == Model.Grid.RowHeight &&
                DrawBorder_bacground_color == background && DrawCell_Active == focus &&
                DrawBorder_editable == Model.Editable && cellBorderPen == DrawBorder_pen && DrawBorder_rowBorder == rowBorder && DrawBorder_cellBorder == cellBorder && DrawBorder_contentPainter == Model.ContentPainter)
                return;

            if (DrawBorder_bacground_color != background)
            {
                DrawBorder_bacground_color = background;
                DrawBorder_background_brush = new SolidColorBrush(DrawBorder_bacground_color);
                DrawBorder_background_brush.Freeze();
            }

            if (DrawBorder_pen != cellBorderPen)
            {
                DrawBorder_pen = cellBorderPen;
            }

            borderDrawing = glyphCache.CalculateBorderDrawing(Width, Model.Grid.RowHeight, cellBorderPen, DrawBorder_background_brush, focus, rowBorder, cellBorder, (short)LightGridPanel.PenBorder_size);
            if (borderDrawing != DrawBorder_borderDrawing || Model.ContentPainter != DrawBorder_contentPainter)
            {
                var borderContext = borderVisual.RenderOpen();
                if (borderDrawing != null) borderContext.DrawDrawing(borderDrawing);
                if (Model.ContentPainter != null) borderContext.DrawDrawing(Model.ContentPainter(DrawBorder_width, DrawBorder_height));
                borderContext.Close();
            }

            DrawBorder_width = Width;
            DrawBorder_height = Model.Grid.RowHeight;
            DrawBorder_borderDrawing = borderDrawing;
            DrawBorder_editable = Model.Editable;
            DrawBorder_rowBorder = rowBorder;
            DrawBorder_cellBorder = cellBorder;
            DrawBorder_contentPainter = Model.ContentPainter;
        }
        private double DrawBorder_width;
        private double DrawBorder_height;
        private Color DrawBorder_bacground_color;
        private Pen DrawBorder_pen;
        private Brush DrawBorder_background_brush;
        private DrawingGroup DrawBorder_borderDrawing;
        private bool DrawBorder_editable;
        private DrawingGroup borderDrawing;
        private Color? DrawBorder_rowBorder;
        private Color? DrawBorder_cellBorder;
        private Func<double, double, Drawing> DrawBorder_contentPainter;


        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseDown(e);

            if(Model.Initialized == false) return;

            if (!TreeNode.Leaf && Model.GroupIconBound.Contains(e.GetPosition(this)))
            {
                //Clicked on expand/collapse icon
                if(e.ClickCount != 1)
                {
                    Model.Grid.ToggleNodeExpandCollapse(TreeNode);

                    e.Handled = true;

                    return;
                }

                //e.Handled = true;
                GridPanel.BeginSelection(this, e.OriginalSource, e.ChangedButton, PointToScreen(e.GetPosition(this)));
            }
            else if (Model.Editable && Spec.DataType == typeof(bool) && (Spec.EditOnClick || Model.IconBound.Contains(e.GetPosition(this))))
            {
                //Clicked on checkbox
                GridPanel.BeginSelection(this, e.OriginalSource, e.ChangedButton, PointToScreen(e.GetPosition(this)));
            }
            else if (Model.Editable && Spec.DataType.IsEnum && (Spec.EditOnClick || Model.IconBound.Contains(e.GetPosition(this))))
            {
                //Clicked on enum icon
                GridPanel.BeginSelection(this, e.OriginalSource, e.ChangedButton, PointToScreen(e.GetPosition(this)));
            }
            else
            {
                if(e.ClickCount != 1) return;

                GridPanel.BeginSelection(this, e.OriginalSource, e.ChangedButton, PointToScreen(e.GetPosition(this)));

                if(e.ChangedButton == MouseButton.Left)
                {
                    if (Model.Grid.AutoFill.Enabled && Model.Grid.Editable)
                    {
                        if (Model.Grid.Spec.SelectionUnit == SelectionUnits.Cell && !((Keyboard.Modifiers.HasFlag(ModifierKeys.Control) || Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) && Model.Grid.Tree.SelectedCount > 0))
                            Model.Grid.AutoFill.Start(TreeNode.Model, Spec, Model.AutoFillIconBound.Contains(e.GetPosition(this)) && Model.Active);
                        else if (Model.AutoFillIconBound.Contains(e.GetPosition(this)) && Model.Active)
                            Model.Grid.AutoFill.Start(TreeNode.Model, Spec, true);
                    }

                    if (Model.Grid.Spec.SelectionMode == SelectionModes.Drag || Model.Grid.AutoFill.IconClicked)
                        e.Handled = true;

                    if (TreeNode.Selected)
                        clickedOnSelectedCell = true;
                }
            }
        }
        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseUp(e);

            if(Model.Initialized == false) return;

            if (e.ClickCount != 1) return;

            if (!GridPanel.ReceivedPreviewMouseDown) return;

            if (e.ChangedButton == MouseButton.Left)
            {
                if(clickedOnSelectedCell)
                {
                    Model.Grid.ToggleSelection(TreeNode.Model, Spec, Keyboard.Modifiers.HasFlag(ModifierKeys.Control), Keyboard.Modifiers.HasFlag(ModifierKeys.Shift), Model.Grid.SummarySelectionType);
                    clickedOnSelectedCell = false;
                }

                if (Model.Grid.Spec.GroupingModeColumns.Grouped(Spec) && Model.GroupIconBound.Contains(e.GetPosition(this)))
                {
                    //Clicked on expand/collapse icon
                    Model.Grid.ToggleNodeExpandCollapse(TreeNode);

                    e.Handled = true;
                }

                GridPanel.EndSelection(Model, e.OriginalSource, e.ChangedButton, PointToScreen(e.GetPosition(this)));
            }
        }
        private bool clickedOnSelectedCell;

        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);

            if(Model.Initialized == false) return;

            ToolTip = Model.Visible ? Model.Grid.GetCellToolTip(TreeNode, Spec) : null;

            if (e.LeftButton == MouseButtonState.Pressed && Model.Grid.Spec.SelectionMode == SelectionModes.Drag && GridPanel.ReceivedPreviewMouseDown)
            {
                e.Handled = true;

                if (Model.Grid.AutoFill.IconClicked)
                    Model.Grid.ToggleSelectionForAutoFill(TreeNode.Model, Spec);
                else
                    Model.Grid.ToggleSelection(TreeNode.Model, Spec, single: Keyboard.Modifiers.HasFlag(ModifierKeys.Control), continuous: true);
            }
            else if(Model.Grid.HoverHighlight != GridViewModel.HoverHighlightModes.None)
            {
                GridPanel.HoverCell = this;
            }
        }
        protected override void OnPreviewMouseMove(MouseEventArgs e)
        {
            base.OnPreviewMouseMove(e);

            if(Model.Initialized == false) return;

            if (e.LeftButton == MouseButtonState.Pressed)
                clickedOnSelectedCell = false;
        }

        protected override void OnPreviewMouseWheel(MouseWheelEventArgs e)
        {
            base.OnPreviewMouseWheel(e);

            if(Model.Initialized == false) return;

            var editorControl = (e.OriginalSource as DependencyObject).FindVisualParent<CellEditorControl>();
            if (editorControl != null && editorControl.NeedEvent(e)) return;
            if (e.Delta == 0) return;

            var delta = -(e.Delta / Math.Abs(e.Delta));

            if (Keyboard.Modifiers == ModifierKeys.Alt)
            {
                GridPanel.Owner.DataContext.ViewportOffset += 50 * delta;
            }
            else
            {
                if (TreeNode.Model is TreeBuilderModel.SplitTreeNodeModel) GridPanel.Owner.DataContext.Tree.SplitViewportOffset += 3 * delta;
                else GridPanel.Owner.DataContext.Tree.ViewportOffset += 3 * delta;
            }
        }


        protected override void OnContextMenuOpening(ContextMenuEventArgs e)
        {
            base.OnContextMenuOpening(e);

            if(Model.Initialized == false) return;

            if(TreeNode.Selected) return;

            GridPanel.BeginSelection(this, e.OriginalSource, MouseButton.Right, PointToScreen(Mouse.GetPosition(this)));
        }



        private object IconToDrawing(object icon)
        {
            if(icon == null) return null;
            else if(icon is CellViewModel.Icons?) return IconToDrawing((CellViewModel.Icons?)icon);
            else if(icon is GeometryDrawing) return icon;
            else if(icon is ImageSource) return icon;
            else throw new NotImplementedException();
        }
        private object IconToDrawing(CellViewModel.Icons? icon)
        {
            switch(icon)
            {
                case null: return null;
                case CellViewModel.Icons.Expanded: return iconExpanded;
                case CellViewModel.Icons.Collapsed: return iconCollapsed;
                case CellViewModel.Icons.DragBorder: return iconDragBorder;
                case CellViewModel.Icons.DragFill: return iconDragFill;
                case CellViewModel.Icons.ReadOnlyChecked: return iconReadOnlyChecked;
                case CellViewModel.Icons.ReadOnlyUnchecked: return iconReadOnlyUnchecked;
                case CellViewModel.Icons.ReadOnlyIntermediate: return iconReadOnlyIntermediate;
                case CellViewModel.Icons.Intermediate: return iconIntermediate;
                case CellViewModel.Icons.OverriddenChecked: return iconOverriddenChecked;
                case CellViewModel.Icons.OverriddenUnchecked: return iconOverriddenUnchecked;
                case CellViewModel.Icons.Checked: return IconChecked;
                case CellViewModel.Icons.Unchecked: return IconUnchecked;
                case CellViewModel.Icons.CheckedForeground: return Column.Header.CalculateIconChecked(Model.Foreground);
                case CellViewModel.Icons.UncheckedForeground: return Column.Header.CalculateIconUnchecked(Model.Foreground);
                default: throw new NotImplementedException();
            }
        }


        #region nested classes

        protected override System.Windows.Automation.Peers.AutomationPeer OnCreateAutomationPeer()
        {
            return new AutomationPeer(this);
        }
        private class AutomationPeer : System.Windows.Automation.Peers.FrameworkElementAutomationPeer
        {
            public AutomationPeer(LightGridCell owner) : base(owner)
            {
            }

            public new LightGridCell Owner { get { return (LightGridCell)base.Owner; } }


            protected override string GetClassNameCore()
            {
                return typeof(LightGridCell).Name;
            }

            protected override System.Windows.Automation.Peers.AutomationControlType GetAutomationControlTypeCore()
            {
                return System.Windows.Automation.Peers.AutomationControlType.DataItem;
            }

            protected override string GetAutomationIdCore()
            {
                var spec = Owner.Spec;

                return spec == null ? "Cell_" : "Cell_" + spec.Name;
            }

            protected override string GetNameCore()
            {
                var node = Owner.TreeNode;

                return node == null || node.Model == null ? "Row_" : "Row_" + node.Model.Index;
            }

            protected override string GetHelpTextCore()
            {
                return Owner.Model.FormattedText;
            }
        }

        #endregion
    }
}
