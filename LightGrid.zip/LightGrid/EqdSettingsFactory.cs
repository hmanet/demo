﻿//using Wells.Derivatives.Carina.Core.Configuration;
//using Wells.Derivatives.Carina.Core.Interfaces;
//using Wells.Derivatives.Carina.Core.ViewModel.Grid.Serializers;
//using Wells.Derivatives.Carina.EqdCore;

//namespace Wells.Derivatives.Carina.Core.Presentation.Utils
//{
//    // Used with Spring to create instance of EqdSettings for use as a VM in global options
//    public static class EqdSettingsFactory
//    {
//        public static EqdSettings CreatEqdSettings(CarinaConfig configService, IPersistenceManager persistenceManager)
//        {
//            persistenceManager.RegisterSerializer(new EqdSettingsSerializer());
//            return configService.Get<EqdSettings>(EqdSettings.SETTINGS_KEY);
//        }
//    }
//}
