﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class GroupColumnControl
    {
        public GroupColumnControl()
        {
            Resources.MergedDictionaries.Add(LightGridCommonResources.Instance);

            InitializeComponent();
            DataContextChanged += GroupColumnControl_DataContextChanged;
            Unloaded += GroupColumnControl_Unloaded;
            GroupControl.PreviewMouseDown += GroupControl_PreviewMouseDown;
            GroupControl.PreviewMouseUp += GroupControl_PreviewMouseUp;
        }
        private ListBoxItem clickedOnSelectedItem;
        private bool sortClicked;
        private bool toggleExpandCollapseClicked;


        public new GroupColumnViewModel DataContext { get { return dataContext; } set { base.DataContext = value; } } private GroupColumnViewModel dataContext;
        private void GroupColumnControl_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            dataContext = e.NewValue as GroupColumnViewModel;

            if (DataContext != null)
            {
                GroupControl.ItemsPanel = DataContext.UniformItemWidth
                    ? (ItemsPanelTemplate)Resources["GroupItemsPanelTemplateUniform"]
                    : (ItemsPanelTemplate)Resources["GroupItemsPanelTemplateAuto"];
            }
        }


        private void GroupColumnControl_Unloaded(object sender, RoutedEventArgs e)
        {
            DataContextChanged -= GroupColumnControl_DataContextChanged;
            GroupControl.PreviewMouseDown -= GroupControl_PreviewMouseDown;
            GroupControl.PreviewMouseUp -= GroupControl_PreviewMouseUp;

            Unloaded -= GroupColumnControl_Unloaded;
        }

        private void GroupControl_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (dataContext == null || !dataContext.HasGroups) return;
            var item = e.OriginalSource as ListBoxItem ?? ((DependencyObject) e.OriginalSource).FindParentObjectByType<ListBoxItem>();
            if (item == null) return;

            var expander = e.OriginalSource as ToggleButton ?? ((DependencyObject)e.OriginalSource).FindParentObjectByType<ToggleButton>();

            sortClicked = false;
            toggleExpandCollapseClicked = false;
            if (e.ChangedButton == MouseButton.Left
                && e.GetPosition(item).X <= GridViewModel.GROUP_ICON_SIZE + LightGridPanel.CLICK_HOTSPOTSIZE
                && e.GetPosition(item).X > 0 && expander != null)
            {
                toggleExpandCollapseClicked = true;
                return;
            }
            if (e.ChangedButton == MouseButton.Left
                && e.GetPosition(item).X >= item.ActualWidth - LightGridPanel.SORT_HOTSPOTSIZE - LightGridPanel.CLICK_HOTSPOTSIZE
                && e.GetPosition(item).X < item.ActualWidth - LightGridPanel.RESIZE_THUMB_WIDTH)
            {
                sortClicked = true;
                return;
            }

            var columnSpec = (ColumnSpec) item.DataContext;

            if (columnSpec.Selected)
                clickedOnSelectedItem = item;
            else
                dataContext.UpdateColumnSelection(columnSpec, Keyboard.Modifiers.HasFlag(ModifierKeys.Control), Keyboard.Modifiers.HasFlag(ModifierKeys.Shift));
        }
        private void GroupControl_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton != MouseButton.Left) return;
            var item = e.OriginalSource as ListBoxItem ?? ((DependencyObject) e.OriginalSource).FindParentObjectByType<ListBoxItem>();
            if (item == null) return;

            if (toggleExpandCollapseClicked
                && e.GetPosition(item).X <= GridViewModel.GROUP_ICON_SIZE + LightGridPanel.CLICK_HOTSPOTSIZE
                && e.GetPosition(item).X > 0)
            {
                dataContext.Grid.ToggleGroupExpandCollapse((ColumnSpec) item.DataContext);
            }
            toggleExpandCollapseClicked = false;
            if (sortClicked
                && e.GetPosition(item).X >= item.ActualWidth - LightGridPanel.SORT_HOTSPOTSIZE - LightGridPanel.CLICK_HOTSPOTSIZE
                && e.GetPosition(item).X < item.ActualWidth - LightGridPanel.RESIZE_THUMB_WIDTH)
            {
                // Do sort.
                dataContext.Grid.Spec.ToggleSort((ColumnSpec) item.DataContext,
                    Keyboard.Modifiers.HasFlag(ModifierKeys.Control),
                    Keyboard.Modifiers.HasFlag(ModifierKeys.Shift));
            }
            sortClicked = false;

            if (clickedOnSelectedItem != null)
            {
                clickedOnSelectedItem = null;

                dataContext.UpdateColumnSelection((ColumnSpec) item.DataContext, Keyboard.Modifiers.HasFlag(ModifierKeys.Control), Keyboard.Modifiers.HasFlag(ModifierKeys.Shift));
            }
        }


        private void ColumnSpec_MouseEnter(object sender, MouseEventArgs e)
        {
            var cp = (ContentPresenter)sender;
            if(cp.DataContext is ColumnSpec == false) return;

            cp.ToolTip = DataContext.Grid.GetColumnToolTip((ColumnSpec)cp.DataContext);
        }
    }
}
