﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Common.Logging;
using Wells.Derivatives.Carina.Core.Interfaces;
using Wells.Derivatives.Carina.Core.Metadata;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Presentation.Extensions;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.LightGrid.LightGridEditor;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid.Editor;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.OptionSelector;
using Wells.Derivatives.Carina.Core.Utilities;
using Point = System.Windows.Point;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public partial class LightGridPanel : Canvas
    {
        private const double DRAG_HOTSPOT_SIZE = 5;
        public const double RESIZE_THUMB_WIDTH = 3;
        public const double SORT_HOTSPOTSIZE = 12;
        public const double COLLAPSIBLE_WIDTH = 70;
        public const double CLICK_HOTSPOTSIZE = 2;

        private static readonly ILog Log = LogManager.GetLogger(typeof(LightGridPanel));

        static LightGridPanel()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridPanel), new FrameworkPropertyMetadata((d, a) => ((LightGridPanel)d).OnDataContextChanged((GridViewModel)a.OldValue, (GridViewModel)a.NewValue), (d, v) => v as GridViewModel));

            //initialize cached visuals
            var pen_brush = new SolidColorBrush(Pen_color); pen_brush.Freeze();
            Pen = new Pen(pen_brush, Pen_size); Pen.Freeze();
            var penFocused_brush = new SolidColorBrush(PenFocused_color); penFocused_brush.Freeze();
            PenFocused = new Pen(penFocused_brush, PenFocused_size); PenFocused.Freeze();
            var penTopTotals_brush = new SolidColorBrush(PenTopTotals_color); penTopTotals_brush.Freeze();
            PenTopTotals = new Pen(penTopTotals_brush, PenTopTotals_size); PenTopTotals.Freeze();
        }
        public LightGridPanel()
        {
            Columns = new ReadOnlyCollection<LightGridColumn>(columns);
            Rows = new ReadOnlyCollection<LightGridRow>(rows);

            Resources.MergedDictionaries.Add(LightGridResources.Instance);
            //Resources.MergedDictionaries.Add(LightGridColumnHeaderResources.Instance);

            Focusable = true;
            FocusVisualStyle = null;

            Width = double.NaN;
            Height = double.NaN;

            AllowDrop = true;
            //AllowDrag = true;


            // Cell editing
            CellEditTemplate = TryFindResource("LightGridCellEditTemplate") as ControlTemplate;
            singleAndDoubleClickHelper = new SingleAndDoubleClickHelper();
            singleAndDoubleClickHelper.RegisterHandlers
            (
                this,
                doubleClickHandler: OnDoubleClick,
                canHandle: e => e.OriginalSource is LightGridCell || ((DependencyObject)e.OriginalSource).FindParentObjectByType<LightGridCell>() != null
            );

            formatBridge = new GlobalFormatToGridBridge(this);

            splitScrollBar.Style = LightGridResources.Instance.SplitScrollBarStyle;
            SetZIndex(splitScrollBar, GridViewModel.ScrollbarZIndex);

            Children.Add(splitScrollBar);
            Children.Add(Splitter);
            Children.Add(cellEditorControl);

            //initialize cached visuals
            EditIndicator_color = Colors.Black;
            EditIndicator_brush = Brushes.Black;
            EditIndicator_pen = new Pen(Brushes.Black, Pen_size); EditIndicator_pen.Freeze();
            EditIndicator_penFocused = new Pen(Brushes.Black, PenFocused_size); EditIndicator_penFocused.Freeze();
        }
        private readonly GlobalFormatToGridBridge formatBridge;

        internal readonly LightGridColumnHeadersPanel.Thumb Splitter = new LightGridColumnHeadersPanel.Thumb();

        private readonly ScrollBar splitScrollBar = new ScrollBar();
        private void CalculateSplitScrollBarLocation()
        {
            SetLeft(splitScrollBar, Math.Min(DataContext.ViewportSize + DataContext.LockedViewportSize, ActualWidth) - splitScrollBar.ActualWidth);
            splitScrollBar.Height = Math.Max(DataContext.Spec.SplitPanelMaxSize * DataContext.RowHeight, 2) - 2;
        }

        public LightGrid Owner { get; internal set; }


        public new GridViewModel DataContext { get { return dataContext; } set { base.DataContext = value; } } private GridViewModel dataContext;
        private void OnDataContextChanged(GridViewModel oldValue, GridViewModel newValue)
        {
            if (oldValue != null)
            {
                oldValue.Handler(() => oldValue.Columns).Changed -= DataContext_ColumnsChanged;
                oldValue.Handler(() => oldValue.Editable).Changed -= DataContext_EditableChanged;
                oldValue.Handler(() => oldValue.EditIndicator).Changed -= DataContext_EditIndicatorChanged;
                oldValue.Handler(() => oldValue.ActiveCell).Changed -= DataContext_ActiveCellChanged;
                oldValue.Spec.Handler(() => oldValue.Spec.SelectionMode).Changed -= DataContext_Spec_SelectionModeChanged;
                oldValue.Spec.Handler(() => oldValue.Spec.GrandTotalFormat).Changed -= DataContext_Spec_GrandTotalFormatChanged;
                oldValue.Spec.Handler(() => oldValue.Spec.SummaryRowFormat).Changed -= DataContext_Spec_SummaryRowFormatChanged;
                oldValue.Spec.Handler(() => oldValue.Spec.TopTotalsRowFormat).Changed -= DataContext_Spec_TopTotalsRowFormatChanged;
                oldValue.EnableRowDragChanged -= DataContext_EnableRowDragChanged;
                oldValue.Tree.EndChanges -= DataContext_Tree_EndChanges;
                oldValue.Tree.SelectionChanged -= DataContext_Tree_SelectionChanged;
                oldValue.Tree.EditCellEvent -= DataContext_Tree_EditCellEvent;
                oldValue.Tree.Builder.OutputCleared -= DataContext_Tree_Builder_OutputCleared;
                oldValue.Triggers.CollectionChanged -= Triggers_CollectionChanged;
            }

            dataContext = newValue;

            if (newValue != null)
            {
                newValue.Handler(() => newValue.Columns).Changed += DataContext_ColumnsChanged;
                newValue.Handler(() => newValue.Editable).Changed += DataContext_EditableChanged;
                newValue.Handler(() => newValue.EditIndicator).Changed += DataContext_EditIndicatorChanged;
                newValue.Handler(() => oldValue.ActiveCell).Changed += DataContext_ActiveCellChanged;
                newValue.Spec.Handler(() => newValue.Spec.SelectionMode).Changed += DataContext_Spec_SelectionModeChanged; DataContext_Spec_SelectionModeChanged(null);
                newValue.Spec.Handler(() => newValue.Spec.GrandTotalFormat).Changed += DataContext_Spec_GrandTotalFormatChanged;
                newValue.Spec.Handler(() => newValue.Spec.SummaryRowFormat).Changed += DataContext_Spec_SummaryRowFormatChanged;
                newValue.Spec.Handler(() => newValue.Spec.TopTotalsRowFormat).Changed += DataContext_Spec_TopTotalsRowFormatChanged;
                newValue.EnableRowDragChanged += DataContext_EnableRowDragChanged; DataContext_EnableRowDragChanged();
                newValue.Tree.EndChanges += DataContext_Tree_EndChanges;
                newValue.Tree.SelectionChanged += DataContext_Tree_SelectionChanged;
                newValue.Tree.EditCellEvent += DataContext_Tree_EditCellEvent;
                newValue.Tree.Builder.OutputCleared += DataContext_Tree_Builder_OutputCleared;
                newValue.Triggers.CollectionChanged += Triggers_CollectionChanged;
                newValue.CellEditorManager.EditStarting += DataContext_EditStarting;

                BeginResetColumns();
                BeginResetRows();
                DataContext_EditIndicatorChanged(null);
            }

            else//newValue is null, update columns and rows
            {
                foreach (var next in Columns)
                {
                    next.Spec = null;
                    next.Grid = null;
                }
                foreach (var next in Rows)
                {
                    next.TreeNode = null;
                    next.Grid = null;
                }
            }
        }

        private void DataContext_ColumnsChanged(IChangeArgs<ColumnSpec[]> args) { BeginResetColumns(); DataContext_EditableChanged(null); }
        private void DataContext_EditableChanged(IChangeArgs<bool> args) { foreach (var next in Columns) next.GridEditable = DataContext.Editable; }
        private void DataContext_EditIndicatorChanged(IChangeArgs<Color> args)
        {
            if (EditIndicator_color == DataContext.EditIndicator) return;

            EditIndicator_brush = new SolidColorBrush(DataContext.EditIndicator); EditIndicator_brush.Freeze();
            EditIndicator_pen = new Pen(EditIndicator_brush, Pen_size);
            EditIndicator_penFocused = new Pen(EditIndicator_brush, PenFocused_size);
        }
        private void DataContext_Spec_SelectionModeChanged(IChangeArgs<SelectionModes> args) { UpdateRowDragState(); }
        private void DataContext_Spec_GrandTotalFormatChanged(IChangeArgs<TriggerStyle> args) { BeginResetRows(); }
        private void DataContext_Spec_SummaryRowFormatChanged(IChangeArgs<TriggerStyle> args) { BeginResetRows(); }
        private void DataContext_Spec_TopTotalsRowFormatChanged(IChangeArgs<TriggerStyle> args) { BeginResetRows(); }
        private void DataContext_EnableRowDragChanged() { UpdateRowDragState(); }
        private void DataContext_Tree_EndChanges() { BeginResetRows(); }
        private void DataContext_Tree_SelectionChanged(ChangeEventArgs<TreeNodeModel> arg1, ChangeEventArgs<AttributeKey> arg2)
        {
            if (TreeNodeModel.IdEquals(arg1.OldValue, arg1.NewValue) && arg2.OldValue == arg2.NewValue) return;

            //Trace.WriteLine(arg1.OldValue + ", " + arg1.NewValue + ", " + arg2.OldValue + ", " + arg2.NewValue);

            EndEdit();
        }
        private void Triggers_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e) { BeginResetRows(); }


        public IReadOnlyCollection<LightGridColumn> Columns { get; private set; }
        private readonly List<LightGridColumn> columns = new List<LightGridColumn>();

        public IReadOnlyCollection<LightGridRow> Rows { get; private set; }
        private readonly List<LightGridRow> rows = new List<LightGridRow>();


        public LightGridCell HoverCell { get { return hoverCell; } internal set { if (value == hoverCell) return; hoverCell = value; Dispatcher.ThrottleInvoke(OnHoverCellChanged, DispatcherPriority.Input); } } private LightGridCell hoverCell;
        private void OnHoverCellChanged()
        {
            DataContext.HoverCell = HoverCell == null ? null : hoverCell.Model;

            var newHoverCell = HoverCell;
            if ((DataContext.HoverHighlight & GridViewModel.HoverHighlightModes.Row) == GridViewModel.HoverHighlightModes.Row)
            {
                if(oldHoverCell != null) oldHoverCell.Row.RefreshCells();
                if(newHoverCell != null &&(oldHoverCell == null || oldHoverCell.Row != newHoverCell.Row)) newHoverCell.Row.RefreshCells();
            }

            if ((DataContext.HoverHighlight & GridViewModel.HoverHighlightModes.Column) == GridViewModel.HoverHighlightModes.Column)
            {
                if (oldHoverCell != null) oldHoverCell.Column.RefreshCells();
                if (newHoverCell != null && (oldHoverCell == null || oldHoverCell.Column != newHoverCell.Column)) newHoverCell.Column.RefreshCells();
            }

            oldHoverCell = newHoverCell;
        }
        private LightGridCell oldHoverCell;


        private void BeginResetColumns()
        {
            if (resettingColumns) return;
            resettingColumns = true;

            CalculateSplitScrollBarLocation();

            Dispatcher.BeginInvoke(() => { resettingColumns = false; ResetColumns(); }, DispatcherPriority.DataBind);
        }
        private void ResetColumns()
        {
            if(DataContext.CalculatingColumns)
            {
                BeginResetColumns();
                return;
            }

            var nextColumnIndex = -1;
            foreach (var next in DataContext.LockedColumns)
            {
                ++nextColumnIndex;
                if (columns.Count <= nextColumnIndex) columns.Add(new LightGridColumn(this));
                var column = columns[nextColumnIndex];
                column.Grid = DataContext;
                column.Spec = next;
                column.GridEditable = DataContext.Editable;
            }
            foreach (var spec in DataContext.Columns)
            {
                ++nextColumnIndex;
                if (Columns.Count <= nextColumnIndex) columns.Add(new LightGridColumn(this));
                var column = columns[nextColumnIndex];
                column.Grid = DataContext;
                column.Spec = spec;
                column.GridEditable = DataContext.Editable;
            }
            for (var i = nextColumnIndex + 1; i < columns.Count; ++i)
            {
                var column = columns[i];
                column.Spec = null;
                column.Grid = null;
            }

            var lastLockedColumn = DataContext.LockedColumns.LastOrDefault();
            Splitter.Spec = Owner.FiltersPanel.Splitter.Spec = lastLockedColumn;
            Splitter.Grid = Owner.FiltersPanel.Splitter.Grid = lastLockedColumn == null ? null : DataContext;
            Splitter.Width = DataContext.LockedViewportSize + 3;

            EndEditIfNeeded();


            Owner.Timer.StopAll();
            foreach (var next in Owner.Rows)
                next.RefreshAfterScroll();
        }
        private bool resettingColumns;

        private void BeginResetRows()
        {
            if (resettingRows) return;
            resettingRows = true;

            Dispatcher.BeginInvoke(() => { CalculateSplitScrollBarLocation(); resettingRows = false; ResetRows(); }, DispatcherPriority.DataBind);
        }
        private void ResetRows()
        {
            var nextRowIndex = -1;

            foreach (var next in DataContext.Tree.Nodes)
            {
                ++nextRowIndex;
                if (Rows.Count <= nextRowIndex) rows.Add(new LightGridRow(this));
                var row = rows[nextRowIndex];
                row.TreeNode = next;
                row.Grid = DataContext;
            }
            for (var i = nextRowIndex + 1; i < rows.Count; ++i)
            {
                var row = rows[i];
                row.TreeNode = null;
                row.Grid = null;
            }

            foreach (var next in Owner.Rows)
                next.ProcessTriggersAndRefreshCells();

            Splitter.Height = DataContext.Tree.Nodes.Count * DataContext.RowHeight;

            EndEditIfNeeded();
        }
        private bool resettingRows;


        private LightGridColumnHeader activeColumnHeaderCell;
        private LightGridColumnHeader firstSelectedColumnHeader;
        internal void BeginSelection(LightGridColumnHeader columnHeader, object source, MouseButton button, Point screenPosition)
        {
            clickedOnColumnHeaderSort = false;
            clickedOnColumnHeaderExpandCollapse = false;

            if (columnHeader.PointFromScreen(screenPosition).X < RESIZE_THUMB_WIDTH)//this will give some room for the column resize thumb
                return;

            var expander = source as ToggleButton ?? ((DependencyObject)source).FindParentObjectByType<ToggleButton>();

            var spec = columnHeader.Spec;

            var x = columnHeader.PointFromScreen(screenPosition).X;
            if (button == MouseButton.Left && expander != null)
            {
                var groupIconSize = DataContext.Spec.GroupingModeColumns.Grouped(spec) ? GridViewModel.GRID_MENU_ICON_SIZE : 0;
                if (x <= GridViewModel.GROUP_ICON_SIZE + groupIconSize + CLICK_HOTSPOTSIZE && x > 0) clickedOnColumnHeaderExpandCollapse = true;
            }
            else if (button == MouseButton.Right || x < spec.Width - SORT_HOTSPOTSIZE)
            {
                activeColumnHeaderCell = columnHeader;

                if (spec.Selected)
                {
                    firstSelectedColumnHeader = columnHeader;
                }
                else
                {
                    firstSelectedColumnHeader = null;

                    SelectColumn(columnHeader);
                }

                relativeClickPosition = screenPosition;
            }
            else if (x < spec.Width - DRAG_HOTSPOT_SIZE)
            {
                clickedOnColumnHeaderSort = true;
            }

            EndEdit();

            Owner.DragDrop.Hover -= DragDropHandler_Hover;
            Owner.DragDrop.Hover += DragDropHandler_Hover;
        }
        private void DragDropHandler_Hover(Point position, DragEventArgs args)
        {
            Owner.DragDrop.Hover -= DragDropHandler_Hover;

            relativeClickPosition = new Point(double.NegativeInfinity, double.NegativeInfinity);
        }
        internal void EndSelection(LightGridColumnHeader columnHeader, object source, MouseButton button, Point screenPosition)
        {
            Owner.DragDrop.Hover -= DragDropHandler_Hover;

            var position = columnHeader.PointFromScreen(screenPosition);

            if (clickedOnColumnHeaderSort && button == MouseButton.Left)
            {
                var spec = columnHeader.Spec;

                if (position.X >= spec.Width - SORT_HOTSPOTSIZE && spec != dataContext.Spec.GroupColumn && spec.SortedCanChange)
                    dataContext.Spec.ToggleSort(spec, Keyboard.Modifiers.HasFlag(ModifierKeys.Control), Keyboard.Modifiers.HasFlag(ModifierKeys.Shift));
            }
            clickedOnColumnHeaderSort = false;

            if (clickedOnColumnHeaderExpandCollapse && button == MouseButton.Left)
            {
                var spec = columnHeader.Spec;

                var groupIconSize = DataContext.Spec.GroupingModeColumns.Grouped(spec) ? GridViewModel.GRID_MENU_ICON_SIZE : 0;
                if (position.X <= GridViewModel.GROUP_ICON_SIZE + groupIconSize + CLICK_HOTSPOTSIZE && position.X > 0)
                {
                    if (spec != dataContext.Spec.GroupColumn && spec.GroupedCanChange)
                        dataContext.ToggleGroupExpandCollapse(spec);
                }
            }
            clickedOnColumnHeaderExpandCollapse = false;

            if (!double.IsNegativeInfinity(relativeClickPosition.X))
            {
                relativeClickPosition = new Point(double.NegativeInfinity, double.NegativeInfinity);

                if (button == MouseButton.Left && firstSelectedColumnHeader != null)
                {
                    firstSelectedColumnHeader = null;

                    activeColumnHeaderCell = columnHeader;

                    SelectColumn(activeColumnHeaderCell);
                }
            }
        }
        private void SelectColumn(LightGridColumnHeader columnHeader)
        {
            if (columnHeader.Spec == DataContext.Spec.GroupColumn && Keyboard.Modifiers.HasFlag(ModifierKeys.Control) && DataContext.Spec.GroupColumn.Selected)
                return;

            DataContext.ToggleColumnSelected(columnHeader.Spec, Keyboard.Modifiers.HasFlag(ModifierKeys.Control), Keyboard.Modifiers.HasFlag(ModifierKeys.Shift));
        }
        private bool clickedOnColumnHeaderSort;
        private bool clickedOnColumnHeaderExpandCollapse;

        private void DataContext_ActiveCellChanged(IChangeArgs<CellViewModel> args)
        {
            if(DataContext == null) return;

            if (args.NewValue != null)
            {
                if (editOnActive && editOnActiveAttribute == args.NewValue.Spec.Metadata.Key && editOnActiveNode != null && TreeNodeViewModel.IdEquals(editOnActiveNode, args.NewValue.TreeNode))
                {
                    editOnActive = false;
                    DataContext.CellEditorManager.BeginEdit(false);
                }
            }
        }
        internal void BeginSelection(LightGridCell cell, object source, MouseButton button, Point screenPosition)
        {
            if (DataContext.AutoFill.IconClicked) DataContext.AutoFill.End();

            if (cell.Model.Initialized == false) return;

            if (cell.TreeNode.Leaf == false && button == MouseButton.Left && cell.Model.GroupIconBound.Contains(TranslatePoint(PointFromScreen(screenPosition), cell)))
            {
                //Clicked on expand/collapse icon
                //don't select
                return;
            }

            var orgSrc = source as DependencyObject;
            if (orgSrc != null && orgSrc.FindParentObjectByType<CellEditorControl>(10) != null) return;

            UnselectCell(cell.Model);

            DataContext.ActiveCell = cell.Model;

            if(cell.TreeNode.Selected == false)
                DataContext.ToggleSelection(cell.TreeNode.Model, cell.Spec, single: Keyboard.Modifiers.HasFlag(ModifierKeys.Control), continuous: Keyboard.Modifiers.HasFlag(ModifierKeys.Shift), toggleSelection: !cell.Model.Selected, summarySelection: DataContext.SummarySelectionType);

            if (button == MouseButton.Left)
            {
                //logic for checkbox
                var isEditableCheckBoxCell = IsEditableCheckBoxCell(cell.Model);
                if (isEditableCheckBoxCell && (cell.Spec.EditOnClick || cell.Model.IconBound.Contains(cell.PointFromScreen(screenPosition))))
                    EditCheckboxCell();

                var isEditableTriStateCheckBoxCell = IsEditableTriStateCheckboxCell(cell.Model);
                if(isEditableTriStateCheckBoxCell && (cell.Spec.EditOnClick || cell.Model.IconBound.Contains(cell.PointFromScreen(screenPosition))))
                    EditTriStateCheckboxCell();

                var isEditableMultiStateCell = IsEditableMultiStateToggleCell(cell.Model);
                if (isEditableMultiStateCell && (cell.Spec.EditOnClick || cell.Model.IconBound.Contains(cell.PointFromScreen(screenPosition))))
                    EditMultiStateCheckedCell();
            }
        }
        internal void EndSelection(CellViewModel cell, object source, MouseButton button, Point screenPosition)
        {
        }
        internal void SelectCell(CellViewModel cell)
        {
            UnselectCell(cell);

            DataContext.ToggleSelection(cell.TreeNode.Model, cell.Spec, single: Keyboard.Modifiers.HasFlag(ModifierKeys.Control), continuous: Keyboard.Modifiers.HasFlag(ModifierKeys.Shift), toggleSelection: false);
        }
        private void UnselectCell(CellViewModel cell)
        {
            activeColumnHeaderCell = null;

            if (cell != DataContext.ActiveCell && CellEditMode) CellEditorViewModel.CommitCommand.Execute(EditCompleteTrigger.Click);
        }

        internal void BeginSelection(LightGridFilterCell filterCell, object source, MouseButton button, Point screenPosition)
        {
        }
        internal void EndSelection(LightGridFilterCell filterCell, object source, MouseButton button, Point screenPosition)
        {
        }


        private GestureAction[] gestures
        {
            get
            {
                return gesturesField ?? (gesturesField = GetGestureActions());
            }
        }
        private GestureAction[] gesturesField;

        private GestureAction[] GetGestureActions()
        {
            var gestures = new List<GestureAction>
            {
                new GestureAction(Key.F2, ModifierKeys.None, KeyStates.Down, a => DataContext.CellEditorManager.BeginEdit(false)),
                new GestureAction(Key.F, ModifierKeys.Control | ModifierKeys.Shift, KeyStates.Down, a => DataContext.Spec.EnableFilterRow = !DataContext.Spec.EnableFilterRow),
                new GestureAction(Key.Delete, ModifierKeys.None, KeyStates.Down, a => DataContext.CanRemoveRow, a => DataContext.DeleteSelectedNodes()) { Repeat = true },
                new GestureAction(Key.Escape, ModifierKeys.None, KeyStates.Down, a => DataContext.ClearSelection()),
                new GestureAction(Key.C, ModifierKeys.Control, KeyStates.Down, a => ApplicationCommands.Copy.Execute(null, this)),
                new GestureAction(Key.A, ModifierKeys.Control, KeyStates.Down, a => DataContext.SelectAllCommand.Execute()),
                new GestureAction(Key.D, ModifierKeys.Control, KeyStates.Down, a => DataContext.AutoFill.Started || DataContext.Tree.SelectedCount > 0, a => DataContext.AutoFill.RaiseAutoFillEvent(AutoFillDirection.Vertical)),
                new GestureAction(Key.R, ModifierKeys.Control, KeyStates.Down, a => DataContext.AutoFill.Started || DataContext.Tree.SelectedCount > 0, a => DataContext.AutoFill.RaiseAutoFillEvent(AutoFillDirection.Horizontal)),
                new GestureAction(Key.R, ModifierKeys.Control | ModifierKeys.Alt, KeyStates.Down, a => DataContext.ActiveCell != null, a => { DataContext.RowSelectableCommand.Execute(); SelectCell(DataContext.ActiveCell); }),
                new GestureAction(Key.C, ModifierKeys.Control | ModifierKeys.Alt, KeyStates.Down, a => DataContext.ActiveCell != null, a => { DataContext.CellSelectableCommand.Execute(); SelectCell(DataContext.ActiveCell); }),
                new GestureAction(Key.M, ModifierKeys.Control | ModifierKeys.Alt, KeyStates.Down, a => DataContext.ActiveCell != null, a => { DataContext.ModeSelectableCommand.Execute(); SelectCell(DataContext.ActiveCell); }),
                new GestureAction(Key.Space, ModifierKeys.None, KeyStates.Down, a => DataContext.ActiveCell != null && IsEditableCheckBoxCell(DataContext.ActiveCell), a => EditCheckboxCell()),
                new GestureAction(Key.Space, ModifierKeys.None, KeyStates.Down, a => DataContext.ActiveCell != null && DataContext.ActiveCell.TreeNode != null&& DataContext.Spec.GroupingModeColumns.Grouped(DataContext.ActiveCell.Spec), a => DataContext.ToggleNodeExpandCollapse(DataContext.ActiveCell.TreeNode)),
                new GestureAction(ModifierKeys.Control | ModifierKeys.Shift, CanNavigate, Navigate_Ctrl_Shift),
                new GestureAction(ModifierKeys.Control, a => CanNavigate(a) && Keyboard.IsKeyToggled(Key.Scroll) == false, Navigate_Ctrl),
                new GestureAction(ModifierKeys.Control, a => CanNavigate(a) && Keyboard.IsKeyToggled(Key.Scroll), Navigate_Ctrl_ScrollLock){ Repeat = true },
                new GestureAction(ModifierKeys.None, CanNavigate , Navigate) { Repeat = true },
                new GestureAction(ModifierKeys.Shift, CanNavigate , Navigate){ Repeat = true },

                //the rest will just make sure we handle the navigation so that underlying grid won't get it
                new GestureAction(Key.Home, null, KeyStates.Down, a => { }) { Repeat = true },
                new GestureAction(Key.End, null, KeyStates.Down, a => { }) { Repeat = true },
                new GestureAction(Key.Left, null, KeyStates.Down, a => { }) { Repeat = true },
                new GestureAction(Key.Right, null, KeyStates.Down, a => { }) { Repeat = true },
                new GestureAction(Key.Up, null, KeyStates.Down, a => { }) { Repeat = true },
                new GestureAction(Key.Down, null, KeyStates.Down, a => { }) { Repeat = true },
                new GestureAction(Key.PageUp, null, KeyStates.Down, a => { }) { Repeat = true },
                new GestureAction(Key.PageDown, null, KeyStates.Down, a => { }) { Repeat = true }
            };

            if (Owner.EditOnEnter) gestures.Add(new GestureAction(Key.Enter, ModifierKeys.None, KeyStates.Down, a => DataContext.CellEditorManager.BeginEdit(true)));

            return gestures.ToArray();
        }

        private int horizontalOffset { get { return DataContext.ViewportOffset; } set { DataContext.ViewportOffset = value; } }
        private int verticalOffset { get { return DataContext.Tree.ViewportOffset; } set { DataContext.Tree.ViewportOffset = value; } }

        private bool CanNavigate(GestureArgs a)
        {
            if (a.Navigation == NavigationDirection.None) return false;

            var activeNode = DataContext.Tree.Model.ActiveNode;
            var activeSpec = DataContext.Spec.GroupingModeColumns.TryGetVisibleColumnAt(DataContext.Tree.ActiveAttributeIndex);

            return activeNode != null && activeSpec != null;
        }
        private void Navigate(GestureArgs args)
        {
            var activeNode = DataContext.Tree.Model.ActiveNode;
            if (activeNode == null) return;

            switch (args.Navigation)
            {
                case NavigationDirection.Home:
                    horizontalOffset = 0;
                    UpdateSelection(activeNode, 0);
                    break;
                case NavigationDirection.End:
                    horizontalOffset = (int)DataContext.MaximumViewportOffset;
                    UpdateSelection(activeNode, DataContext.Spec.GroupingModeColumns.VisibleColumns.Count() - 1);
                    break;
                default:
                    var activeSpec = DataContext.Spec.GroupingModeColumns.TryGetVisibleColumnAt(DataContext.Tree.ActiveAttributeIndex);
                    DataContext.UpdateViewportOffset(args.Navigation, activeNode, activeSpec);
                    UpdateSelection(activeNode, DataContext.Tree.ActiveAttributeIndex, args.Navigation);
                    break;
            }
        }
        private void Navigate_Ctrl(GestureArgs args)
        {
            var activeNode = DataContext.Tree.Model.ActiveNode;
            if (activeNode == null) return;

            switch (args.Navigation)
            {
                case NavigationDirection.Left:
                    horizontalOffset = 0;
                    DataContext.ToggleSelection(activeNode, 0);
                    break;
                case NavigationDirection.Right:
                    horizontalOffset = (int)DataContext.MaximumViewportOffset;
                    DataContext.ToggleSelection(activeNode, DataContext.Spec.GroupingModeColumns.VisibleColumns.Count() - 1);
                    break;
                case NavigationDirection.Up:
                    verticalOffset = 0;
                    DataContext.ToggleSelection(activeNode, DataContext.ActiveVisibleColumnIndex, navigation: NavigationDirection.Home);
                    break;
                case NavigationDirection.Down:
                    verticalOffset = (int)DataContext.Tree.MaximumViewportOffset;
                    DataContext.ToggleSelection(activeNode, DataContext.ActiveVisibleColumnIndex, navigation: NavigationDirection.End);
                    break;
                case NavigationDirection.Home:
                    horizontalOffset = 0;
                    verticalOffset = 0;
                    DataContext.ToggleSelection(activeNode, 0, navigation: NavigationDirection.Home);
                    break;
                case NavigationDirection.End:
                    horizontalOffset = (int)DataContext.MaximumViewportOffset;
                    verticalOffset = (int)DataContext.Tree.MaximumViewportOffset;
                    DataContext.ToggleSelection(activeNode, DataContext.Spec.GroupingModeColumns.VisibleColumns.Count() - 1, navigation: NavigationDirection.End);
                    break;
                case NavigationDirection.PageUp:
                case NavigationDirection.PageDown:
                    break;
            }
        }
        private void Navigate_Ctrl_ScrollLock(GestureArgs args)
        {
            switch (args.Navigation)
            {
                case NavigationDirection.Left:
                    horizontalOffset -= DataContext.ViewportItemChangeSize;
                    break;
                case NavigationDirection.Right:
                    horizontalOffset += DataContext.ViewportItemChangeSize;
                    break;
                case NavigationDirection.Up:
                    --verticalOffset;
                    break;
                case NavigationDirection.Down:
                    ++verticalOffset;
                    break;
                case NavigationDirection.Home:
                    horizontalOffset = 0;
                    verticalOffset = 0;
                    break;
                case NavigationDirection.End:
                    horizontalOffset += DataContext.ViewportItemChangeSize;
                    verticalOffset = (int)DataContext.Tree.MaximumViewportOffset;
                    break;
                case NavigationDirection.PageUp:
                    verticalOffset -= DataContext.Tree.ViewportSize - 1;
                    break;
                case NavigationDirection.PageDown:
                    verticalOffset += DataContext.Tree.ViewportSize - 1;
                    break;
            }
        }
        private void Navigate_Ctrl_Shift(GestureArgs args)
        {
            var activeNode = DataContext.Tree.Model.ActiveNode;
            if (activeNode == null) return;

            switch (args.Navigation)
            {
                case NavigationDirection.Left:
                    if (DataContext.Spec.SelectionUnit != SelectionUnits.Cell) return;

                    horizontalOffset = 0;
                    DataContext.ToggleSelection(activeNode, 0, false, true);
                    break;
                case NavigationDirection.Right:
                    if (DataContext.Spec.SelectionUnit != SelectionUnits.Cell) return;

                    horizontalOffset = (int)DataContext.MaximumViewportOffset;
                    DataContext.ToggleSelection(activeNode, DataContext.Spec.GroupingModeColumns.VisibleColumns.Count() - 1, false, true);
                    break;
                case NavigationDirection.Up:
                    verticalOffset = 0;
                    DataContext.ToggleSelection(activeNode, DataContext.ActiveVisibleColumnIndex, false, true, navigation: NavigationDirection.Home);
                    break;
                case NavigationDirection.Down:
                    verticalOffset = (int)DataContext.Tree.MaximumViewportOffset;
                    DataContext.ToggleSelection(activeNode, DataContext.ActiveVisibleColumnIndex, false, true, navigation: NavigationDirection.End);
                    break;
                case NavigationDirection.Home:
                    horizontalOffset = 0;
                    verticalOffset = 0;
                    DataContext.ToggleSelection(activeNode, 0, false, true, navigation: NavigationDirection.Home);
                    break;
                case NavigationDirection.End:
                    horizontalOffset = (int)DataContext.MaximumViewportOffset;
                    verticalOffset = (int)DataContext.Tree.MaximumViewportOffset;
                    DataContext.ToggleSelection(activeNode, DataContext.Spec.GroupingModeColumns.VisibleColumns.Count() - 1, false, true, navigation: NavigationDirection.End);
                    break;
                case NavigationDirection.PageUp:
                case NavigationDirection.PageDown:
                    DataContext.ToggleSelection(activeNode, DataContext.ActiveVisibleColumnIndex, false, true, navigation: args.Navigation);
                    break;
            }
        }

        private void UpdateSelection(TreeNodeModel node, int columnIndex, NavigationDirection navigation = NavigationDirection.None)
        {
            UpdateSelection(node, columnIndex, navigation, Keyboard.Modifiers == ModifierKeys.Control, Keyboard.Modifiers == ModifierKeys.Shift);
        }
        private void UpdateSelection(TreeNodeModel node, int columnIndex, NavigationDirection navigation, bool ctrlModifier, bool shiftModifier)
        {
            var grid = DataContext;

            grid.ToggleSelection(node, columnIndex, single: ctrlModifier, continuous: shiftModifier, navigation: navigation);

            if (grid.Spec.SelectionUnit == SelectionUnits.Cell && !((ctrlModifier || shiftModifier) && grid.Tree.SelectedCount > 0))
            {
                grid.Tree.Builder.BeginInvoke(() =>
                {
                    var selected = grid.Tree.ActiveNode;

                    var spec = grid.Tree.ActiveAttribute.Id != 0
                        ? DataContext.Spec.GroupingModeColumns.TryGetVisibleColumnAt(DataContext.Tree.ActiveAttributeIndex)
                        : null;

                    if (grid.Editable && grid.AutoFill.Enabled)
                    {
                        grid.AutoFill.Start(selected, spec, false);
                    }
                });
            }
        }

        public new void Focus()
        {
            Keyboard.Focus(this);
        }

        internal bool ReceivedPreviewMouseDown { get; private set; }

        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseDown(e);

            ReceivedPreviewMouseDown = true;

            if (!(IsFocused || IsKeyboardFocusWithin))
                Focus();
        }

        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseUp(e);

            Dispatcher.BeginInvoke(() => ReceivedPreviewMouseDown = false, DispatcherPriority.Background);
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);

            HoverCell = null;
            Dispatcher.BeginInvoke(() => ReceivedPreviewMouseDown = false, DispatcherPriority.Background);
        }

        protected override void OnPreviewMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            if (CellEditMode) return;

            Focus();
        }
        protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseLeftButtonUp(e);

            if (DataContext.AutoFill.IconClicked)
                DataContext.AutoFill.RaiseAutoFillEvent();
        }
        private Point relativeClickPosition = new Point(double.NegativeInfinity, double.NegativeInfinity);

        private void OnDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var cell = e.Source as LightGridCell;
            if (cell == null || !cell.Model.Active) return;

            if (cell.TreeNode.Leaf == false &&
                (cell.Model.GroupColumn == true || DataContext.Spec.Groups.Contains(cell.Spec)) &&
                cell.Model.GroupIconBound.Contains(TranslatePoint(PointFromScreen(PointToScreen(e.GetPosition(this))), cell)) == false)
            {
                DataContext.SelectAllChildrenCommand.Execute(null);
                return;
            }

            if (!cell.Spec.DataType.IsBoolean()) DataContext.CellEditorManager.BeginEdit(true);
        }

        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if (DataContext.AutoFill.IconClicked) DataContext.AutoFill.End();

            if (CellEditMode) return;

            if (e.Key == Key.OemPlus && DataContext.ActiveCell.Spec.CustomColumn && DataContext.Tree.ActiveNode != null)
            {
                var vm = DataContext.CellEditorManager.GetLightGridCellExpressionEditorViewModel();
                DataContext.CellEditorManager.BeginEdit(false, null, vm);
                e.Handled = true;
            }
            else
            {
                var args = new GestureArgs(e);

                e.Handled = args.Execute(gestures);
            }
        }
        protected override void OnPreviewGotKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            if (gotKeyboardFocus) EndEdit();

            gotKeyboardFocus = true;
        }
        protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            if (!CellEditMode) return;

            gotKeyboardFocus = false;

            if (!(e.NewFocus is DependencyObject) || ((DependencyObject)e.NewFocus).FindParent<CellEditorControl>() != null)
                return;

            CellEditorViewModel.CommitCommand.Execute(EditCompleteTrigger.Click);
        }
        private bool gotKeyboardFocus;

        internal void DropColumns(ColumnSpec targetColumn, bool insertAfter, IList<ColumnSpec> columns, AttributesAddAction addAction = AttributesAddAction.Move, GridViewModel.ColumnTypes columnHint = GridViewModel.ColumnTypes.None)
        {
            firstSelectedColumnHeader = null;

            DataContext.InsertColumns(targetColumn, insertAfter, columns, addAction, columnHint);
        }

        public void DragSelection(Point screenPosition)
        {
            if (dragSelecting) return;
            dragSelecting = true;

            DataContext.Tree.Builder.BeginInvoke(() =>
            {
                Dispatcher.BeginInvoke(() =>
                {
                    dragSelecting = false;

                    var grid = DataContext;
                    if (Mouse.LeftButton != MouseButtonState.Pressed || (DataContext.Spec.SelectionMode != SelectionModes.Drag && !grid.AutoFill.IconClicked)) return;

                    var hit = VisualTreeHelper.HitTest(this, screenPosition);
                    var hitCell = hit == null ? null : hit.VisualHit.FindParentObjectByType<LightGridCell>();

                    if (hitCell == null || hitCell.Spec == null || hitCell.TreeNode == null || hitCell.TreeNode.Model == null) return;

                    var activeNode = hitCell.TreeNode.Model;
                    var activeSpec = hitCell.Spec;

                    var position = PointFromScreen(screenPosition);

                    var gridBound = new Rect(new Size(ActualWidth, ActualHeight));

                    var ctrlModifier = Keyboard.Modifiers.HasFlag(ModifierKeys.Control);
                    var shiftModifier = true;

                    if (grid.AutoFill.IconClicked)
                    {
                        AutoFillDirection autoFillNav;
                        if (position.Y < gridBound.Top || position.Y > gridBound.Bottom) autoFillNav = AutoFillDirection.Vertical;
                        else autoFillNav = AutoFillDirection.Horizontal;

                        if (!DataContext.AutoFill.CheckAutoFillPossible(activeNode, activeSpec, autoFillNav))
                            return; // Check if drag selection possible for Auto fill

                        ctrlModifier = false;
                    }

                    var navigation = NavigationDirection.None;
                    if (position.Y > gridBound.Bottom) navigation = NavigationDirection.Down;
                    else if (position.Y < gridBound.Top) navigation = NavigationDirection.Up;
                    else if (position.X > gridBound.Right) navigation = NavigationDirection.Right;
                    else if (position.X < gridBound.Left) navigation = NavigationDirection.Left;
                    if (navigation == NavigationDirection.None) return;

                    UpdateSelection(activeNode, grid.Spec.GroupingModeColumns.IndexOfVisibleColumn(activeSpec), navigation, ctrlModifier, shiftModifier);
                }, DispatcherPriority.Background);
            });
        }
        private bool dragSelecting;

        protected override void OnPreviewTextInput(TextCompositionEventArgs e)
        {
            base.OnPreviewTextInput(e);

            if (CellEditMode) return;
            if (Keyboard.Modifiers != ModifierKeys.None && Keyboard.Modifiers != ModifierKeys.Shift) return;
            if (string.IsNullOrEmpty(e.Text)) return;
            if (e.Text.Length == 1 && Char.IsControl(e.Text[0])) return;

            DataContext.CellEditorManager.BeginEdit(false, e.Text);
        }

        protected override void OnPreviewKeyUp(KeyEventArgs e)
        {
            e.Handled = true;
        }


        private void UpdateRowDragState()
        {
            Owner.DragDropHandler.IsDataRowDragDisabled = DataContext.Spec.SelectionMode == SelectionModes.Drag || !DataContext.EnableRowDrag;
        }


        public CustomPopupPlacementCallback ToolBarPopupPlacementCallback { get { return CalculateToolBarPopupPlacement; } }
        public CustomPopupPlacement[] CalculateToolBarPopupPlacement(Size popupSize, Size targetSize, Point offset)
        {
            var placement2 = new CustomPopupPlacement(new Point(0, 0), PopupPrimaryAxis.Horizontal);

            CustomPopupPlacement[] ttplaces = { placement2 };

            return ttplaces;
        }


        internal static readonly Pen Pen;
        internal static readonly Color Pen_color = Colors.Transparent;
        internal const double Pen_size = 1;

        internal static readonly Pen PenFocused;
        internal static readonly Color PenFocused_color = Colors.Gray;
        internal const double PenFocused_size = 2;

        internal static readonly Pen PenTopTotals;
        internal static readonly Color PenTopTotals_color = Colors.LightGray;
        internal static readonly double PenTopTotals_size = 1;

        internal const double PenBorder_size = 2;

        internal Color EditIndicator_color { get; private set; }
        internal SolidColorBrush EditIndicator_brush { get; private set; }
        internal Pen EditIndicator_pen { get; private set; }
        internal Pen EditIndicator_penFocused { get; private set; }



        #region Cell Editing

        private bool editOnActive;
        private AttributeKey editOnActiveAttribute;
        private TreeNodeModel editOnActiveNode;
        private void DataContext_Tree_EditCellEvent(TreeNodeModel treeNodeModel, AttributeKey attributeKey)
        {
            Dispatcher.BeginInvoke(() =>
            {
                editOnActiveAttribute = attributeKey;
                editOnActiveNode = treeNodeModel;

                editOnActive = true;

               DataContext.CellEditorManager.BeginEdit(false);
            }, DispatcherPriority.Background);
        }
        private void DataContext_Tree_Builder_OutputCleared()
        {
            if (!CellEditMode) return;

            Dispatcher.BeginInvoke(() => EndEdit(false), DispatcherPriority.Background);
        }

        public static readonly DependencyProperty CellEditTemplateProperty = DependencyProperty.Register("CellEditTemplate", typeof(ControlTemplate), typeof(LightGridPanel), new FrameworkPropertyMetadata());
        public ControlTemplate CellEditTemplate { get { return (ControlTemplate)GetValue(CellEditTemplateProperty); } set { SetValue(CellEditTemplateProperty, value); } }

        public bool CellEditMode { get { return CellEditorViewModel != null; } }
        private readonly CellEditorControl cellEditorControl = new CellEditorControl();
        internal LightGridCellEditorViewModel CellEditorViewModel { get { return DataContext.CellEditorManager.CellEditorViewModel; } }
        private readonly SingleAndDoubleClickHelper singleAndDoubleClickHelper;

        private bool ActiveCellEditable()
        {
            if(DataContext.ActiveCell == null || DataContext.ActiveCell.TreeNode == null || DataContext.ActiveCell.Spec == null)
                return false;

            if(DataContext.ActiveCell.Editable == false)
                return false;

            return true;
        }

        private void EditCheckboxCell()
        {
            if (!ActiveCellEditable()) return;

            DataContext.CellEditorManager.BeginEdit(false);
            if(CellEditorViewModel is LightGridCellExpressionEditorViewModel<bool?>) return;

            ToggleCellChecked();
            EndEdit(true, EditCompleteTrigger.Click);
        }
        private void ToggleCellChecked()
        {
            if (!CellEditMode) return;

            var viewModel = CellEditorViewModel as LightGridCellEditorViewModel<bool>;
            if (viewModel != null) viewModel.EditData = !viewModel.EditData;

            CellEditorViewModel.CommitCommand.Execute(EditCompleteTrigger.Click);
        }

        private void EditTriStateCheckboxCell()
        {
            if (!ActiveCellEditable()) return;

            DataContext.CellEditorManager.BeginEdit(false);
            if (CellEditorViewModel is LightGridCellExpressionEditorViewModel<bool?>) return;

            ToggleTriStateChecked();
            EndEdit(true, EditCompleteTrigger.Click);
        }
        private void ToggleTriStateChecked()
        {
            if (!CellEditMode) return;

            var viewModel = CellEditorViewModel as LightGridCellEditorViewModel<bool?>;
            if (viewModel != null)
            {
                if (viewModel.EditData == true) viewModel.EditData = false;
                else if (viewModel.EditData == false) viewModel.EditData = null;
                else viewModel.EditData = true;
            }

            CellEditorViewModel.CommitCommand.Execute(EditCompleteTrigger.Click);
        }

        private void EditMultiStateCheckedCell()
        {
            if (!ActiveCellEditable()) return;

            DataContext.CellEditorManager.BeginEdit(false);
            if (CellEditorViewModel is LightGridCellExpressionEditorViewModel<bool?>) return;

            ToggleCellMultiStateChecked();
            EndEdit(true, EditCompleteTrigger.Click);
        }
        private void ToggleCellMultiStateChecked()
        {
            if (!CellEditMode || !DataContext.ActiveCell.Spec.Toggleable) return;

            var viewModel = CellEditorViewModel as IIterator;
            if (viewModel != null) viewModel.Next();

            CellEditorViewModel.CommitCommand.Execute(EditCompleteTrigger.Click);
        }

        private void DataContext_EditStarting(EditStartEventArgs editStartEventArgs)
        {
            if (beginEditEntered || beginEditInternalEntered) return;
            if (!IsKeyboardFocusWithin) return;
            if (!ActiveCellEditable()) return;
            if (DataContext.ActiveCell.Spec.DataType.IsEnum && DataContext.ActiveCell.Spec.Icons.Length != 0) return;
            if (DataContext.ActiveCell.Visible == false) return;

            beginEditEntered = true;

            var savedActiveCell = DataContext.ActiveCell;
            if (!(CellEditorViewModel is LightGridCellExpressionEditorViewModel<bool?>) && DataContext.ActiveCell.Spec.DataType.IsBoolean())
            {
                BeginEditInternal(savedActiveCell, editStartEventArgs);
            }
            
            else Dispatcher.BeginInvoke(() => BeginEditInternal(savedActiveCell, editStartEventArgs), DispatcherPriority.Background);
        }

        private bool beginEditEntered;
        private bool beginEditInternalEntered;
        private void BeginEditInternal(CellViewModel activeCell, EditStartEventArgs eventArgs)
        {
            if (beginEditInternalEntered) return;
            if (eventArgs.Cancel) return;
            if (!ActiveCellEditable()) return;
            if (activeCell.Spec != null && (!ReferenceEquals(DataContext.ActiveCell, activeCell) && activeCell.Spec.DataType != typeof(Boolean))) return;

            ClearCellEditor();

            // Get cell edit view model
            beginEditInternalEntered = true;

            DataContext.CellEditorManager.InvokeEditStarted(eventArgs);
            CellEditorViewModel.SelectAllOnStart = eventArgs.SelectAll;
            CellEditorViewModel.Committed += CellEditorViewModel_Committed;
            CellEditorViewModel.Reverted += CellEditorViewModel_Reverted;

            if ((CellEditorViewModel is LightGridCellExpressionEditorViewModel<bool?>) || (DataContext.ActiveCell.Spec.DataType != typeof(Boolean) && !DataContext.ActiveCell.Spec.Toggleable))
            {
                cellEditorControl.Cell = DataContext.ActiveCell;
                cellEditorControl.DataContext = CellEditorViewModel;
            }
        }

        internal void EndEdit(bool commit = true, EditCompleteTrigger trigger = EditCompleteTrigger.None)
        {
            if (beginEditEntered == false && beginEditInternalEntered == false) return;
            beginEditEntered = false;

            if (!CellEditMode) return;

            var isValid = IsEditDataValid();
            var eventArgs = new EditEndEventArgs(CellEditorViewModel.OriginalNode.Model, CellEditorViewModel.Spec, trigger, GetEditData(), isValid && commit);

            DataContext.CellEditorManager.InvokeEditEnding(eventArgs);

            EndEditInternal(eventArgs);
        }

        private bool IsEditDataValid()
        {
            if (CellEditorViewModel is LightGridCellEditorViewModel<bool> || CellEditorViewModel is LightGridCellEditorViewModel<bool?>) return true;
            return CellEditorViewModel.Validate(GetEditData());
        }
        private object GetEditData()
        {
            if (CellEditorViewModel is LightGridCellEditorViewModel<bool>) return ((LightGridCellEditorViewModel<bool>) CellEditorViewModel).EditData;
            if (CellEditorViewModel is LightGridCellEditorViewModel<bool?>) return ((LightGridCellEditorViewModel<bool?>)CellEditorViewModel).EditData;
            return cellEditorControl.GetEditData();
        }
        internal void EndEditInternal(EditEndEventArgs eventArgs)
        {
            if (beginEditEntered == false && beginEditInternalEntered == false) return;
            beginEditEntered = beginEditInternalEntered = false;

            if (eventArgs.Cancel) return;

            if (endingEditing) return;
            endingEditing = true;

            if (eventArgs.Commit)
            {
                cellEditorControl.UpdateEditData();
                CellEditorViewModel.UpdateData(EditCompleteTrigger.None);
            }

            switch (eventArgs.Trigger)
            {
                case EditCompleteTrigger.Tab: DataContext.ToggleSelection(CellEditorViewModel.Model, CellEditorViewModel.Spec, navigation: NavigationDirection.Right); break;
                case EditCompleteTrigger.ShiftTab: DataContext.ToggleSelection(CellEditorViewModel.Model, CellEditorViewModel.Spec, navigation: NavigationDirection.Left); break;
                case EditCompleteTrigger.Enter: DataContext.ToggleSelection(CellEditorViewModel.Model, CellEditorViewModel.Spec); break;
                case EditCompleteTrigger.Esc: DataContext.ToggleSelection(CellEditorViewModel.Model, CellEditorViewModel.Spec); break;
            }

            Dispatcher.BeginInvoke(() =>
            {
                endingEditing = false;
                if (DataContext == null) return;

                ClearCellEditor();

                DataContext.CellEditorManager.InvokeEditEnded(eventArgs);

                if (IsKeyboardFocusWithin)
                    Focus();

                BeginResetRows();
            }, DispatcherPriority.Background);
        }
        private bool endingEditing;

        private void EndEditIfNeeded()
        {
            if (!CellEditMode) return;

            if (cellEditorControl.Cell == null
                || cellEditorControl.Spec != cellEditorControl.Cell.Spec
                || TreeNodeViewModel.IdEquals(cellEditorControl.TreeNode, cellEditorControl.Cell.TreeNode) == false
                || cellEditorControl.Top != cellEditorControl.Cell.Top
                || cellEditorControl.Left != cellEditorControl.Cell.Left)
                EndEdit();
        }

        private void ClearCellEditor()
        {
            if (!CellEditMode) return;

            cellEditorControl.DataContext = null;
            cellEditorControl.Cell = null;

            CellEditorViewModel.Committed -= CellEditorViewModel_Committed;
            CellEditorViewModel.Reverted -= CellEditorViewModel_Reverted;
            CellEditorViewModel.Dispose();
        }

        private void CellEditorViewModel_Committed(EditCompleteTrigger trigger)
        {
            EndEdit(true, trigger);
        }
        private void CellEditorViewModel_Reverted()
        {
            EndEdit(false, EditCompleteTrigger.Esc);
        }

        private bool IsEditableCheckBoxCell(CellViewModel cell)
        {
            if (cell == null || cell.Spec == null) return false;

            return cell.Editable && cell.Spec.DataType == typeof(bool);
        }
        private bool IsEditableTriStateCheckboxCell(CellViewModel cell)
        {
            if (cell == null || cell.Spec == null) return false;

            return cell.Editable && cell.Spec.DataType == typeof(bool?);
        }
        private bool IsEditableMultiStateToggleCell(CellViewModel cell)
        {
            if (cell == null || cell.Spec == null) return false;

            return cell.Editable && (cell.Spec.DataType.IsEnum || cell.Spec.Toggleable);
        }

        #endregion
    }
}
