﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Data;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Formatting;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class ThinGridColumn : DependencyObject
    {
        public GridSpec Grid { get; internal set; }
        public ColumnSpec Spec { get; internal set; }


        public static readonly DependencyProperty HeaderProperty = DependencyProperty.Register("Header", typeof(string), typeof(ThinGridColumn), new PropertyMetadata(null));
        public string Header { get { return (string)GetValue(HeaderProperty); } set { SetValue(HeaderProperty, value); } }

        public static readonly DependencyProperty LabelProperty = DependencyProperty.Register("Label", typeof(string), typeof(ThinGridColumn), new PropertyMetadata(null));
        public string Label { get { return (string)GetValue(LabelProperty); } set { SetValue(LabelProperty, value); } }

        public static readonly DependencyProperty HeaderImageSourceProperty = DependencyProperty.Register("Image", typeof(string), typeof(ThinGridColumn), new PropertyMetadata(null));
        public string Image { get { return (string)GetValue(HeaderImageSourceProperty); } set { SetValue(HeaderImageSourceProperty, value); } }

        public static readonly DependencyProperty ToolTipProperty = DependencyProperty.Register("ToolTip", typeof(string), typeof(ThinGridColumn), new PropertyMetadata(null));
        public string ToolTip { get { return (string)GetValue(ToolTipProperty); } set { SetValue(ToolTipProperty, value); } }

        public static readonly DependencyProperty EditableProperty = DependencyProperty.Register("Editable", typeof(bool), typeof(ThinGridColumn), new PropertyMetadata(false));
        public bool Editable { get { return (bool)GetValue(EditableProperty); } set { SetValue(EditableProperty, value); } }

        public static readonly DependencyProperty VisibleProperty = DependencyProperty.Register("Visible", typeof(bool), typeof(ThinGridColumn), new FrameworkPropertyMetadata(true, (d, a) => ((ThinGridColumn)d).OnVisibleChanged((bool)a.NewValue)));
        public bool Visible { get { return (bool)GetValue(VisibleProperty); } set { SetValue(VisibleProperty, value); } }
        private void OnVisibleChanged(bool visible) { if (Spec != null) Spec.Visible = visible; }

        public static readonly DependencyProperty FixedWidthProperty = DependencyProperty.Register("FixedWidth", typeof(bool), typeof(ThinGridColumn), new PropertyMetadata(false));
        public bool FixedWidth { get { return (bool)GetValue(FixedWidthProperty); } set { SetValue(FixedWidthProperty, value); } }

        public static readonly DependencyProperty WidthProperty = DependencyProperty.Register("Width", typeof(double), typeof(ThinGridColumn), new PropertyMetadata(80D));
        public double Width { get { return (double)GetValue(WidthProperty); } set { SetValue(WidthProperty, value); } }

        public static readonly DependencyProperty HorizontalAlignmentProperty = DependencyProperty.Register("HorizontalAlignment", typeof(HorizontalAlignment), typeof(ThinGridColumn), new PropertyMetadata(HorizontalAlignment.Stretch));
        public HorizontalAlignment HorizontalAlignment { get { return (HorizontalAlignment)GetValue(HorizontalAlignmentProperty); } set { SetValue(HorizontalAlignmentProperty, value); } }

        public static readonly DependencyProperty VerticalAlignmentProperty = DependencyProperty.Register("VerticalAlignment", typeof(VerticalAlignment), typeof(ThinGridColumn), new PropertyMetadata(VerticalAlignment.Stretch));
        public VerticalAlignment VerticalAlignment { get { return (VerticalAlignment)GetValue(VerticalAlignmentProperty); } set { SetValue(VerticalAlignmentProperty, value); } }


        public static readonly DependencyProperty EditOnClickProperty = DependencyProperty.Register("EditOnClick", typeof(bool), typeof(ThinGridColumn), new PropertyMetadata(false));
        public bool EditOnClick { get { return (bool)GetValue(EditOnClickProperty); } set { SetValue(EditOnClickProperty, value); } }

        public static readonly DependencyProperty AllowNullProperty = DependencyProperty.Register("AllowNull", typeof(bool), typeof(ThinGridColumn), new PropertyMetadata(false));
        public bool AllowNull { get { return (bool)GetValue(AllowNullProperty); } set { SetValue(AllowNullProperty, value); } }

        public static readonly DependencyProperty ToggleableProperty = DependencyProperty.Register("Toggleable", typeof(bool), typeof(ThinGridColumn), new PropertyMetadata(false));
        public bool Toggleable { get { return (bool)GetValue(ToggleableProperty); } set { SetValue(ToggleableProperty, value); } }


        public static readonly DependencyProperty ScalingProperty = DependencyProperty.Register("Scaling", typeof(double), typeof(ThinGridColumn), new PropertyMetadata((double)1));
        public double Scaling { get { return (double)GetValue(ScalingProperty); } set { SetValue(ScalingProperty, value); } }

        public static readonly DependencyProperty DecimalPlacesProperty = DependencyProperty.Register("DecimalPlaces", typeof(int?), typeof(ThinGridColumn), new PropertyMetadata((int)0));
        public int? DecimalPlaces { get { return (int)GetValue(DecimalPlacesProperty); } set { SetValue(DecimalPlacesProperty, value); } }

        public static readonly DependencyProperty UseSeparatorProperty = DependencyProperty.Register("UseSeparator", typeof(bool), typeof(ThinGridColumn));
        public bool UseSeparator { get { return (bool)GetValue(UseSeparatorProperty); } set { SetValue(UseSeparatorProperty, value); } }

        public static readonly DependencyProperty TypeDescriptorProperty = DependencyProperty.Register("TypeDescriptor", typeof(TypeDescriptor), typeof(ThinGridColumn));
        public TypeDescriptor TypeDescriptor { get { return (TypeDescriptor)GetValue(TypeDescriptorProperty); } set { SetValue(TypeDescriptorProperty, value); } }

        public static readonly DependencyProperty FormatInfoProperty = DependencyProperty.Register("FormatInfo", typeof(FormatInfoItem), typeof(ThinGridColumn));
        public FormatInfoItem FormatInfo { get { return (FormatInfoItem)GetValue(FormatInfoProperty); } set { SetValue(FormatInfoProperty, value); } }

        public static readonly DependencyProperty EditValueConverterProperty = DependencyProperty.Register("EditValueConverter", typeof(IValueConverter), typeof(ThinGridColumn));
        public IValueConverter EditValueConverter { get { return (IValueConverter)GetValue(EditValueConverterProperty); } set { SetValue(EditValueConverterProperty, value); } }

        public static readonly DependencyProperty EditTemplateKeyProperty = DependencyProperty.Register("EditTemplateKey", typeof(string), typeof(ThinGridColumn));
        public string EditTemplateKey { get { return (string)GetValue(EditTemplateKeyProperty); } set { SetValue(EditTemplateKeyProperty, value); } }
    }

    public class ThinGridColumnCollection : ObservableCollection<ThinGridColumn>
    {
    }
}
