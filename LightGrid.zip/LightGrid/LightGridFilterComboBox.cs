using System;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Formatting;
using Wells.Derivatives.Carina.Core.Threading;

namespace Wells.Derivatives.Carina.Core.Presentation.LightGrid
{
    public class LightGridFilterComboBox : ComboBox
    {
        static LightGridFilterComboBox()
        {
            DataContextProperty.OverrideMetadata(typeof(LightGridFilterComboBox), new FrameworkPropertyMetadata((d, a) => ((LightGridFilterComboBox)d).OnDataContextChanged((LightGridFilterCell)a.OldValue, (LightGridFilterCell)a.NewValue), (d, v) => v as LightGridFilterCell));
        }
        public LightGridFilterComboBox()
        {
            HorizontalAlignment = HorizontalAlignment.Stretch;
            VerticalAlignment = VerticalAlignment.Center;
            Background = Brushes.Transparent;

            SelectedValuePath = "Source";

            delayedApply = Delayed.Delay(TimeSpan.FromMilliseconds(300)).Dispatcher(Dispatcher);
        }
        private readonly DelayedAction delayedApply;

        public new LightGridFilterCell DataContext { get { return dataContext; } set { base.DataContext = value; } } private LightGridFilterCell dataContext;
        private void OnDataContextChanged(LightGridFilterCell oldValue, LightGridFilterCell newValue)
        {
            if (oldValue != null)
            {
                Spec = null;
            }

            dataContext = newValue;

            if (newValue != null)
            {
                Spec = DataContext.Spec;
            }
        }

        public ColumnSpec Spec { get { return spec; } internal set { if (spec == value) return; var oldValue = spec; spec = value; OnSpecChanged(oldValue, spec); } } private ColumnSpec spec;

        private void OnSpecChanged(ColumnSpec oldValue, ColumnSpec newValue)
        {
            if (oldValue != null) oldValue.PropertyChanged -= Spec_PropertyChanged;

            if (newValue != null) newValue.PropertyChanged += Spec_PropertyChanged;

            if(Spec != null)
            {
                CalculateDependencies();
                CalculateSelectedValue();
            }
        }
        private void Spec_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if(Spec == null) return;

            if(e.PropertyName == "FilterValue") CalculateSelectedValue();
            else if(e.PropertyName == "TypeDescriptor")
            {
                CalculateDependencies();
                CalculateSelectedValue();
            }
        }
        private void CalculateDependencies()
        {
            ItemsSource = Spec.TypeDescriptor.Values.Select(e => new LightGridEnumFilterType(Spec, e));
        }
        private void CalculateSelectedValue()
        {
            if(Spec.DataType.IsEnum)
            {
                SelectedValue = Spec.TypeDescriptor.Values.FirstOrDefault(v => v.Value == Spec.FilterValue);
            }
            else
            {
                var filterValue = Spec.FilterValue == null ? string.Empty : Spec.FilterValue.ToString();

                SelectedValue = string.Equals(filterValue, "true", StringComparison.CurrentCultureIgnoreCase)
                    ? Spec.TypeDescriptor.Values[0]
                    : string.Equals(filterValue, "false", StringComparison.CurrentCultureIgnoreCase)
                        ? Spec.TypeDescriptor.Values[1]
                        : null;
            }
        }


        protected override void OnSelectionChanged(SelectionChangedEventArgs e)
        {
            base.OnSelectionChanged(e);

            if (e.AddedItems.Count > 0)
            {
                var selectedItem = e.AddedItems[0];
                var spec = Spec;
                var grid = DataContext.Grid;
                if (grid == null) return;

                object value = null;

                if (selectedItem is LightGridEnumFilterType)
                {
                    var filterEnum = (LightGridEnumFilterType)selectedItem;
                    value = filterEnum.Source.Value;
                }

                delayedApply.Action(() =>
                {
                    if(spec != Spec) return;

                    spec.FilterValue = value;
                    grid.PostFilterManager.UpdateFilter(spec);
                }).Execute();
            }
        }
    }

    public class LightGridEnumFilterType : IEquatable<LightGridEnumFilterType>
    {
        public LightGridEnumFilterType(ColumnSpec spec, ValueDescriptor source)
        {
            Spec = spec;
            Source = source;
            Image = Spec.GetFormatImage(source).IconDefault;
            Description = Spec.CalculateFormattedText(source, Spec.FormatInfo);
        }


        public string Description { get; private set; }

        public ValueDescriptor Source { get; private set; }

        public ImageSource Image { get; private set; }

        public ColumnSpec Spec { get; private set; }


        public bool Equals(LightGridEnumFilterType other)
        {
            return other != null && Source.Equals(other.Source);
        }
    }
}
