"use strict";
{
    Carina.Core.BaseControl = class 
    {
        constructor()
        {
            this.dataContext = null;
            this.element = null;
            this.parent = null;
        }

        get DataContext() { return this.dataContext; }
        set DataContext(value)
        {
            let oldValue = this.dataContext;
            this.dataContext = value;
            this.OnDataContextChanged(oldValue, value);
        }
        OnDataContextChanged(oldValue, newValue){}

        get Element() { return this.element; }
        set Element(value) { this.element = value; }

        get Parent() { return this.parent; }
        set Parent(value) { this.parent = value; }

        get Height() { return this.element ? this.element.offsetHeight : 0; }
        set Height(value) { this.element.style["height"] = value + "px"; }

        get Width() { return this.element ? this.element.offsetWidth : 0; }
        set Width(value) { this.element.style["width"] = value + "px"; }

        Attribute(key, value) { this.element.setAttribute(key, value); }

        Style(key, value) { this.element.style[key] = value; }
    }

    Carina.Core.DivControl = class extends Carina.Core.BaseControl
    {
        constructor(id)
        {
            super();
            this.Element = document.createElement("div");
            if (id) this.Element.id = id;
        }
    }

    Carina.Core.BaseComponent = class extends Carina.Core.BaseControl
    {
        constructor()
        {
            super();
        }
    }
}