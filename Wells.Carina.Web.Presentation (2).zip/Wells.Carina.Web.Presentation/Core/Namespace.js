﻿// This file is to define namespaces
        Carina = {};
        Carina.Core = {};
        Carina.Server = {};
        Carina.ViewModel = {};
        Carina.Model = {};
        Carina.LightGrid = {};
        Carina.View = {};
