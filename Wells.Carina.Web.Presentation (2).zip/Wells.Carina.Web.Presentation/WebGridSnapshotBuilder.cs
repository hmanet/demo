﻿using System.Linq;
using System.Collections.Generic;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Responses;
using Wells.Carina.Web.Presentation.Utilities;
using Wells.Carina.Web.Presentation.ViewModel;
using Wells.Derivatives.Carina.Core.Presentation.Grid;

namespace Wells.Carina.Web.Presentation
{
    public interface IWebLightGridSnapshotBuilder
    {
        IWebLightGridSnapshotBuilder CreateHorizontalViewPort();

        IWebLightGridSnapshotBuilder CreateVerticalViewPort();

        IWebLightGridSnapshotBuilder CreateColumnSpecs();

        IWebLightGridSnapshotBuilder CreateCells();

        SnapshotResponse Build();
    }

    /// <summary>
    /// Creates the Snapshot response from the source GridViewModel
    /// </summary>
    public class WebLightGridSnapshotBuilder : IWebLightGridSnapshotBuilder
    {
        public WebLightGridSnapshotBuilder(WebLightGridViewModel gridViewModel)
        {
            webLightGridViewModel = gridViewModel;
        }

        private readonly WebLightGridViewModel webLightGridViewModel;

        private ViewPort verticalViewPort;

        private ViewPort horizonatlViewPort;

        private List<LightGridColumn> lightGridColumns;

        private List<LightGridCell> lightGridCells;

        //private FormatInfo Mapper(ColumnSpec columnSpec)
        //{
        //    FormatInfo formatInfo
        //}


        public IWebLightGridSnapshotBuilder CreateHorizontalViewPort()
        {
            horizonatlViewPort = new ViewPort
            {
                Size = webLightGridViewModel.Grid.ViewportSize,
                Offset = webLightGridViewModel.Grid.ViewportOffset
            };

            return this;
        }

        public IWebLightGridSnapshotBuilder CreateVerticalViewPort()
        {
            verticalViewPort = new ViewPort
            {
                Size = webLightGridViewModel.Grid.Tree.ViewportSize,
                Offset = webLightGridViewModel.Grid.Tree.ViewportOffset,
                Count = webLightGridViewModel.Grid.Tree.TotalCount
            };

            return this;
        }

        public IWebLightGridSnapshotBuilder CreateColumnSpecs()
        {
            lightGridColumns = webLightGridViewModel.Grid.Columns.Select(MappingHelper.Map).ToList();

            return this;
        }

        public IWebLightGridSnapshotBuilder CreateCells()
        {
            lightGridCells = new List<LightGridCell>();
            int rowIndex = 0;
            var columnSpecs = webLightGridViewModel.Grid.Columns;

            foreach (var row in webLightGridViewModel.Grid.Tree.Nodes)
            {
                var columnIndex = 0;
                foreach (ColumnSpec column in columnSpecs)
                {
                    var cell = new LightGridCell
                    {
                        ColumnIndex = columnIndex++,
                        RowIndex = rowIndex,
                        Left = column.Left,
                        Top = row.Top,
                        Data = column.CalculateFormattedText(row.Data[column.Key], column.FormatInfo)
                    };
                    cell.FormatInfo = new FormatInfo();
                    {
                        
                    }
                    var triggerStyle = webLightGridViewModel.Grid.Triggers.Evaluate(webLightGridViewModel.Grid.Tree.Model, row.Model, row.Model, column.Key, column);
                    if (!Equals(triggerStyle, TriggerStyle.Empty))
                    {
                        cell.FormatInfo = MappingHelper.Map(triggerStyle);
                    }

                    lightGridCells.Add(cell);
                }

                rowIndex++;
            }

            return this;
        }

        public SnapshotResponse Build()
        {
            SnapshotResponse snapshot = new SnapshotResponse
            {
                VerticalViewport = verticalViewPort,
                HorizontalViewport = horizonatlViewPort,
                Columns = lightGridColumns,
                Cells = lightGridCells,
                GridId = webLightGridViewModel.GridId
            };

            return snapshot;
        }
    }
}
