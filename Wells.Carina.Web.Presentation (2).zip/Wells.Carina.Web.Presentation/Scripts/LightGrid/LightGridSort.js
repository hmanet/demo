﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.LightGrid.LightGridSort = class extends Core.BaseControl {
        constructor(parent) {
            super();

            this.Parent = parent;
            this.Element = document.createElement("div");
            this.Element.innerText = "aa";

        }

        Render() { }
    }
}