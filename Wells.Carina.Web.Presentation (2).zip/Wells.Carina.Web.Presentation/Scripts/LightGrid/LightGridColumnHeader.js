﻿"use strict";
{
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;

    Carina.LightGrid.LightGridColumnHeader = class extends Core.BaseControl
    {
        constructor()
        {
            super();
            this.Element = document.createElement("div");
            this.columnSpec = null;
            this.AddClass("lightGrid-lightGridColumnHeader");
            this.sort = new LightGrid.LightGridSort(this);
            this.AppendChild(this.sort.Element);

        }

        Render(columnSpec)
        {
            if (this.Compare(columnSpec)) return;
            this.sort = new LightGrid.LightGridSort(this);
            this.AppendChild(this.sort.Element);

            this.columnSpec = columnSpec;

            this.Width = this.columnSpec.Width;
            this.Element.innerText = this.columnSpec.Name;
            this.Style("left", this.columnSpec.Left + "px");
            this.Style("backgroundColor", this.columnSpec.Background);
            this.Style("font-family", this.columnSpec.FontFamily);
            this.Style("font-style", this.columnSpec.FontStyle);
            this.Style("font-weight", this.columnSpec.FontWeight);
            this.Style("font-size", this.columnSpec.FontSize + "px");
            
            //this.Style("border", this.columnSpec.CellBorder);
            //this.Style("visibility", this.columnSpec.Visible);
            //this.Style("color", this.columnSpec.Foreground);
        }

        Compare(columnSpec)
        {
            return this.columnSpec != null &&
                columnSpec.Name === this.columnSpec.Name &&
                columnSpec.Left === this.columnSpec.Left &&
                columnSpec.Width === this.columnSpec.Width &&
                columnSpec.Background === this.columnSpec.Background &&
                columnSpec.FontFamily === this.columnSpec.FontFamily &&
                columnSpec.FontStyle === this.columnSpec.FontStyle &&
                columnSpec.FontWeight === this.columnSpec.FontWeight &&
                columnSpec.FontSize === this.columnSpec.FontSize;
        }
    }
}
