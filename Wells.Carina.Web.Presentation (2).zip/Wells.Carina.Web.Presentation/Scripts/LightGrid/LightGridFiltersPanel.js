﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.LightGrid.LightGridFiltersPanel = class extends Core.BaseControl
    {
        constructor(parent)
        {
            super();

            this.Parent = parent;
            this.Element = document.createElement("div");
            this.AddClass("lightGrid-filtersPanel");
        }

        Render(){}
    }
}