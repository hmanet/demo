﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let Grid = Carina.LightGrid;

    Carina.LightGrid.LightGridPanel = class extends Core.BaseControl
    {
        constructor(parent)
        {
            super();

            this.Parent = parent;
            this.cells = [];
            this.isFirstRender = true;

            this.Element = document.createElement("div");
            this.Attribute("name", "LightGridPanel");
            this.AddClass("lightGrid-gridPanel");
        }

        Reset()
        {
            this.cells = [];
            this.isFirstRender = true;
            Core.UiUtil.RemoveChildren(this.Element);
        }

        Render(snapshot)
        {
            // console.log(snapshot);
            if (this.isFirstRender)
            {
                this.isFirstRender = false;
                let cellHeight = this.Parent.Spec.RowHeight;
                let headersize = new Grid.LightGridColumnHeader(this.Parent.Spec);

                this.Width = headersize.width;

                for (let i = 0; i < snapshot.Cells.length; i++)
                {
                    let cell = new Grid.LightGridCell(snapshot.Cells[i]);
                    cell.SetHeight(cellHeight);
                    this.AppendChild(cell);
                    this.cells.push(cell);
                    cell.CellRender(snapshot.Cells[i], snapshot.Columns[snapshot.Cells[i].ColumnIndex]);
                }
            }
            else
            {
                for (let i = 0, len = snapshot.Cells.length; i !== len; i++)
                {
					// TODO: Remove
                    if (!this.cells[i]) break;

                    this.cells[i].CellRender(snapshot.Cells[i], snapshot.Columns[snapshot.Cells[i].ColumnIndex]);
                }
            }
        }
    }
}