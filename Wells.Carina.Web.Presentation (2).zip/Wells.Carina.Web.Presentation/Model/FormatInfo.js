
"use strict";

function FormatInfo(data)
{
    this.Editable = data.Editable;
    this.Foreground = data.Foreground;
    this.Background = data.Background;
    this.FontFamily = data.Editable;
    this.FontWeight = data.FontWeight;
    this.FontStyle = data.FontStyle;
    this.FontSize = data.FontSize;
    this.Visible = data.Visible;
    this.Strikethrough = data.Strikethrough;
    this.Underline = data.Underline;
}