"use strict";
{
    let Model = Carina.Model;

    Model.Viewport = class
    {
        constructor(count, size, offset)
        {
            this.Count = count;
            this.Size = size;
            this.Offset = offset;
        }
    }

    Model.GridRenderer = class
    {
        constructor(width, height, id, horizontalViewport, verticalViewport)
        {
            this.Width = width;
            this.Height = height;
            this.Id = id;
            this.HorizontalViewport = horizontalViewport;
            this.VerticalViewport = verticalViewport;
        }
    }

    Model.Size = class
    {
        constructor(width, height)
        {
            this.Width = width;
            this.Height = height;
        }
    }
}