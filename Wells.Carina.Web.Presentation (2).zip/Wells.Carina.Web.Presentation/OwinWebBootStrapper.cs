﻿using System.Web.Http;
using Microsoft.AspNet.SignalR;
using Newtonsoft.Json;
using Owin;

using Wells.Carina.Web.API.Hubs;

namespace Wells.Carina.Web.Presentation
{
    public class OwinWebBootStrapper
    {
        // This code configures Web API. The Startup class is specified as a type
        // parameter in the WebApp.Start method.
        public void Configuration(IAppBuilder appBuilder)
        {
            HttpConfiguration config = new HttpConfiguration();

            config.MapHttpAttributeRoutes();
            config.Formatters.JsonFormatter.SerializerSettings = new JsonSerializerSettings {TypeNameHandling = TypeNameHandling.All};
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
            var test = typeof(WebLightGridHub).AssemblyQualifiedName;

            appBuilder.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);
            appBuilder.UseWebApi(config);
            appBuilder.MapSignalR("", new HubConfiguration()
            {
                EnableJavaScriptProxies = true
            });

        }
    }
}
