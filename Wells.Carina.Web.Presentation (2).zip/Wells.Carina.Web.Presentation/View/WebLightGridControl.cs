﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using CefSharp;
using CefSharp.Wpf;
using Wells.Derivatives.Carina.Core.Command;

namespace Wells.Carina.Web.Presentation.View
{
    public class WebLightGridControl : Control
    {
        private const string SCRIPTFILE = "";
        private ChromiumWebBrowser webBrowser;
        private bool isShowDeveloperTools;

        static WebLightGridControl()
        {
            DataContextProperty.OverrideMetadata(typeof(WebLightGridControl),
                new FrameworkPropertyMetadata(
                    (d, a) => ((WebLightGridControl) d).OnDataContextChanged(a.OldValue, a.NewValue), (d, v) => v));
            if (Cef.IsInitialized) return;

            // Fix for occasional failure to find cef dependencies.
            var cefSettings = new CefSettings
            {
                BrowserSubprocessPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                    "CefSharp.BrowserSubprocess.exe")
            };
            //Cef.Initialize(cefSettings, false, true);
        }

        public CarinaCommand ShowDevToolsCommand { get; set; }

        private void WebLightGridControl_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.O)
            {
                webBrowser.ShowDevTools();
            }
            else
            {
                webBrowser.CloseDevTools();
            }
        }

        private void OnDataContextChanged(object oldValue, object newValue)
        {
            SetupContextMenu();
        }

        public WebLightGridControl()
        {
            ApplyTemplate();
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            KeyDown += WebLightGridControl_KeyDown;

            webBrowser = (ChromiumWebBrowser) Template.FindName("ChromiumWebBrowser", this);
            webBrowser.LoadingStateChanged += WebBrowserLoadingStateChanged;
            webBrowser.FrameLoadEnd += WebBrowserFrameLoadEnd;
            webBrowser.Address = string.Format("file:///{0}\\..\\..\\WebLightGrid\\{1}",
                Directory.GetCurrentDirectory(), SCRIPTFILE);
        }


        public static readonly DependencyProperty ScriptFileProperty =
            DependencyProperty.Register("ScriptFile", typeof(string), typeof(WebLightGridControl),
                new PropertyMetadata(SCRIPTFILE, OnScriptFileChanged));

        public string ScriptFile
        {
            get { return (string) GetValue(ScriptFileProperty); }
            set { SetValue(ScriptFileProperty, value); }
        }

        private static void OnScriptFileChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (e.NewValue == null) return;
            var vc = (WebLightGridControl) d;
            if (vc.webBrowser == null) return;
            vc.webBrowser.Address = string.Format("file:///{0}\\..\\..\\WebLightGrid\\{1}",
                Directory.GetCurrentDirectory(), e.NewValue);
            //log.Info("[CarinaChart] Url changed to " + vc.webBrowser.Address);
        }

        private bool browserLoaded;

        private void WebBrowserFrameLoadEnd(object sender, FrameLoadEndEventArgs e)
        {
            if (!e.Frame.IsMain) return;

            browserLoaded = true;
        }

        private void WebBrowserLoadingStateChanged(object sender, LoadingStateChangedEventArgs e)
        {
            if (e.IsLoading) return;

            DispatcherInvoke(Initialize);
        }

        private void DispatcherInvoke(Action action)
        {
            if (Dispatcher.CheckAccess())
            {
                action.Invoke();
                return;
            }

            Dispatcher.BeginInvoke(action);
        }

        private bool IsBrowserLoaded()
        {
            if (webBrowser.IsBrowserInitialized == false || webBrowser.IsLoaded == false ||
                browserLoaded == false) return false;

            return true;
        }

        private void Initialize()
        {
            if (DataContext == null || !IsBrowserLoaded()) return;

            webBrowser.LoadingStateChanged -= WebBrowserLoadingStateChanged;
            webBrowser.FrameLoadEnd -= WebBrowserFrameLoadEnd;
        }

        private void SetupContextMenu()
        {
            MenuItem item = new MenuItem();
            item.Header = "DevTools";
            item.Click += Item_Click;
            if (ContextMenu != null) ContextMenu.Items.Add(item);
        }

        private void Item_Click(object sender, RoutedEventArgs e)
        {
            if (!isShowDeveloperTools)
                webBrowser.ShowDevTools();
            else
            {
                webBrowser.CloseDevTools();
            }

            isShowDeveloperTools = !isShowDeveloperTools;
        }
    }
}

