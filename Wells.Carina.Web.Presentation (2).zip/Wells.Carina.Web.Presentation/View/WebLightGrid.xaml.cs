﻿using System.Windows;
using System.Windows.Controls;

namespace Wells.Carina.Web.Presentation.View
{
    public partial class WebLightGrid : UserControl
    {
        public WebLightGrid()
        {
            InitializeComponent();
            DataContextChanged += WebLightGrid_DataContextChanged;
        }

        private void WebLightGrid_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
           
        }
    }
}
