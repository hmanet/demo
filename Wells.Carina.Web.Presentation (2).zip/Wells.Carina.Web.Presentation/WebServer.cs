﻿using Microsoft.Owin.Hosting;

namespace Wells.Carina.Web.Presentation
{
    public static class WebServer
    {
        public static bool IsLoaded { get; private set; }

        public static string UrlAddress { get; set; }

        public static void Start()
        {
            if (!IsLoaded)
            {
                WebApp.Start<OwinWebBootStrapper>(UrlAddress);
                IsLoaded = true;
            }
        }

        public static void Stop()
        {
            // Need to find an API to unload the server listening for the address.
        }
    }
}