﻿using System.Linq;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Responses;
using Wells.Carina.Web.Presentation.ViewModel;
using Wells.Derivatives.Carina.Core.DataLeaf;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using MappingHelper = Wells.Carina.Web.Presentation.Utilities.MappingHelper;

namespace Wells.Carina.Web.Presentation
{
    public interface IWebLightGridSnapshotBuilder
    {
        IWebLightGridSnapshotBuilder CreateHorizontalViewPort();

        IWebLightGridSnapshotBuilder CreateVerticalViewPort();

        IWebLightGridSnapshotBuilder CreateColumnSpecs();

        IWebLightGridSnapshotBuilder CreateCells();

        SnapshotResponse Build();
    }

    /// <summary>
    /// Creates the Snapshot response from the source GridViewModel
    /// </summary>
    public class WebLightGridSnapshotBuilder : IWebLightGridSnapshotBuilder
    {
        public WebLightGridSnapshotBuilder(WebLightGridViewModel gridViewModel)
        {
            webLightGridViewModel = gridViewModel;
            grid = webLightGridViewModel.Grid;
        }

        private readonly WebLightGridViewModel webLightGridViewModel;
        private readonly GridViewModel grid;
        private ViewPort verticalViewPort;

        private ViewPort horizonatlViewPort;

        private LightGridColumn[] groups;

        private LightGridColumn[] columns;

        private LightGridCell[] cells;
       
        public IWebLightGridSnapshotBuilder CreateHorizontalViewPort()
        {
            horizonatlViewPort = new ViewPort
            {
                Size = grid.ViewportSize,
                Count = (int) (grid.ViewportSize + grid.MaximumViewportOffset),
                Offset = grid.ViewportOffset
            };

            return this;
        }

        public IWebLightGridSnapshotBuilder CreateVerticalViewPort()
        {
            verticalViewPort = new ViewPort
            {
                Size = (int)grid.Tree.Model.Viewport.Size,
                Offset = (int)grid.Tree.Model.Viewport.Offset,
                Count = (int)grid.Tree.Model.Viewport.Count
            };

            return this;
        }

        public IWebLightGridSnapshotBuilder CreateColumnSpecs()
        {
            var colIndex = 0;
            columns = new LightGridColumn[grid.LockedColumns.Length + grid.Columns.Length];

            foreach (var column in grid.LockedColumns)
            {
                var mappedColumn = MappingHelper.MapColumn(column);
                mappedColumn.Locked = true;
                if (column == grid.Spec.GroupColumn || (grid.Spec.GroupingMode == GridSpec.GroupingModes.Full && grid.Spec.Groups.Count > colIndex && grid.Spec.Groups[colIndex] == column))
                    mappedColumn.Grouped = true;

                mappedColumn.Index = colIndex;
                columns[colIndex++] = mappedColumn;
            }

            foreach (var column in grid.Columns)
            {
                var mappedColumn = MappingHelper.MapColumn(column);
                mappedColumn.Index = colIndex;
                columns[colIndex++] = mappedColumn;
            }

            groups = new LightGridColumn[grid.GroupColumnViewModel.Groups.Length];
            var isCompactMode = grid.Spec.GroupingMode == GridSpec.GroupingModes.Compact;
            var groupColWidth = isCompactMode ? grid.Spec.GroupColumn.Width / groups.Length : 0;
            for (var i = 0; i < groups.Length; i++)
            {
                var mappedColumn = MappingHelper.MapColumn(grid.GroupColumnViewModel.Groups[i]);
                mappedColumn.Index = i;
                mappedColumn.Left = i == 0 ? 0 : groups[i - 1].Left + groups[i - 1].Width;
                if (isCompactMode) mappedColumn.Width = groupColWidth;
                groups[i] = mappedColumn;
            }
            
            return this;
        }

        public IWebLightGridSnapshotBuilder CreateCells()
        {
            cells = new LightGridCell[grid.Tree.Nodes.Count * columns.Length];

            if (cells.Length != 0)
            {
                var rowIndex = 0;
                var cellIndex = 0;
                foreach (var row in grid.Tree.Nodes)
                {
                    var colIndex = 0;
                    foreach (var column in grid.LockedColumns)
                        cells[cellIndex++] = GetLightGridCell(row, rowIndex, column, colIndex++);

                    foreach (var column in grid.Columns)
                        cells[cellIndex++] = GetLightGridCell(row, rowIndex, column, colIndex++);

                    rowIndex++;
                }
            }

            return this;
        }
        private LightGridCell GetLightGridCell(TreeNodeViewModel row, int rowIndex, ColumnSpec column, int columnIndex)
        {
            var groupColumn = column == grid.Spec.GroupColumn;
            var cell = new LightGridCell
            {
                NodeId = row.Model.Id,
                ColumnIndex = columnIndex,
                RowIndex = rowIndex,
                Left = column.Left,
                Top = row.Top,
                BottomTotal = row.BottomTotal,
                Expanded = row.Expanded ? (bool?) true:null,
                GrandTotal = row.GrandTotal,
                Leaf = row.Leaf,
                Level = row.Level,
                TopTotal = row.TopTotal,
                FormatInfo = new FormatInfo()
            };

            // TODO: Should be removed once we move the logic from LightGridCell to ViewModel
            ColumnSpec formatSpec = column;
            object data = null;
            object formattedText = null;
            var pivotSpec = row.PivotAttribute == null ? null : grid.Spec.Columns.FirstOrDefault(next => next.Metadata == row.PivotAttribute);
            if (groupColumn)
            {
                data = row.GrandTotal ? "" : row.PivotValue;
                if (pivotSpec != null) formatSpec = pivotSpec;
            }
            else if (grid.Spec.GroupingModeColumns.Grouped(column))
            {
                if (row.SplitFiltered && row.Model is TreeBuilderModel.SplitTreeNodeModel)
                    data = row.Data[column.Key];
                else
                    data = grid.PivotValue(row, column);
            }
            else
            {
                data = row.Data[column.Key];
            }

            //calculate text
            if ((groupColumn || formatSpec.Grouped) && row.UsePivotLabelOnly)
            {
                formattedText = row.PivotLabel;
            }
            else //if (newIcon == null)
            {
                formattedText = groupColumn || (formatSpec.Grouped && row.Model.Level == formatSpec.GroupedIndex)
                    ? formatSpec.CalculateFormattedText(data, formatSpec.FormatInfo) + row.PivotLabel
                    : formatSpec.CalculateFormattedText(data, formatSpec.FormatInfo);
            }

            cell.Data = formattedText;

            var triggerStyle = grid.Triggers.Evaluate(grid.Tree.Model, row.Model, row.Model, column.Key, column);
            if (!Equals(triggerStyle, TriggerStyle.Empty))
            {
                cell.FormatInfo = MappingHelper.MapTrigger(triggerStyle);
            }

            cell.FormatInfo.Background = GridHelper.CalculateCellBackground(grid, ExtendedData.Empty, row, column, column.Background).ToString();
            return cell;
        }

        public SnapshotResponse Build()
        {
            return new SnapshotResponse
            {
                VerticalViewport = verticalViewPort,
                HorizontalViewport = horizonatlViewPort,
                Groups = groups,
                Columns = columns,
                Cells = cells,
                GridId = webLightGridViewModel.GridId,
                LockedViewportSize = grid.LockedViewportSize,
                RowCount = grid.Tree.Nodes.Count
            };
        }
    }
}
