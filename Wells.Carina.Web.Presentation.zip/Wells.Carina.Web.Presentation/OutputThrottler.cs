﻿using System;
using System.Threading;

namespace Wells.Carina.Web.Presentation
{
    public class DelayThrottler<T>
        where T : class
    {
        public DelayThrottler(int delay, Action<T> publishAction)
        {
            // Create and start a separate
            observerThread = new Thread(Publish) {IsBackground = true};
            observerThread.Start();

            throttleDelay = delay;
            this.executeAction = publishAction;
        }

        private readonly object syncRoot = new object();

        private readonly Thread observerThread;

        private readonly Action<T> executeAction;

        private T item;

        private readonly int throttleDelay;

        private bool stop;

        private void Clear()
        {
            item = null;
        }

        private void Delay()
        {
            Thread.Sleep(throttleDelay);
        }

        private void Publish()
        {
            while (true)
            {
                if (stop)
                    break;

                Delay();

                if (item == default(T)) continue;

                lock (syncRoot)
                {
                    executeAction(item);
                    Clear();
                }
            }
        }

        public void Consume(T item)
        {
            lock (syncRoot)
            {
                this.item = item;
            }
        }

        public void Shutdown()
        {
            stop = true;
            observerThread.Join();
        }

    }
}