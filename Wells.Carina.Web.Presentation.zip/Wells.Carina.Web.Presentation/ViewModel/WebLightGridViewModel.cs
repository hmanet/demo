﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using Common.Logging;
using Wells.Carina.Web.API.Hubs;
using Wells.Carina.Web.API.Interfaces;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Requests;
using Wells.Carina.Web.API.Models.Responses;
using Wells.Carina.Web.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Events;
using Wells.Derivatives.Carina.Core.Observable;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Utilities;
using MappingHelper = Wells.Carina.Web.Presentation.Utilities.MappingHelper;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Presentation.LightGrid;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.OptionSelector;
using LightGridColumn = Wells.Carina.Web.API.Models.LightGridColumn;

namespace Wells.Carina.Web.Presentation.ViewModel
{
    public class WebLightGridViewModel : ViewModelBase, IWebLightGridSource
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(WebLightGridViewModel));
        private string gridId;
        private string webPage;
        private string serverAddress;
        private readonly GridViewModel grid;
        private IClient client;
        
        private readonly Dictionary<int, WebGridRequest> requestsThrottler = new Dictionary<int, WebGridRequest>();
        private readonly WebGridRequestProcessor requestProcessor;
        private SnapshotResponse snapshot;

        public WebLightGridViewModel(string gridId,string homePage,string serverAddress,GridViewModel source, IEventBus eventBus)
        {
            
            GridId = gridId;
            ServerAddress = serverAddress;
            WebPage = homePage;
            grid = source;
            requestProcessor = new WebGridRequestProcessor(this);
        }

        public string GridId
        {
            get
            {
                return gridId;
            }
            private set
            {
                if (gridId == value) return;
                gridId = value;
                RaisePropertyChanged();
            }
        }

        public GridViewModel Grid { get { return grid; } }

        public IClient Client { get { return client; } }

        public string WebPage
        {
            get { return webPage; }
            set
            {
                if (webPage == value) return;
                webPage = value;
                RaisePropertyChanged();
            }
        }

        public string ServerAddress
        {
            get { return serverAddress; }
            set
            {
                if (serverAddress == value) return;
                serverAddress = value;
                RaisePropertyChanged();
            }
        }


        private bool isShowDevTools;
        public bool ShowDevTools
        {
            get { return isShowDevTools; }
            set
            {
                if (isShowDevTools != value)
                {
                    isShowDevTools = value;
                    RaisePropertyChanged();
                }
            }
        }

        private void Tree_EndChanges()
        {
            PushSnapshot();
        }

        private void Grid_PropertyChanged(object sender, PropertyChangedEventArgs propertyChangedEventArgs)
        {
            PushSnapshot();
        }

        private void Spec_Columns_ItemPropertyChanged(object sender, PropertyChangedEventArgs propertyChangedEventArgs)
        {
            PushSnapshot(true);
        }

        private TreeModel lastPushedSnapshot;
        private void PushSnapshot(bool isColumnsChanged = false)
        {
            try
            {
                if (Client == null || string.IsNullOrEmpty(GridId))
                    return;

                grid.Dispatcher.BeginInvoke(() =>
                {
                    
                        if (lastPushedSnapshot == Grid.Tree.Model && isColumnsChanged == false)
                        {
                            return;
                        }

                        lastPushedSnapshot = Grid.Tree.Model;

                    
                    snapshot = new WebLightGridSnapshotBuilder(this)
                        .CreateVerticalViewPort()
                        .CreateHorizontalViewPort()
                        .CreateColumnSpecs()
                        .CreateCells()
                        .Build();

                    Client.ReceiveSnapshot(snapshot);

                }, DispatcherPriority.Background);


            }
            catch (Exception ex)
            {
                // Log the exception..
                logger.Error(ex.Message);
            }
        }

        private void PopulateGridSettings(GridSpecResponse gridSpec)
        {
            ColorTranslator colorTranslator = new ColorTranslator();

            gridSpec.GridSettings = new GridSettings();
            gridSpec.GridSettings.ColumnSelectionBackGround = colorTranslator.GetRgbaColorInHex(Grid.SelectionBackground);
            gridSpec.GridSettings.ColumnSelectionForeground = colorTranslator.GetRgbaColorInHex(Grid.SelectionForeground);
            
            var selectedColumnGradientBackGround =
                GridHelper.CalculateColumnBackgroundHeader(LightGridResources.Instance.HeaderBrush,
                    LightGridResources.Instance.LockedHeaderColor, Grid.SelectionBackground, true, false, false);
            var lockedColumnGradientBackGround =
                GridHelper.CalculateColumnBackgroundHeader(LightGridResources.Instance.HeaderBrush,
                    LightGridResources.Instance.LockedHeaderColor, Grid.SelectionBackground, false, true, false);
            var groupedColumnGradientBackGround =
                GridHelper.CalculateColumnBackgroundHeader(LightGridResources.Instance.HeaderBrush,
                    LightGridResources.Instance.LockedHeaderColor, Grid.SelectionBackground, false, false, true);

            if ((LightGridResources.Instance.HeaderBrush is System.Windows.Media.LinearGradientBrush))
            {
                System.Windows.Media.LinearGradientBrush headerBrush = LightGridResources.Instance.HeaderBrush as System.Windows.Media.LinearGradientBrush;
                // TODO: need to do it in a better way.
                if (headerBrush.GradientStops.Count > 1)
                {
                    var gradientStopFirst = headerBrush.GradientStops[0];
                    var gradientStopSecond = headerBrush.GradientStops[0];

                    var linearGradient = colorTranslator.GetWebSupportedLinearGradient(gradientStopFirst.Color,
                        gradientStopSecond.Color, gradientStopFirst.Offset, gradientStopSecond.Offset);

                    gridSpec.GridSettings.ColumnBackground = linearGradient;
                }
            }

            gridSpec.GridSettings.SelectedColumnBackground =
                colorTranslator.GetWebSupportedLinearGradient(selectedColumnGradientBackGround.Item1,
                    selectedColumnGradientBackGround.Item2);

            gridSpec.GridSettings.LockedColumnBackground = colorTranslator.GetWebSupportedLinearGradient(lockedColumnGradientBackGround.Item1,
                    lockedColumnGradientBackGround.Item2);

            gridSpec.GridSettings.GroupedColumnBackground = colorTranslator.GetWebSupportedLinearGradient(groupedColumnGradientBackGround.Item1,
                    groupedColumnGradientBackGround.Item2);

            gridSpec.GridSettings.AlternatingRowBackground = colorTranslator.GetRgbaColorInHex(Grid.AlternatingRowBackground);
            gridSpec.GridSettings.AlternatingRowForeground = colorTranslator.GetRgbaColorInHex(Grid.AlternatingRowForeground);
            gridSpec.GridSettings.RowBackground = colorTranslator.GetRgbaColorInHex(Grid.RowBackground);
            gridSpec.GridSettings.RowForeground = colorTranslator.GetRgbaColorInHex(Grid.RowForeground);
            gridSpec.GridSettings.HeaderFontFamily = Grid.HeaderFontFamily.ToString();
            gridSpec.GridSettings.HeaderFontSize = Grid.HeaderFontSize;
            gridSpec.GridSettings.HeaderFontStyle = Grid.HeaderFontStyle.ToString();
            gridSpec.GridSettings.CellZIndex = GridViewModel.CellZIndex;
            gridSpec.GridSettings.ActiveCellZIndex = GridViewModel.ActiveCellZIndex;
            gridSpec.GridSettings.SeparatorZIndex = GridViewModel.SeparatorZIndex;
            gridSpec.GridSettings.EditorZIndex = GridViewModel.EditorZIndex;
            gridSpec.GridSettings.LockedCellZIndex = GridViewModel.LockedCellZIndex;
            gridSpec.GridSettings.LockedActiveCellZIndex = GridViewModel.LockedActiveCellZIndex;
            gridSpec.GridSettings.LockedSeparatorZIndex = GridViewModel.LockedSeparatorZIndex;
            gridSpec.GridSettings.LockedEditorZIndex = GridViewModel.LockedEditorZIndex;
            gridSpec.GridSettings.TitleRowZIndex = GridViewModel.TitleRowZIndex;
            gridSpec.GridSettings.ScrollbarZIndex = GridViewModel.ScrollbarZIndex;
        }

        private int timeFiredSnapshot;
        public void Initialize()
        {
            WebLightGridSources.AddSource(GridId, this);
            
            var typeColumn = Grid.Spec.Columns.FirstOrDefault(x => x.Name == "Type");
            if (typeColumn != null) typeColumn.Grouped = true;

            var orbits = Grid.Spec.Columns.FirstOrDefault(x => x.Name == "Orbits");
            if (orbits != null) orbits.Grouped = true;

            var name = Grid.Spec.Columns.FirstOrDefault(x => x.Name == "Name");
            if (name != null) name.Locked = true;

            Grid.Spec.GroupingMode = GridSpec.GroupingModes.Compact;
            Grid.Editable = true;
            Grid.EnableGrouping = true;
            Grid.EnableSplitScreen = true;
            Grid.Spec.EnableGrandTotal = false;

            Grid.Tree.EndChanges += Tree_EndChanges;
            Grid.PropertyChanged += Grid_PropertyChanged;
            Grid.Spec.Columns.ItemPropertyChanged += Spec_Columns_ItemPropertyChanged;
           
        }

        public void AttachClient(IClient hubClient)
        {
            client = hubClient;
        }

        public void GetComponentSpec()
        {
            try
            {
                GridComponentSpecResponse gridComponentSpec = new GridComponentSpecResponse()
                {
                    RunTimeId = GridId,
                    Type = Grid.Spec.Name,
                    GridId = GridId
                };

                Client.ReceiveGridComponentSpec(gridComponentSpec);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
            }
            
        }

        public void GetGridSpec()
        {
            try
            {
                snapshot = null;
                GridSpecResponse gridSpec = new GridSpecResponse()
                {
                    GridId = GridId,
                    HeadersHeight = (int)Grid.HeadersHeight,
                    RowHeight = (int)Grid.RowHeight,
                };

                PopulateGridSettings(gridSpec);

                gridSpec.Columns = new LightGridColumn[grid.LockedColumns.Length + grid.Columns.Length];

                var colIndex = 0;
                // Recheck this logic.
                foreach (var column in grid.LockedColumns)
                {
                    gridSpec.Columns[colIndex++] = MappingHelper.MapColumn(column);
                }

                foreach (var column in grid.Columns)
                {
                    gridSpec.Columns[colIndex++] = MappingHelper.MapColumn(column);
                }

                Client.ReceiveGridSpec(gridSpec);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
            }
        }

        public void ProcessSnapshotRequests(WebGridRequest request)
        {
            if (snapshot == null)
            {
                var snapShotBuilder = new WebLightGridSnapshotBuilder(this);
                snapshot = snapShotBuilder.CreateVerticalViewPort()
                    .CreateHorizontalViewPort()
                    .CreateColumnSpecs()
                    .CreateCells()
                    .Build();

                Client.ReceiveSnapshot(snapshot);
                requestProcessor.Process(request);
            }
            else
            {
                grid.Dispatcher.BeginInvoke(() =>
                {
                    WebGridRequest lastRequest;
                    requestsThrottler.TryGetValue(request.RequestId, out lastRequest);
                    if (lastRequest != null && lastRequest.RequestId > request.RequestId) return;
                    requestsThrottler[request.RequestId] = request;
                    
                    requestProcessor.Process(request);
                },DispatcherPriority.Background);
            }

        }

        public void GenerateSnapShot()
        {    
            PushSnapshot();
        }

        public void PushContextMenu(UserActionRequest request)
        {
            grid.Menu.Level = request.Level.Value;
            grid.Menu.IsOpen = true;
            var contextMenu = new ContextMenuResponse { GridId = GridId, Items = GetMenuItems(grid.Menu.Items), PageX = request.PageX.Value, PageY = request.PageY.Value };
            Client.ReceiveContextMenu(contextMenu);
            grid.Menu.IsOpen = false;
        }
        private static MenuItem[] GetMenuItems(IEnumerable<MenuAction> menuActions)
        {
            var visibleMenuActions = menuActions.Where(x => x.Visibility == Visibility.Visible).ToArray();
            var items = new MenuItem[visibleMenuActions.Length];
            for (var i = 0; i < items.Length; i++)
            {
                items[i] = new MenuItem
                {
                    Id = visibleMenuActions[i].Id,
                    Header = visibleMenuActions[i].DisplayName,
                    IsSeparator = visibleMenuActions[i] is SeparatorMenuAction ? (bool?)true : null,
                    Icon = visibleMenuActions[i].IconName,
                    Items = GetMenuItems(visibleMenuActions[i].Items)
                };
            }

            return items;
        }

        protected override void OnDisposed(bool disposing)
        {
            WebLightGridSources.RemoveSource(gridId);
            gridId = null;
            Grid.Tree.EndChanges -= Tree_EndChanges;
            Grid.PropertyChanged -= Grid_PropertyChanged;
            Grid.Spec.Columns.ItemPropertyChanged -= Spec_Columns_ItemPropertyChanged;

            base.OnDisposed(disposing);
        }
    }
}
