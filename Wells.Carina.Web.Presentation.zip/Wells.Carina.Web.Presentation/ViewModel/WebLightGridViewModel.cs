﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using Common.Logging;
using Wells.Carina.Web.API.Hubs;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Requests;
using Wells.Carina.Web.API.Models.Responses;
using Wells.Carina.Web.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Events;
using Wells.Derivatives.Carina.Core.Observable;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Threading;

namespace Wells.Carina.Web.Presentation.ViewModel
{
    public class WebLightGridViewModel : ViewModelBase, IWebLightGridSource
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(WebLightGridViewModel));
        private string gridId;
        private string webPage;
        private readonly GridViewModel grid;
        private IClient client;
        private readonly BackgroundQueue<Action> requestQueue;
        private readonly BackgroundQueue<Action> responseQueue;
        private readonly Dictionary<int, WebGridRequest> requestsThrottler = new Dictionary<int, WebGridRequest>();
        private readonly WebGridRequestProcessor requestProcessor;
        private SnapshotResponse snapshot;
        private bool enqueued;

        public WebLightGridViewModel(string gridId,GridViewModel source, IEventBus eventBus)
        {
            requestQueue = BackgroundQueue<Action>.Single(x => x(), eventBus);
            responseQueue = BackgroundQueue<Action>.Single(x => x(), eventBus);

            this.gridId = gridId;
            grid = source;
            requestProcessor = new WebGridRequestProcessor(Grid);
        }

        public string GridId { get { return gridId; } }

        public GridViewModel Grid { get { return grid; } }

        public IClient Client { get { return client; } }

        public string WebPage
        {
            get { return webPage; }
            set
            {
                if (webPage != value)
                {
                    webPage = value;
                    RaisePropertyChanged();
                }
            }
        }

        private void Tree_EndChanges()
        {
            GetSnapshot();
        }

        private void Grid_PropertyChanged(object sender, PropertyChangedEventArgs propertyChangedEventArgs)
        {
            GetSnapshot();
        }

        private void GetSnapshot()
        {
            try
            {
                if (Client == null)
                    return;

                if (!string.IsNullOrEmpty(GridId))
                {
                    snapshot = new WebLightGridSnapshotBuilder(this).CreateVerticalViewPort()
                        .CreateHorizontalViewPort()
                        .CreateColumnSpecs()
                        .CreateCells()
                        .Build();
                }

                if (enqueued) return;
                enqueued = true;

                responseQueue.Enqueue(() =>
                {
                    enqueued = false;
                    Client.ReceiveSnapshot(snapshot);
                });
            }
            catch (Exception ex)
            {
                // Log the exception..
                logger.Error(ex.Message);
            }
        }

        public void Initialize()
        {
            WebLightGridSources.AddSource(GridId, this);
            Grid.Tree.EndChanges += Tree_EndChanges;
            Grid.PropertyChanged += Grid_PropertyChanged;
        }

        public void AttachClient(IClient hubClient)
        {
            client = hubClient;
        }

        public void GetComponentSpec()
        {
            try
            {
                GridComponentSpecResponse gridComponentSpec = new GridComponentSpecResponse()
                {
                    RunTimeId = GridId,
                    Type = Grid.Spec.Name,
                    GridId = GridId
                };

                Client.ReceiveGridComponentSpec(gridComponentSpec);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
            }
            
        }

        public void GetGridSpec()
        {
            try
            {
                snapshot = null;
                GridSpecResponse gridSpec = new GridSpecResponse()
                {
                    GridId = GridId,
                    HeadersHeight = (int)Grid.HeadersHeight,
                    RowHeight = (int)Grid.RowHeight,
                };

                gridSpec.Columns = new List<LightGridColumn>();
                // Recheck this logic.
                var visibleColumns = Grid.Spec.Columns;
                foreach (var column in visibleColumns)
                {
                    gridSpec.Columns.Add(MappingHelper.Map(column));
                }

                Client.ReceiveGridSpec(gridSpec);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
            }
        }

        public void ProcessSnapshotRequests(WebGridRequest request)
        {
            if (snapshot == null)
            {
                var snapShotBuilder = new WebLightGridSnapshotBuilder(this);
                snapshot = snapShotBuilder.CreateVerticalViewPort()
                    .CreateHorizontalViewPort()
                    .CreateColumnSpecs()
                    .CreateCells()
                    .Build();

                Client.ReceiveSnapshot(snapshot);
                requestProcessor.Process(request);
            }
            else
            {
                requestQueue.Enqueue(() =>
                {
                    WebGridRequest lastRequest;
                    requestsThrottler.TryGetValue(request.RequestId, out lastRequest);
                    if (lastRequest != null && lastRequest.RequestId > request.RequestId) return;
                    requestsThrottler[request.RequestId] = request;

                    requestProcessor.Process(request);
                });
            }
        }

        protected override void OnDisposed(bool disposing)
        {
            WebLightGridSources.RemoveSource(gridId);
            gridId = null;
            Grid.Tree.EndChanges -= Tree_EndChanges;
            Grid.PropertyChanged -= Grid_PropertyChanged;

            base.OnDisposed(disposing);
        }
    }
}
