﻿using System;
using Common.Logging;
using Wells.Derivatives.Carina.Core.Events;
using Wells.Derivatives.Carina.Core.Interfaces;
using Wells.Derivatives.Carina.Core.Presentation.Common;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Carina.Web.Presentation.ViewModel
{
    public class WebLightGridComponentViewModel : CarinaViewModelBase
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(WebLightGridComponentViewModel));

        private readonly IEventBus eventBus;

        public WebLightGridComponentViewModel(IComponentContext componentContext, IEventBus eventBus): base(componentContext)
        {
            this.eventBus = eventBus;
            this.eventBus.Exception += OnException;
        }

        private string hostingAddress = "http://localhost:9000/";

        private string homePage = "Component.html";

        public override string ComponentTitle { get { return "WebLightGrid"; } }

        public WebLightGridViewModel WebLightGridViewModel { get { return webLightGridViewModel.Value; } set { webLightGridViewModel.SetValue(this, value); } }
        private Property<WebLightGridViewModel> webLightGridViewModel = new Property<WebLightGridViewModel>();

        private void StartWebServer()
        {
            WebServer.UrlAddress = hostingAddress;
            WebServer.Start();
        }

        public void Initialize(string gridType, string gridTitle, string gridName, GridViewModel source)
        {
            WebLightGridViewModel = new WebLightGridViewModel("12345",source, eventBus);
            WebLightGridViewModel.Initialize();
            StartWebServer();
            WebLightGridViewModel.WebPage = homePage;
        }

        protected override void ComponentDispose(bool disposing)
        {
            WebLightGridViewModel.Dispose();
            base.ComponentDispose(disposing);
        }

        private void OnException(EventBusArgs<Exception> args)
        {
            args.Handle(this);
            log.Error("[WebLightGridComponentViewModel] Error :" + args.Value);
        }
    }
}
