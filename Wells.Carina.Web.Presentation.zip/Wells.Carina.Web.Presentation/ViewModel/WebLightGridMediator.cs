﻿using Wells.Derivatives.Carina.Core.Host;
using Wells.Derivatives.Carina.Core.Presentation.Grid;

namespace Wells.Carina.Web.Presentation.ViewModel
{
    public class WebLightGridMediator : IParentChildMediator<GridComponentViewModel, WebLightGridComponentViewModel>
    {
        private WebLightGridComponentViewModel webLightGrid;

        public void Mediate(GridComponentViewModel parent, WebLightGridComponentViewModel child)
        {
            webLightGrid = child;
            child.Initialize(parent.GridType, parent.ComponentTitle, parent.ComponentName, parent.Grid);
        }

        public void Dispose()
        {
            webLightGrid.Dispose();
        }
    }
}
