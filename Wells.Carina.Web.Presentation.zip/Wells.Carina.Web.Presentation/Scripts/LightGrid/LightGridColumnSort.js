﻿"use strict";
{
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;

    Carina.LightGrid.LightGridColumnSort = class extends Core.BaseControl
    {
        constructor(header)
        {
            super();

            this.Element = document.createElement("div");
            this.Parent = header;
            this.AddClass("lightGrid-sort");
            this.sortDirection = null;
            this.sortIndex = null;
            this.sortLocked = null;

            this.iconElement = new Core.GenericControl("i");
            this.iconElement.AddClass("lightGrid-sortIcon");
            this.iconElement.AddClass("fa");
            this.lastSortCssClass = null;
            this.AppendChild(this.iconElement);

            this.indexElement = new Core.DivControl();
            this.indexElement.AddClass("lightGrid-sortIndex");
            this.AppendChild(this.indexElement);
        }

        Render(columnSpec)
        {
            if (this.sortDirection === columnSpec.SortDirection && this.sortIndex === columnSpec.SortIndex && this.sortLocked === columnSpec.SortLocked)
            {
                return;
            }

            this.sortDirection = columnSpec.SortDirection;
            this.sortIndex = columnSpec.SortIndex;
            this.sortLocked = columnSpec.SortLocked;

            this.iconElement.RemoveClass(this.lastSortCssClass);
            if (this.sortDirection === "ASCENDING" || this.sortDirection === "ABSOLUTE_ASCENDING")
            {
                this.lastSortCssClass = "fa-caret-up";
                this.iconElement.AddClass(this.lastSortCssClass);
            }
            else if (this.sortDirection === "DESCENDING" || this.sortDirection === "ABSOLUTE_DESCENDING")
            {
                this.lastSortCssClass = "fa-caret-down";
                this.iconElement.AddClass(this.lastSortCssClass);
            }

            if (this.sortIndex)
            {
                this.indexElement.Element.innerText = this.sortIndex;
                this.AddClass("lightGrid-sorted");
            }
            else
            {
                this.indexElement.Element.innerText = "";
                this.RemoveClass("lightGrid-sorted");
            }

            this.Style("color", this.sortLocked ? "#930000" : "#000000");
        }
    }
}
