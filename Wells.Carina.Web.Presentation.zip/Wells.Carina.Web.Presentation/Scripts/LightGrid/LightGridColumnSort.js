﻿"use strict";
{
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;

    Carina.LightGrid.LightGridColumnSort = class extends Core.BaseControl
    {
        constructor()
        {
            super();
            this.Parent;
            this.Element = document.createElement("div");
            this.Element.setAttribute("name", "LightGridHeaderSort");
            this.Element.style["z-index"] = LightGrid.LightGrid.HeaderZIndex;
            this.onClick_Event_Handler = this.onClickEvent.bind(this);
        }

        Render(LighGridColumnHeader)
        {
            this.Parent = LighGridColumnHeader;
            let path = "Images/iconDownArrowHead.png"
            let image = new Core.ImageControl("CulumnSort", path);
            this.AddClass("lightGrid-sort")
            this.AddClickEvent();
            this.AppendChild(image);
        }
        onClickEvent(eventArgs)
        {
            console.log("sort Event Fired", eventArgs);
            eventArgs.stopPropagation();
        }
    }
}
