"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;
    let Model = Carina.Model;

    Carina.LightGrid.LightGrid = class extends Core.BaseControl
    {
        constructor()
        {
            super();

            this.onScroll_Vertical_Handler = this.OnScroll_Vertical.bind(this);
            this.onScroll_Horizontal_Handler = this.OnScroll_Horizontal.bind(this);
            this.dataContext_OnSpecChanged_Handler = this.DataContext_OnSpecChanged.bind(this);
            this.dataContext_OnSnapshotChanged_Handler = this.DataContext_OnSnapshotChanged.bind(this);
            this.onResize_Handler = this.OnResize.bind(this);

            this.Element = document.createElement("div");
            this.Attribute("name", "LightGrid");

            // Bar Panel
            this.barPanel = new LightGrid.LightGridBarPanel(this);
            this.AppendChild(this.barPanel);

            // Layout Grid
            this.layoutGrid = new Core.DivControl("LayoutGrid");
            this.layoutGrid.AddClass("lightGrid-layoutGrid");
            this.AppendChild(this.layoutGrid);

            // Layout Grid children
            {
                // vertical scrollbar
                this.verticalScrollbar = new Core.ScollbarControl("v");
                this.verticalScrollbar.AddClass("lightGrid-verticalScrollBar");
                this.verticalScrollbar.Element.addEventListener("scroll", this.onScroll_Vertical_Handler);
                this.layoutGrid.AppendChild(this.verticalScrollbar);

                // header
                this.header = new LightGrid.LightGridHeader(this);
                this.layoutGrid.AppendChild(this.header);

                // menu
                this.menuPanel = new LightGrid.LightGridMenuPanel(this);
                this.layoutGrid.AppendChild(this.menuPanel);

                // filter
                this.filterPanel = new LightGrid.LightGridFiltersPanel(this);
                this.layoutGrid.AppendChild(this.filterPanel);

                // main cell panel
                this.panel = new LightGrid.LightGridPanel(this);
                this.layoutGrid.AppendChild(this.panel);

                // horizontal scrollbar
                this.horizontalScrollBar = new Core.ScollbarControl("h");
                this.horizontalScrollBar.AddClass("lightGrid-horizontalScrollBar");
                this.horizontalScrollBar.Element.addEventListener("scroll", this.onScroll_Horizontal_Handler);
                this.layoutGrid.AppendChild(this.horizontalScrollBar);
            }

            // tool bar
            this.toolBar = new LightGrid.LightGridToolBar(this);
            this.Element.appendChild(this.toolBar.Element);

            //this.onResize_Handler = Core.UiUtil.Throttle(this.OnResize).bind(this);
            window.addEventListener("resize", this.onResize_Handler);

            this.horizontalViewport = new Model.Viewport(0 ,0 ,0);
            this.verticalViewport = new Model.Viewport(0, 0, 0);

            this.scrollTop = 0;
            this.scrollLeft = 0;
        }

        get Spec() { return this.spec; }
        get Id() { return this.spec.gridRunTimeId; }
        get Header() { return this.header; }

        OnDataContextChanged(oldValue, newValue)
        {
            if (oldValue)
            {
                oldValue.SpecChanged.Remove(this.dataContext_OnSpecChanged_Handler);
                oldValue.SnapshotChanged.Remove(this.dataContext_OnSnapshotChanged_Handler);
            }

            if (newValue)
            {
                newValue.SpecChanged.Add(this.dataContext_OnSpecChanged_Handler);
                newValue.SnapshotChanged.Add(this.dataContext_OnSnapshotChanged_Handler);
            }

            this.panel.DataContext = newValue;
        }

        DataContext_OnSpecChanged(specChangeArgs)
        {
            this.spec = specChangeArgs.NewValue;

            this.header.Reset();
            this.panel.Reset();

            this.ResetViewport();

            var width = 0;
            for (let i = 0; i < this.spec.Columns.length; i++) width += this.spec.Columns[i].Width;

            this.horizontalScrollBar.SetContentLength(width);
            this.horizontalViewport.Count = width;
            this.horizontalViewport.Offset = 0;

            this.verticalScrollbar.SetContentLength(1);
            this.verticalViewport.Count = 0;
            this.verticalViewport.Offset = 0;

            this.firstSnapshot = true;

            this.DataContext.Scroll(this.GetUpdateViewportRequest());
        }

        OnResize(args)
        {
            this.ResetViewport();
            this.DataContext.Scroll(this.GetUpdateViewportRequest());
        }

        ResetViewport()
        {
            let size = Core.UiUtil.CalculateViewportResolution();
            this.Width = size.Width;
            this.Height = size.Height;

            this.panel.Width = this.Width - this.verticalScrollbar.Width;
            this.panel.Height = this.Height - this.header.Height - this.filterPanel.Height - this.toolBar.Height - this.horizontalScrollBar.Height;

            // Set horizontal scrollbar.
            this.horizontalScrollBar.SetWidth(this.panel.Width);
            this.horizontalViewport.Size = this.panel.Width;

            // Set vertical scrollbar
            this.verticalScrollbar.SetHeight(this.panel.Height);
            this.verticalViewport.Size = Math.floor(this.panel.Height / this.Spec.RowHeight);
        }

        GetUpdateViewportRequest()
        {
            return { HorizontalViewport: this.horizontalViewport, VerticalViewport: this.verticalViewport };
        }

        DataContext_OnSnapshotChanged(snapshot)
        {
            console.log(snapshot);
            if (this.firstSnapshot)
            {
                this.firstSnapshot = false;

                this.verticalViewport.Count = snapshot.VerticalViewport.Count;
                this.verticalScrollbar.SetContentLength(snapshot.VerticalViewport.Count * this.spec.RowHeight + this.spec.RowHeight);
            }

            this.header.Render(snapshot);
            this.panel.Render(snapshot);
        }

        OnScroll_Vertical(eventArgs)
        {
            if (Math.abs(eventArgs.target.scrollTop - this.scrollTop) < 40) return;

            this.scrollTop = eventArgs.target.scrollTop;
            let offset = Math.round(eventArgs.target.scrollTop / this.spec.RowHeight);
            this.verticalViewport.Offset = offset;
            this.DataContext.Scroll(this.GetUpdateViewportRequest());
        }

        OnScroll_Horizontal(eventArgs)
        {
            if (Math.abs(eventArgs.target.scrollLeft - this.scrollLeft) < 5) return;

            this.scrollLeft = eventArgs.target.scrollLeft;
            this.horizontalViewport.Offset = this.scrollLeft;
            this.DataContext.Scroll(this.GetUpdateViewportRequest());
        }
    }
}