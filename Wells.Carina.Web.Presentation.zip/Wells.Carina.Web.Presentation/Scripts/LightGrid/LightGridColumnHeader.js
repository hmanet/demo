﻿"use strict";
{
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;
    let UiUtil = Carina.Core.UiUtil;

    Carina.LightGrid.LightGridColumnHeader = class extends Core.BaseControl
    {
        constructor(lightGridHeader, partOfGoupColumn)
        {
            super();

            this.layoutLoaded = false;
            this.groups = [];

            this.Parent = lightGridHeader;
            this.gridHeader = lightGridHeader;
            this.grid = this.gridHeader.Parent;
            this.columnSpec = {};
            this.partOfGoupColumn = partOfGoupColumn ? true : false;

            this.Element = document.createElement("div");
            this.AddClass("lightGrid-columnHeader");
            this.Element.id = LightGrid.LightGridColumnHeader.CommonId;
            this.SetData(LightGrid.LightGrid.TypeKey, LightGrid.LightGrid.TypeCol);
        }

        static get CommonId() { return "_lgch"; }

        get ColumnSpec() { return this.columnSpec; }

        LoadLayout()
        {
            this.Height = this.grid.Spec.HeadersHeight;
            this.Style("background", this.grid.Spec.ColumnBackground);

            // Expand collapse
            this.expandCollapse = new Core.DivControl();
            this.expandCollapse.AddClass("lightGrid-columnHeader-expandCollapse");
            this.expandCollapse.AddClass("lightGrid-icon");
            this.expandCollapse.AddClass("lightGrid-icon-collapsed");
            this.expandCollapse.Hide();
            this.AppendChild(this.expandCollapse);

            // Scaling and Cycles
            const icons = new Core.DivControl();
            icons.AddClass("lightGrid-columnHeader-icons");
            {
                this.scalingIndicator = new Core.DivControl();
                this.scalingIndicator.Hide();
                icons.AppendChild(this.scalingIndicator);

                this.cycleIndicator = new Core.DivControl();
                this.cycleIndicator.Hide();
                icons.AppendChild(this.cycleIndicator);
            }
            this.AppendChild(icons);

            // Label
            this.label = new Core.DivControl();
            this.label.AddClass("lightGrid-columnHeader-label");
            this.AppendChild(this.label);

            // TODO: Header Image

            // Sort
            this.sort = new LightGrid.LightGridColumnSort(this);
            this.sort.AddClass("lightGrid-columnHeader-sort");
            this.AppendChild(this.sort);

            // Separtor
            const border = new Core.DivControl();
            border.AddClass("lightGrid-columnHeader-separator");
            this.AppendChild(border);

            if (this.partOfGoupColumn === false) this.AddThumb();
            
            this.onMouseDown_Handler = this.OnMouseDown.bind(this);
            this.AddEvent("mousedown", this.onMouseDown_Handler);

            this.onMouseUp_Handler = this.OnMouseUp.bind(this);
            this.AddEvent("mouseup", this.onMouseUp_Handler);
        }
        LoadCompactGroupLayout(groups)
        {
            this.Height = this.grid.Spec.HeadersHeight;
            this.groups = [];
            for (let i = 0; i < groups.length; i++)
            {
                const column = new LightGrid.LightGridColumnHeader(this.Parent, true);
                column.LoadLayout();
                this.groups.push(column);
                this.AppendChild(column);
            }

            this.AddThumb();
            this.onMouseDown_Handler = this.OnMouseDown.bind(this);
            this.AddEvent("mousedown", this.onMouseDown_Handler);
            this.onMouseUp_Handler = this.OnMouseUp.bind(this);
            this.AddEvent("mouseup", this.onMouseUp_Handler);
        }
        AddThumb()
        {
            this.thumb = new Core.GenericControl("div");
            this.thumb.Height = this.grid.Spec.HeadersHeight;
            this.thumb.AddClass("lightGrid-columnHeader-thumb");
            this.thumb.Style("z-index", LightGrid.LightGrid.ColumnThumbZIndex);
            this.AppendChild(this.thumb);
        }

        Render(snapshot, index)
        {
            const columnSpec = snapshot.Columns[index];
            if (this.layoutLoaded === false || columnSpec.IsGroupColumn !== this.columnSpec.IsGroupColumn)
            {
                Core.UiUtil.RemoveChildren(this.Element);
                this.columnSpec = {};
                if (columnSpec.IsGroupColumn) this.LoadCompactGroupLayout(snapshot.Groups);
                else this.LoadLayout();
                this.layoutLoaded = true;
            }
            else if (columnSpec.IsGroupColumn && snapshot.Groups.length !== this.groups.length)
            {
                Core.UiUtil.RemoveChildren(this.Element);
                this.columnSpec = {};
                this.LoadCompactGroupLayout(snapshot.Groups);
            }

            if (columnSpec.IsGroupColumn) this.RenderCompactGroupInternal(columnSpec, snapshot.Groups);
            else this.RenderInternal(columnSpec);
        }
        RenderInternal(columnSpec)
        {
            this.sort.Render(columnSpec);

            if (columnSpec.Width !== this.columnSpec.Width) this.Width = columnSpec.Width;
            if (columnSpec.Name !== this.columnSpec.Name) this.label.Element.innerText = columnSpec.Name;
            if (columnSpec.Left !== this.columnSpec.Left) this.Style("left", columnSpec.Left + "px");
            if (columnSpec.Left !== this.columnSpec.Left) this.Style("left", columnSpec.Left + "px");
            if (columnSpec.PaddingLeft !== this.columnSpec.PaddingLeft) this.Style("padding-left", columnSpec.PaddingLeft + "px");

            // TODO: Background color logic.
            if (columnSpec.Selected !== this.columnSpec.Selected || columnSpec.Locked !== this.columnSpec.Locked || columnSpec.Grouped !== this.columnSpec.Grouped)
            {
                this.Style("background", this.CalculateBackground(columnSpec));
            }

            if (columnSpec.FontFamily !== this.columnSpec.FontFamily) this.Style("font-family", columnSpec.FontFamily);
            if (columnSpec.FontStyle !== this.columnSpec.FontStyle) this.Style("font-style", columnSpec.FontStyle);
            if (columnSpec.FontWeight !== this.columnSpec.FontWeight) this.Style("font-weight", columnSpec.FontWeight);
            if (columnSpec.FontSize !== this.columnSpec.FontSize) this.Style("font-size", columnSpec.FontSize + "px");
            if (columnSpec.Locked !== this.columnSpec.Locked) this.Style("z-index", columnSpec.Locked === true ? LightGrid.LightGrid.LockedCellZIndex : 0);
            if (columnSpec.Grouped !== this.columnSpec.Grouped)
            {
                if (columnSpec.Grouped) this.expandCollapse.Show();
                else this.expandCollapse.Hide();
            }
            if (columnSpec.GroupedExpanded !== this.columnSpec.GroupedExpanded)
            {
                this.expandCollapse.RemoveClass(this.columnSpec.GroupedExpanded ? "lightGrid-icon-expanded" : "lightGrid-icon-collapsed");
                this.expandCollapse.AddClass(columnSpec.GroupedExpanded ? "lightGrid-icon-expanded" : "lightGrid-icon-collapsed");
            }

            this.columnSpec = columnSpec;
        }
        RenderCompactGroupInternal(columnSpec, groups)
        {
            if (columnSpec.Width !== this.columnSpec.Width) this.Width = columnSpec.Width;

            for (let i = 0; i < groups.length; i++)
            {
                this.groups[i].RenderInternal(groups[i]);
            }

            this.columnSpec = columnSpec;
        }

        CalculateBackground(columnSpec)
        {
            if (columnSpec.Selected) return this.grid.Spec.SelectedColumnBackground;
            if (columnSpec.Grouped) return this.grid.Spec.GroupedColorHeader;
            if (columnSpec.Locked) return this.grid.Spec.LockedColorHeader;
            return this.grid.Spec.ColumnBackground;
        }

        OnMouseDown(e)
        {
            if (e.button === 0) this.OnLeftMouseDown(e);
            else if (e.button === 2) this.OnRightMouseDown(e);
        }
        OnLeftMouseDown(e)
        {
            if (this.thumb && e.target === this.thumb.Element)
            {
                e.preventDefault();
                this.gridHeader.ResizingColumnSpec = this.columnSpec;
            }
            else if (!this.columnSpec.IsGroupColumn && !this.columnSpec.Selected && e.target !== this.sort.Element && e.target !== this.expandCollapse.Element)
            {
                this.grid.SelectColumn(this.columnSpec, e.ctrlKey, e.shiftKey);
            }
        }
        OnRightMouseDown(e)
        {
            if (!this.columnSpec.IsGroupColumn && !this.columnSpec.Selected && e.target !== this.sort.Element && e.target !== this.expandCollapse.Element)
            {
                this.grid.SelectColumn(this.columnSpec, e.ctrlKey, e.shiftKey);
            }
        }

        OnMouseUp(e)
        {
            if (e.button !== 0) return;

            if (!this.columnSpec.IsGroupColumn)
            {
                if (e.target === this.sort.Element) this.grid.SortColumn(this.columnSpec, e.ctrlKey, e.shiftKey);
                else if (e.target === this.expandCollapse.Element) this.grid.ToggleGroupExpandCollapse(this.columnSpec);
            }
        }

        Dispose()
        {
            this.RemoveEvent("mousedown", this.onMouseDown_Handler);
            this.RemoveEvent("mouseup", this.onMouseUp_Handler);
        }
    }
}
