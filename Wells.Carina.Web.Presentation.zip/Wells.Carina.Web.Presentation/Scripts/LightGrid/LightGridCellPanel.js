"use strict";
{
    let Core = Carina.Core;
    let UiUtil = Carina.Core.UiUtil;
    let LightGrid = Carina.LightGrid;

    Carina.LightGrid.LightGridCellPanel = class extends Core.BaseControl
    {
        constructor(cellPanel)
        {
            super();

            this.Parent = cellPanel;
            
        }

        Render(cellData, columnSpec)
        {
            if (columnSpec.Width !== this.columnSpec.Width) this.Width = columnSpec.Width;
            if (columnSpec.Locked !== this.columnSpec.Locked) this.Style("z-index", columnSpec.Locked === true ? LightGrid.LightGrid.LockedCellZIndex : LightGrid.LightGrid.CellZIndex);

            if (cellData.Top !== this.cellData.Top) this.Style("top", cellData.Top + "px");
            if (cellData.Left !== this.cellData.Left) this.Style("left", cellData.Left + "px");
            if (cellData.Data !== this.cellData.Data) this.textNode.data = cellData.Data !== undefined ? cellData.Data : null;

            if (columnSpec.Grouped !== this.columnSpec.Grouped)
            {
                this.RemoveChild(this.expandCollapse);
                if (columnSpec.Grouped)
                {
                    this.expandCollapse = new Core.GenericControl("div");
                    this.expandCollapse.AddClass("lightGrid-icon");
                    this.expandCollapse.AddClass("lightGrid-cell-groupicon");
                    this.expandCollapse.Style("top", this.grid.Spec.CellIconTop + "px");
                    this.InsertChildBefore(this.expandCollapse, this.textNode);
                }
            }

            if (columnSpec.Grouped === true)
            {
                if (cellData.Leaf === true || (!columnSpec.IsGroupColumn && cellData.Level !== cellData.ColumnIndex + 1))
                {
                     this.expandCollapse.Hide();
                }
                else
                {
                    this.expandCollapse.Show();
                    this.expandCollapse.RemoveClass(this.cellData.Expanded ? "lightGrid-icon-expanded" : "lightGrid-icon-collapsed");
                    this.expandCollapse.AddClass(cellData.Expanded ? "lightGrid-icon-expanded" : "lightGrid-icon-collapsed");

                    // TODO: LEFT padding Should come from server
                    const left = 2 + (columnSpec.IsGroupColumn ? (12 * (cellData.Level - 1)) : 0);
                    this.expandCollapse.Style("left", left + "px");
                    this.Style("padding-left", (left + 16) + "px");
                }
            }
            else
            {
                this.Style("padding-left", "2px");
            }

            // TODO: Logic should simplify once server sends calculated formatting / trigger info
            let foreground, background, fontFamily, fontStyle, fontWeight, fontSize, border, hAlignment;
            if (cellData.FormatInfo)
            {
                foreground = cellData.FormatInfo.Foreground ? cellData.FormatInfo.Foreground : columnSpec.Foreground;
                background = cellData.FormatInfo.Background ? cellData.FormatInfo.Background : columnSpec.Background;
                fontFamily = cellData.FormatInfo.FontFamily ? cellData.FormatInfo.FontFamily : columnSpec.FontFamily;
                fontStyle = cellData.FormatInfo.FontStyle ? cellData.FormatInfo.FontStyle : columnSpec.FontStyle;
                fontWeight = cellData.FormatInfo.FontWeight ? cellData.FormatInfo.FontWeight : columnSpec.FontWeight;
                fontSize = cellData.FormatInfo.FontSize ? cellData.FormatInfo.FontSize : columnSpec.FontSize;
                border = cellData.FormatInfo.CellBorder ? cellData.FormatInfo.CellBorder : columnSpec.CellBorder;
                hAlignment = cellData.FormatInfo.HorizontalAlignmnet ? cellData.FormatInfo.HorizontalAlignmnet : columnSpec.HorizontalAlignmnet;
            }
            else
            {
                foreground = columnSpec.Foreground;
                background = columnSpec.Background;
                fontFamily = columnSpec.FontFamily;
                fontStyle = columnSpec.FontStyle;
                fontWeight = columnSpec.FontWeight;
                fontSize = columnSpec.FontSize;
                border = columnSpec.CellBorder;
                hAlignment = columnSpec.HorizontalAlignmnet;
            }

            if (this.foreground !== foreground) { this.foreground = foreground; this.Style("color", UiUtil.GetHtmlColorFromColor(foreground)); }
            if (this.background !== background) { this.background = background; this.Style("background-color", UiUtil.GetHtmlColorFromColor(background)); }
            if (this.fontFamily !== fontFamily) { this.fontFamily = fontFamily; this.Style("font-family", fontFamily); }
            if (this.fontStyle !== fontStyle) { this.fontStyle = fontStyle; this.Style("font-style", fontStyle); }
            if (this.fontWeight !== fontWeight) { this.fontWeight = fontWeight; this.Style("font-weight", fontWeight); }
            if (this.fontSize !== fontSize) { this.fontSize = fontSize; this.Style("font-size", fontSize + "px"); }
            if (this.border !== border) { this.border = border; this.Style("border", border + "px solid"); }
           // if (this.hAlignment !== hAlignment) { this.hAlignment = hAlignment; this.Style("text-align", hAlignment); }

            this.columnSpec = columnSpec;
            this.cellData = cellData;
        }

        OnMouseDown(e)
        {
            if (this.expandCollapse && e.target === this.expandCollapse.Element) this.grid.ToggleNodeExpandCollapse(this.cellData.NodeId);
            else this.grid.SelectRow(this.cellData.RowIndex, this.columnSpec, e.ctrlKey, e.shiftKey);
        }

        OnMouseEnter(e)
        {
            if (!this.Parent.IsMouseDown) return;
            
            this.grid.SelectRow(this.cellData.RowIndex, this.columnSpec, false, true);
        }

        Dispose()
        {
            this.RemoveEvent("mousedown", this.onMouseDown_Handler);
            this.RemoveEvent("mouseenter", this.onMouseEnter_Handler);
        }
    }
}