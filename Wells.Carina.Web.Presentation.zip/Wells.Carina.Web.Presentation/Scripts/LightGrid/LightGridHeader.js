﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;

    Carina.LightGrid.LightGridHeader = class extends Core.BaseControl
    {
        constructor(lightGridPanel)
        {
            super();

            this.Parent = lightGridPanel;
            this.Element = document.createElement("div");
            this.Element.setAttribute("name", "LightGridHeader");
            this.AddClass("lightGrid-columnHeadersPanel");
            this.headers = [];
        }

        Reset()
        {
            this.Height = this.Parent.Spec.HeadersHeight;
            Core.UiUtil.RemoveChildren(this.Element);
        }

        Render(snapshot)
        {
            if (snapshot.Columns.length <= 0) return;

            let index = 0;
            for (; index < snapshot.Columns.length; index++)
            {
                if (index >= this.headers.length)
                {
                    var newHeader = new LightGrid.LightGridColumnHeader(this);
                    newHeader.Height = this.Parent.Spec.HeadersHeight;
                    this.headers.push(newHeader);
                    
                    this.AppendChild(newHeader.Element);
                }
                
                this.headers[index].Render(snapshot.Columns[index]);
                this.headers[index].Show();
            }

            for (; index < this.headers.length; index++)
            {
                this.headers[index].Hide();
            }
        }
    }
}