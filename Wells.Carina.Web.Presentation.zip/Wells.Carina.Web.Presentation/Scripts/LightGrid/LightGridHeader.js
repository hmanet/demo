﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;
    let UiUtil = Carina.Core.UiUtil;

    Carina.LightGrid.LightGridHeader = class extends Core.BaseControl
    {
        constructor(lightGridPanel)
        {
            super();

            this.Parent = lightGridPanel;
            this.grid = lightGridPanel;
            this.Element = document.createElement("div");
            this.Element.setAttribute("name", "LightGridHeader");
            this.AddClass("lightGrid-columnHeadersPanel");
            this.Attribute("draggable", true);

            this.headers = [];
            this.resizingColumnSpec = null;

            this.onMouseMove_Handler = UiUtil.Throttle(this.OnMouseMove).bind(this);
            this.AddEvent("mousemove", this.onMouseMove_Handler);

            this.onMouseUp_Handler = this.OnMouseUp.bind(this);
            this.AddEvent("mouseup", this.onMouseUp_Handler);

            this.onMouseLeave_Handler = this.OnMouseLeave.bind(this);
            this.AddEvent("mouseleave", this.onMouseLeave_Handler);

            this.onDragStart_Handler = this.OnDragStart.bind(this);
            this.AddEvent("dragstart", this.onDragStart_Handler);

            this.onDragOver_Handler = this.OnDragOver.bind(this);
            this.AddEvent("dragover", this.onDragOver_Handler);

            this.onDrop_Handler = this.OnDrop.bind(this);
            this.AddEvent("drop", this.onDrop_Handler);

            this.dragCanvas = document.getElementById("lightGridHeaderDragDropCanvas");
            if (!this.dragCanvas)
            {
                this.dragCanvas = document.createElement("canvas");
                this.dragCanvas.id = "lightGridHeaderDragDropCanvas";
                this.dragCanvas.style["z-index"] = 20;
                this.dragCanvas.style["position"] = "absolute";
                this.dragCanvas.style["left"] = "-100%";
                document.body.appendChild(this.dragCanvas);
            }
        }

        get Grid() { return this.grid; }

        get ResizingColumnSpec() { return this.resizingColumnSpec; }
        set ResizingColumnSpec(value) { this.resizingColumnSpec = value; }

        Reset()
        {
            this.Height = this.grid.Spec.HeadersHeight;
            Core.UiUtil.RemoveChildren(this.Element);
            this.dropIndicator = new Core.DivControl();
            this.dropIndicator.AddClass("lightGrid-header-dropIndicator");
            this.AppendChild(this.dropIndicator);
            this.HideDropIndicator();
        }

        Render(snapshot)
        {
            let index = 0;
            for (; index < snapshot.Columns.length; index++)
            {
                if (index >= this.headers.length)
                {
                    let header = new LightGrid.LightGridColumnHeader(this);
                    
                    this.headers.push(header);
                    this.AppendChild(header.Element);
                }
                
                this.headers[index].Render(snapshot, index);
                this.headers[index].Show();
            }

            for (; index < this.headers.length; index++)
            {
                this.headers[index].Hide();
            }
        }

        OnMouseMove(e)
        {
            if (e.button !== 0 || this.resizingColumnSpec === null) return;

            this.resizingColumnSpec.Width += e.pageX - (this.resizingColumnSpec.Left + this.resizingColumnSpec.Width);
            this.grid.ResizeColumn(this.resizingColumnSpec);
        }

        OnMouseLeave(e)
        {
            this.resizingColumnSpec = null;
            this.HideDropIndicator();
        }

        OnMouseUp(e)
        {
            this.resizingColumnSpec = null;
        }

        OnDragStart(event)
        {
            const context = this.dragCanvas.getContext("2d");

            this.dragCanvas.width = 200;
            this.dragCanvas.height = 20;

            context.fillStyle = "#CCCCCC";
            context.fillRect(0, 0, this.dragCanvas.width, this.dragCanvas.height);

            context.fillStyle = "#000000";
            context.font = "12px Arial";
            context.fillText("Dragging columns", 5, 15);

            event.dataTransfer.setData("text", "lorem ipsum");
            event.dataTransfer.effectAllowed = "move";
            event.dataTransfer.setDragImage(this.dragCanvas, -15, 9);
        }

        OnDragOver(e)
        {
            e.preventDefault();
            this.dropHeaderElement = this.GetColumnHeader(e);
            if (this.dropHeaderElement)
            {
                this.dropIndicator.Element.style["left"] = this.dropHeaderElement.style["left"];
                this.dropIndicator.Show();
            }
            else
            {
                 this.HideDropIndicator();
            }
        }
        GetColumnHeader(e)
        {
            let target = e.target;
            for (let i = 0; i < 5; i++)
            {
                if(!target) return null;
                if (target.id === LightGrid.LightGridColumnHeader.CommonId) return target;

                target = target.parentElement;
            }

            return null;
        }

        OnDrop(e)
        {
            if (this.dropHeaderElement)
            {
                let dropHeader;
                for (let i = 0; i < this.headers.length; i++)
                {
                    if (this.headers[i].Element === this.dropHeaderElement)
                    {
                        dropHeader = this.headers[i];
                        break;
                    }
                }

                if (dropHeader) this.grid.DropColumnsToTarget(dropHeader.ColumnSpec, e.ctrlKey);
            }

            this.HideDropIndicator();
        }

        HideDropIndicator() { this.dropIndicator.Hide(); this.dropHeaderElement = null; }
    }
}