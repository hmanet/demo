"use strict";
{
    let Model = Carina.Model;

    let ColorTranDict = {};

    Carina.Core.UiUtil = class
    {
        static CalculateViewportResolution()
        {
            let width = Math.ceil(window.innerWidth);
            let height = Math.ceil(window.innerHeight);
            return new Model.Size(width, height);
        }

        static RemoveChildren(node)
        {
            let firstChild = node.firstChild;
            while (firstChild)
            {
                node.removeChild(firstChild);
                firstChild = node.firstChild;
            }
        }

        static Debounce(callback, delay)
        {
            return _.debounce(callback, delay ? delay : 100);
        }

        static Throttle(callback, delay)
        {
            return _.throttle(callback, delay ? delay : 100);
        }

        static GetHtmlColorFromColor(color)
        {
            if (color && color.substring(0, 1) === "#" && (color.length === 7 || color.length === 9))
            {
                if (!ColorTranDict[color])
                {
                    ColorTranDict[color] = color.length === 7 ? `rgb(${parseInt(color.substring(1, 3), 16)},${parseInt(color.substring(3, 5), 16)},${parseInt(color.substring(5), 16)})` : `rgba(${parseInt(color.substring(3, 5), 16)},${parseInt(color.substring(5, 7), 16)},${parseInt(color.substring(7), 16)},${parseInt(color.substring(1, 3), 16) / 255})`;// color.substring(0, 1) + color.substring(3) + color.substring(1, 3);
                }

                return ColorTranDict[color];
            }

            return color;
        }
        static GetGradientColor(firstColor, lastColor) {
            let gradientColor = null;
            gradientColor = "linear-gradient(" + Carina.Core.UiUtil.GetHtmlColorFromColor(firstColor)
                + "," + Carina.Core.UiUtil.GetHtmlColorFromColor(lastColor) + ")";
            return gradientColor;
        }

        static FindParent(element, checkFunction, maxLevel)
        {
            let level = 0;
            while (element)
            {
                if (checkFunction(element)) return element;

                if (maxLevel)
                {
                    level++;
                    if (level >= maxLevel) return null;
                }

                element = element.parentElement;
            }

            return null;
        }
    }
}