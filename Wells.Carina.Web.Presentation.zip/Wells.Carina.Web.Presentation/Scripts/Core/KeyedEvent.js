"use strict";
{
    Carina.Core.CarinaEvent = class
    {
        constructor()
        {
            this.handlers = [];
        }

        Add(handler)
        {
            this.handlers.push(handler);
        }

        Remove(handler)
        {
            if (handler)
            {
                const i = this.handlers.indexOf(handler);
                if (i !== -1) this.handlers.splice(i, 1);
            }
            else
            {
                this.handlers = [];
            }
        }

        Invoke(eventArgs)
        {
            for (let i = 0; i < this.handlers.length; i++)
            {
                this.handlers[i](eventArgs);
            }
        }
    }

    Carina.Core.KeyedEvent = class
    {
        constructor()
        {
            this.handlers = {};
        }


        Add(key, handler)
        {
            if (this.handlers[key] == null) this.handlers[key] = new Array();

            this.handlers[key].push(handler);
        }

        Remove(key, handler)
        {
            if (this.handlers[key] == null) return;

            let index = this.handlers[key].indexOf(handler);
            if (index >= 0) this.handlers[key].splice(index, 1);
        }

        Invoke(key, value)
        {
            let h = this.handlers[key];
            if (h == undefined) return;

            return h[0](value);
        }
    }
}