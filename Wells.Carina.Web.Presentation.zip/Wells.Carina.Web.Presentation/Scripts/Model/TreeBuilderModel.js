﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.Model.TreeBuilderModel = class
    {
        constructor(source)
        {
            this.snapshot = null;
            this.source = source;
            this.SnapshotChanged = new Core.CarinaEvent();

            this.source_OnSnapshotReceived_Handler = this.Source_OnSnapshotReceived.bind(this);
            this.source.SnapshotReceived.Add(this.source_OnSnapshotReceived_Handler);
        }

        Source_OnSnapshotReceived(value)
        {
            this.Snapshot = value;
        }
        get Snapshot() { return this.snapshot; }
        set Snapshot(value)
        {
            this.snapshot = value;
            this.SnapshotChanged.Invoke(value);
        }
        SendAcknowldegment(viewport)
        {
            this.source.SendSnapshotRecievedAcknowledgement();
        }
        Scroll(viewport)
        {
            this.source.GetSnapShot(viewport);
        }

        ToggleColumnSelected(columnSpec, ctrlKey, shiftKey){ this.source.SendUserAction({ UserAction: "ToggleColumnSelection", Column: this.GetColumnInfo(columnSpec), KeyButtonAction: this.GetKeyButtonAction(ctrlKey, shiftKey), MouseButtonAction: "Left" });}

        ToggleRowSelected(rowIndex, columnSpec, ctrlKey, shiftKey){ this.source.SendUserAction({ UserAction: "ToggleRowSelection", Cell: { RowIndex: rowIndex, ColumnIndex: columnSpec.Index }, KeyButtonAction: this.GetKeyButtonAction(ctrlKey, shiftKey), MouseButtonAction: "Left" }); }

        SortColumn(columnSpec, ctrlKey, shiftKey){ this.source.SendUserAction({ UserAction: "SortColumn", Column: this.GetColumnInfo(columnSpec), KeyButtonAction: this.GetKeyButtonAction(ctrlKey, shiftKey), MouseButtonAction: "Left" }); }

        ResizeColumn(columnSpec){ this.source.SendUserAction({ UserAction: "ResizeColumn", Column: this.GetColumnInfo(columnSpec) }); }

        DropColumnsToTarget(targetColumnSpec, ctrlKey){ this.source.SendUserAction({ UserAction: "DropColumns", Column: this.GetColumnInfo(targetColumnSpec), KeyButtonAction: this.GetKeyButtonAction(ctrlKey) }); }

        ToggleGroupExpandCollapse(columnSpec) { this.source.SendUserAction({ UserAction: "ToggleGroupExpandCollapse", Column: this.GetColumnInfo(columnSpec) }); }

        ToggleNodeExpandCollapse(nodeId) { this.source.SendUserAction({ UserAction: "ToggleNodeExpandCollapse", NodeId: nodeId }); }

        GetContextMenu(menuLevel, pageX, pageY) { this.source.SendUserAction({ UserAction: "GetContextMenu", Level: menuLevel, PageX: pageX, pageY: pageY }); }

        ContextMenuCallback(menuItem) { this.source.SendUserAction({ UserAction: "ContextMenuCallback", MenuId: menuItem.Id }); }

        GetColumnInfo(columnSpec){ return { Index: columnSpec.Index, Grouped: columnSpec.Grouped, Width: columnSpec.Width }; }

        GetKeyButtonAction(ctrlKey, shiftKey)
        {
            if (ctrlKey) return "Ctrl";
            if (shiftKey) return "Shift";
            return "None";
        }

        Dispose()
        {
            this.source.SnapshotReceived.Remove(this.source_OnSnapshotReceived_Handler);
        }
    }
}