"use strict";
{
    // Namespace import
    let Server = Carina.Server;

    Carina.Server.CarinaWebSocketClient = class
    {
        constructor(connectionUri, proxyName, connectionQs)
        {
            this.connectionUri = connectionUri;
            this.signalrConnection = $.hubConnection(this.connectionUri, { useDefaultPath: false });
            this.webSocketProxy = this.signalrConnection.createHubProxy(proxyName);
            this.webSocketProxy.connection.qs = connectionQs;
            //this.signalrConnection.logging = true;
            this.requestIndex = 0;
            this.receivedEvent = new Server.SignalRKeyedEvent(this.webSocketProxy);
        }

        get ReceivedEvent() { return this.receivedEvent; }

        Start(handler)
        {
            this.signalrConnection.start({ waitForPageLoad: false }).done(function()
                {
                    //alert("Connected to Signalr Server11");
                    handler();
                })
                .fail(function(error)
                {
                    //alert("failed in connecting to the signalr server");
                });
        }

        Send(key, value)
        {
            if (value == undefined)
            {
                this.webSocketProxy.invoke(key);
            }
            else
            {
                value.RequestId = this.requestIndex++;
                this.webSocketProxy.invoke(key, value);
            }
        }
    }

    Carina.Server.SignalRKeyedEvent = class
    {
        constructor(webSocketProxy)
        {
            this.webSocketProxy = webSocketProxy;
        }

        Add(eventName, callback)
        {
            this.webSocketProxy.on(eventName, callback);
        }

        Remove(eventName, callback)
        {
            this.webSocketProxy.off(eventName, callback);
        }
    }
}