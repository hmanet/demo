﻿using System.Globalization;
using Wells.Carina.Web.API.Models;
using Wells.Derivatives.Carina.Core.Presentation.Grid;

namespace Wells.Carina.Web.Presentation.Utilities
{
    public static class MappingHelper
    {
        public static LightGridColumn Map(ColumnSpec column)
        {
            var col = new LightGridColumn
            {
                Width = column.Width,
                Visible = column.Visible,
                Background = column.Background.ToString(),
                DecimalPlaces = column.DecimalPlaces ?? default(int),
                Editable = column.Editable,
                FontFamily = column.FontFamily.Source,
                FontSize = column.FontSize.ToString(CultureInfo.InvariantCulture),
                FontStyle = column.FontStyle.ToString(),
                FontWeight = column.FontWeight.ToString(),
                Foreground = column.Foreground.ToString(),
                Name = column.Label,
                CellBorder = column.Border.ToString(),
                HorizontalAlignmnet = column.HorizontalAlignment.ToString(),
                VerticalAlignmnet = column.VerticalAlignment.ToString(),
                IsGrouped = column.Grouped,
                IsLocked = column.Locked,
                Left = column.Left
            };

            return col;
        }

        public static FormatInfo Map(TriggerStyle trigger)
        {
            var format = new FormatInfo
            {
                Editable = trigger.Editable ?? default(bool),
                Visible = trigger.Visible ?? default(bool),
                Strikethrough = trigger.Strikethrough ?? default(bool),
                Underline = trigger.Underline ?? default(bool),

                Background = trigger.Background != null ? trigger.Background.ToString() : null,
                Foreground = trigger.Foreground != null ? trigger.Foreground.ToString() : null,
                RowBorder = trigger.Foreground != null ? trigger.Foreground.ToString() : null,
                CellBorder = trigger.Foreground != null ? trigger.Foreground.ToString() : null,

                HorizontalAlignment = trigger.HorizontalAlignment != null ? trigger.HorizontalAlignment.ToString() : null,
                FontFamily = trigger.FontFamily != null ? trigger.FontFamily.ToString() : null,
                FontStyle = trigger.FontStyle != null ? trigger.FontStyle.ToString() : null,
                FontWeight = trigger.FontWeight != null ? trigger.FontWeight.ToString() : null,
                FontSize = trigger.FontSize.HasValue ? trigger.FontSize.ToString() : null,
            };
            return format;
        }
    }
}
