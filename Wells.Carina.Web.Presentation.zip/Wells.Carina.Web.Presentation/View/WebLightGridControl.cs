﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using CefSharp;
using CefSharp.Wpf;
using Newtonsoft.Json;
using Wells.Derivatives.Carina.Core.Command;

namespace Wells.Carina.Web.Presentation.View
{
    public class WebLightGridControl : Control
    {
        private const string SCRIPTFILE = "";
        private ChromiumWebBrowser webBrowser;
        private bool isShowDeveloperTools;
        private string serverAddress;
        private string runTimeId;
        static WebLightGridControl()
        {
            DataContextProperty.OverrideMetadata(typeof(WebLightGridControl),
                new FrameworkPropertyMetadata(
                    (d, a) => ((WebLightGridControl) d).OnDataContextChanged(a.OldValue, a.NewValue), (d, v) => v));
            if (Cef.IsInitialized) return;

            // Fix for occasional failure to find cef dependencies.
            var basePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            var cefSettings = new CefSettings { BrowserSubprocessPath = Path.Combine(basePath, "CefSharp.BrowserSubprocess.exe") };
           
            Cef.Initialize(cefSettings);
           

        }

        public CarinaCommand ShowDevToolsCommand { get; set; }

        private void OnDataContextChanged(object oldValue, object newValue)
        {
            SetupContextMenu();
        }

        public WebLightGridControl()
        {
            ApplyTemplate();
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            webBrowser = (ChromiumWebBrowser) Template.FindName("ChromiumWebBrowser", this);
            webBrowser.LoadingStateChanged += WebBrowserLoadingStateChanged;
            webBrowser.FrameLoadEnd += WebBrowser_FrameLoadEnd;
            webBrowser.Address = string.Format("file:///{0}\\..\\..\\WebLightGrid\\{1}",
                Directory.GetCurrentDirectory(), SCRIPTFILE);
        }

        private void WebBrowser_FrameLoadEnd(object sender, FrameLoadEndEventArgs e)
        {
            if (webBrowser.CanExecuteJavascriptInMainFrame)
            {
                var inovke = string.Format("Carina.App.LoadGrid('{0}','{1}')", serverAddress, runTimeId);
                webBrowser.ExecuteScriptAsync(inovke);
            }
        }

       
        public static readonly DependencyProperty ScriptFileProperty =
            DependencyProperty.Register("ScriptFile", typeof(string), typeof(WebLightGridControl),
                new PropertyMetadata(SCRIPTFILE, OnScriptFileChanged));

        public string ScriptFile
        {
            get { return (string) GetValue(ScriptFileProperty); }
            set { SetValue(ScriptFileProperty, value); }
        }

        private static void OnScriptFileChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (e.NewValue == null) return;
            var vc = (WebLightGridControl) d;
            if (vc.webBrowser == null) return;
            vc.webBrowser.Address = string.Format("file:///{0}\\..\\..\\WebLightGrid\\{1}",
                Directory.GetCurrentDirectory(), e.NewValue);
            
        }


        private bool browserLoaded;

        private static void OnShowDevTools(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var isShowDevTools = (bool) e.NewValue;
            var vc = (WebLightGridControl)d;
            if (vc.webBrowser == null) return;
            if (isShowDevTools)
            {
                vc.webBrowser.ShowDevTools();
            }
            else
            {
                vc.webBrowser.CloseDevTools();
            }

        }

        private static readonly JsonSerializerSettings serializerSettings = new JsonSerializerSettings { DateParseHandling = DateParseHandling.None};

        private static void OnServerAddress(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var vc = (WebLightGridControl)d;
            vc.serverAddress = e.NewValue.ToString();
        }

        private static void OnRunTimeId(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var vc = (WebLightGridControl)d;
            vc.runTimeId = e.NewValue.ToString();
        }

        public static readonly DependencyProperty ShowDevToolsProperty =
            DependencyProperty.Register("ShowDevTools", typeof(bool), typeof(WebLightGridControl),
                new PropertyMetadata(false, OnShowDevTools));

        public bool ShowDevTools
        {
            get { return (bool)GetValue(ShowDevToolsProperty); }
            set { SetValue(ShowDevToolsProperty, value); }
        }


        public static readonly DependencyProperty ServerAddressProperty =
            DependencyProperty.Register("ServerAddress", typeof(string), typeof(WebLightGridControl),
                new PropertyMetadata("test", OnServerAddress));

        public string ServerAddress
        {
            get { return (string)GetValue(ServerAddressProperty); }
            set { SetValue(ServerAddressProperty, value); }
        }

        public static readonly DependencyProperty RuntimeIdProperty =
            DependencyProperty.Register("RuntimeId", typeof(string), typeof(WebLightGridControl),
                new PropertyMetadata("", OnRunTimeId));

        

        public string RuntimeId
        {
            get { return (string)GetValue(RuntimeIdProperty); }
            set { SetValue(RuntimeIdProperty, value); }
        }

        private void WebBrowserFrameLoadEnd(object sender, FrameLoadEndEventArgs e)
        {
            if (!e.Frame.IsMain) return;

            browserLoaded = true;
        }

        private void WebBrowserLoadingStateChanged(object sender, LoadingStateChangedEventArgs e)
        {
            if (e.IsLoading) return;

            DispatcherInvoke(Initialize);
        }

        private void DispatcherInvoke(Action action)
        {
            if (Dispatcher.CheckAccess())
            {
                action.Invoke();
                return;
            }

            Dispatcher.BeginInvoke(action);
        }

        private bool IsBrowserLoaded()
        {
            if (webBrowser.IsBrowserInitialized == false || webBrowser.IsLoaded == false ||
                browserLoaded == false) return false;

            return true;
        }

        private void Initialize()
        {
            if (DataContext == null || !IsBrowserLoaded()) return;

            webBrowser.LoadingStateChanged -= WebBrowserLoadingStateChanged;
            webBrowser.FrameLoadEnd -= WebBrowserFrameLoadEnd;
        }

        private void SetupContextMenu()
        {
            MenuItem item = new MenuItem();
            item.Header = "DevTools";
            item.Click += Item_Click;
            if (ContextMenu != null) ContextMenu.Items.Add(item);
        }

        private void Item_Click(object sender, RoutedEventArgs e)
        {
            if (!isShowDeveloperTools)
                webBrowser.ShowDevTools();
            else
            {
                webBrowser.CloseDevTools();
            }

            isShowDeveloperTools = !isShowDeveloperTools;
        }
    }
}

