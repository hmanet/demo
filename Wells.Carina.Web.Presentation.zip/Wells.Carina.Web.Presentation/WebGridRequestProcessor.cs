﻿using Wells.Carina.Web.API.Models.Requests;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Carina.Web.Presentation
{
    public interface IWebGridRequestProcessor
    {
        void Process(WebGridRequest request);
    }

    /// <summary>
    /// Converts the Web Requests to appropriate Light Grid Commnad objects and executes them on the Grid source.
    /// </summary>
    public class WebGridRequestProcessor : IWebGridRequestProcessor
    {
        private readonly GridViewModel grid;

        public WebGridRequestProcessor(GridViewModel gridViewModel)
        {
            grid = gridViewModel;
        }

        public void Process(WebGridRequest request)
        {
            ExecuteGridCommand((dynamic)request);  
        }

        private void ExecuteGridCommand(UpdateViewPortRequest request)
        {
            if (request.VerticalViewport != null)
            {
                grid.Tree.ViewportOffset = request.VerticalViewport.Offset;
                grid.Tree.ViewportSize = request.VerticalViewport.Size;
                grid.Tree.TotalViewportSize = request.VerticalViewport.Size;
            }

            if (request.HorizontalViewport != null)
            {
                grid.ViewportOffset = request.HorizontalViewport.Offset;
                grid.TotalViewportSize = request.HorizontalViewport.Size;
            }
        }
    }
}
