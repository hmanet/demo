﻿using System;
using Wells.Carina.Web.API.Interfaces;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Requests;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Carina.Web.Presentation
{
    public class WebGridRequestVisitor : IWebGridRequestVisitor
    {
        private readonly GridViewModel grid;

        public WebGridRequestVisitor(GridViewModel gridViewModel)
        {
            grid = gridViewModel;
        }

        public void Process(UpdateViewPortRequest updateViewPortRequest)
        {
            
        }

        public void Process(ColumnInfo columnHeaderRequest)
        {
            throw new NotImplementedException();
        }

        public void Process(CellInfo cellRequest)
        {
            throw new NotImplementedException();
        }
    }
}
