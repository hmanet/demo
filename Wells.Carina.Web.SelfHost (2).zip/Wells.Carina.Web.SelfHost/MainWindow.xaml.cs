﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Wells.Carina.Web.Presentation;
using Wells.Carina.Web.Presentation.Utilities;

namespace Wells.Carina.Web.SelfHost
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs routedEventArgs)
        {
            MockDataSource mockData = new MockDataSource();
            WebServer.ConfigurePortsRange(8000, 10000);

            var serverUrl = "http://localhost:{0}/";
            var runtimeId = "12345";
            WebServer webServer = new WebServer(serverUrl);
            webServer.Start();

            mockData.BuildMockData(webServer.ServerAddress, runtimeId);

            Status.Text = "Server started.";
            BrowserStatus.Text = "Chrome Statring";

            var htmlUrl = string.Format("file:///{0}\\{1}",
                Directory.GetCurrentDirectory(), "Component.html");

            htmlUrl = System.Web.HttpUtility.UrlPathEncode(htmlUrl) + "?serverAddress=" + webServer.ServerAddress + "&" + "runtimeId=" + runtimeId;

            try
            {
                string startUrl = Directory.GetCurrentDirectory() + "\\" + "Component.html";
                
                string chromePath = GetChromePath();
                Process.Start(chromePath, htmlUrl);
                BrowserStatus.Text = "Chrome Launched";
            }
            catch (Exception)
            {
                BrowserStatus.Text = "Chrome Failed to Launch, Please open Component page Url manually";
            }
            

        }

        
        private string GetChromePath()
        {
            const string suffix = @"Google\Chrome\Application\chrome.exe";
            var prefixes = new List<string> { Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) };
            var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            var programFilesx86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            if (programFilesx86 != programFiles)
            {
                prefixes.Add(programFiles);
            }
            else
            {
                var programFilesDirFromReg = Microsoft.Win32.Registry.GetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion", "ProgramW6432Dir", null) as string;
                if (programFilesDirFromReg != null) prefixes.Add(programFilesDirFromReg);
            }

            prefixes.Add(programFilesx86);
            var path = prefixes.Distinct().Select(prefix => System.IO.Path.Combine(prefix, suffix)).FirstOrDefault(File.Exists);

            return path;
        }

        
    }
}
    

