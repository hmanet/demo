﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net.Http;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Threading;
//using Microsoft.Owin.Hosting;

//namespace Wells.Carina.Web.SelfHost
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            //var tem = Dispatcher.CurrentDispatcher;
//            MockDataSource mockData = new MockDataSource();
//            mockData.StartWebServer();
//            mockData.BuildMockData();
           
//            Console.ReadLine();
//        }
//    }
//}
