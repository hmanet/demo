﻿using System;
using Microsoft.Owin.Hosting;
using Wells.Carina.Web.Presentation.ViewModel;
using Wells.Derivatives.Carina.Core.Events;
using Wells.Derivatives.Carina.Core.Metadata;
using Wells.Derivatives.Carina.Core.Model.Showcase.Examples;
using Wells.Derivatives.Carina.Core.Model.Tree;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Carina.Web.SelfHost
{
    public class MockDataSource
    {
        private string hostingAddress = "http://localhost:9000/";

        public void BuildMockData(string serverAddress,string runtimeId,string homepage="")
        {
            var eventBus = new EventBus();
            var treeSource = new SolarSystemBodies(eventBus);
            var gridViewModel = new GridViewModel("GRID",treeSource.AttributeDefinitions, treeSource,TreeCharacteristics.All);
            
            foreach (AttributeMetadata attribute in gridViewModel.Spec.Attributes)
            {
                var columnSpec = new ColumnSpec(attribute);
                
                gridViewModel.Spec.Columns.Add(columnSpec);
            }
            gridViewModel.Tree.TotalViewportSize = 210;

            var webLightGridViewModel = new WebLightGridViewModel(runtimeId, homepage, serverAddress, gridViewModel, eventBus);
            webLightGridViewModel.Initialize();

            gridViewModel.Started = true;
            
        }

        
    }
}
