﻿using System.Windows.Media;

namespace Wells.Carina.Web.Presentation.Utilities
{
    public class ColorTranslator
    {
        public string GetRgbaColorInHex(Color argbColor)
        {
            return GetHexColor(argbColor);
        }

        public string GetArgbColorInHex(Color rgbacolor)
        {
            return null;
        }

        public string GetWebSupportedLinearGradient(Color argbColorA, Color argbColorB,double lenghtA=0, double lenghtB=0)
        {
            string linearGradient;

            //TODO: Need to implment building of it using a proper builder.
            linearGradient=string.Format("linear-gradient(to bottom, rgba({0},{1},{2},{3}),rgba({4},{5},{6},{7}))", argbColorA.R, argbColorA.G, argbColorA.B, argbColorA.A, 
                argbColorB.R, argbColorB.G, argbColorB.B, argbColorB.A);

            return linearGradient;
        }

        private string GetHexColor(Color color)
        {
            string rgbaColor;

            var colorUint = ColorToUInt(color);
            var rgbaUnit = ConvertToRgba(colorUint);

            rgbaColor = string.Format("#"+rgbaUnit.ToString("x"));

            return rgbaColor;
        }

        private uint ColorToUInt(Color color)
        {
            return (uint)((color.A << 24) | (color.R << 16) |
                          (color.G << 8) | (color.B << 0));
        }

        public uint ConvertToRgba(uint rgba)
        {
            return (rgba << 8) | (rgba >> (32 - 8));
        }
    }
}
