﻿using System;
using System.Windows.Input;
using Common.Logging;
using Wells.Derivatives.Carina.Core.Command;
using Wells.Derivatives.Carina.Core.Events;
using Wells.Derivatives.Carina.Core.Interfaces;
using Wells.Derivatives.Carina.Core.Presentation.Common;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;

namespace Wells.Carina.Web.Presentation.ViewModel
{
    public class WebLightGridComponentViewModel : CarinaViewModelBase
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(WebLightGridComponentViewModel));

        private readonly IEventBus eventBus;

        public WebLightGridComponentViewModel(IComponentContext componentContext, IEventBus eventBus): base(componentContext)
        {
            this.eventBus = eventBus;
            this.eventBus.Exception += OnException;
            ShowDevToolsCommand = new CarinaCommand(ExecuteShowDevTools, true);
            WebServer.ConfigurePortsRange(8000, 10000);
        }

        

        private string hostingAddress = "http://localhost:{0}/";

        private string homePage = "Component.html";

        public override string ComponentTitle { get { return "WebLightGrid"; } }

        public ICommand ShowDevToolsCommand { get; private set; }

        public WebLightGridViewModel WebLightGridViewModel { get { return webLightGridViewModel.Value; } set { webLightGridViewModel.SetValue(this, value); } }
        private Property<WebLightGridViewModel> webLightGridViewModel = new Property<WebLightGridViewModel>();

        private void ExecuteShowDevTools()
        {
            webLightGridViewModel.Value.ShowDevTools = !webLightGridViewModel.Value.ShowDevTools;
        }

        private string StartWebServer()
        {
            WebServer webServer = new WebServer(hostingAddress);
            webServer.Start();
            return webServer.ServerAddress;
        }

        public void Initialize(string gridType, string gridTitle, string gridName, GridViewModel source)
        {
            var serverWebAddress = StartWebServer();
            WebLightGridViewModel = new WebLightGridViewModel(Guid.NewGuid().ToString(), homePage, serverWebAddress, source, eventBus);
            WebLightGridViewModel.Initialize();
        }

        protected override void ComponentDispose(bool disposing)
        {
            WebLightGridViewModel.Dispose();
            base.ComponentDispose(disposing);
        }

        private void OnException(EventBusArgs<Exception> args)
        {
            args.Handle(this);
            log.Error("[WebLightGridComponentViewModel] Error :" + args.Value);
        }
    }
}
