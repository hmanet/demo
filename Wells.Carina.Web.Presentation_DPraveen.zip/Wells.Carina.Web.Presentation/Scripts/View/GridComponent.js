"use strict";
{
    // Namespace import
    let LightGrid = Carina.LightGrid;
    let Core = Carina.Core;

    Carina.View.GridComponent = class extends Core.BaseComponent
    {
        constructor()
        {
            super();

            this.lightGrid = new LightGrid.LightGrid();

            this.Element = document.createElement("div");
            this.Element.id = "GridComp";
            this.Element.appendChild(this.lightGrid.Element);
        }

        OnDataContextChanged(oldValue, newValue)
        {
            this.lightGrid.DataContext = newValue ? newValue.GridViewModel : null;
        }
    }
}