"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let Server = Carina.Server;

    Carina.Server.CarinaServer = class
    {
        constructor(serverUrl, webApiRelUrl, proxyName, connectionQs)
        {
            this.connectionUri = serverUrl + webApiRelUrl;
            this.webSocketClient = new Server.CarinaWebSocketClient(serverUrl + "signalr", proxyName, connectionQs);

            this.receivedEvent = this.webSocketClient.ReceivedEvent;
            this.receivedEventAjax = new Core.KeyedEvent();
            this.started = new Core.CarinaEvent();
            this.stopped = new Core.CarinaEvent();
        }

        get ReceivedEvent() { return this.receivedEvent; }
        get ReceivedEventAjax() { return this.receivedEventAjax; }
        get Started() { return this.started; }
        get Stopped() { return this.stopped; }

        Start()
        {
            if (this.webSocketClient.signalrConnection.state !== $.signalR.connectionState.disconnected)
            {
                console.log("Server can not be started as it is already started or start is in progress.");
                return;
            }

            this.webSocketClient.Start(this.OnStarted.bind(this));
        }
        OnStarted()
        {
            this.started.Invoke();
        }

        SendAjax(key, value)
        {
            if (value == undefined)
            {
                return $.ajax
                ({
                    url: this.connectionUri + key,
                    type: "Get",
                    success: (data) => { this.receivedEventAjax.Invoke(key, data); },
                    error: (data) => { return "Error with request: " + key; }
                });
            }
            else
            {
                return $.ajax
                ({
                    url: this.connectionUri + key,
                    type: "Get",
                    dataType: 'json',
                    data: value.value,
                    success: (data) =>
                    {
                        //debugger
                        if (value.updateData)
                        {
                            value.updateData.data = data;
                            this.receivedEventAjax.Invoke(value.event, value.updateData);
                        }
                        else
                        {
                            debugger;
                            this.receivedEventAjax.Invoke(value.event, data);
                        }
                    },
                    error: (data) => { return "Error with request: " + key; }
                });
            }
        }
        Send(key, value)
        {
            if (this.webSocketClient.signalrConnection.state !== $.signalR.connectionState.connected)
            {
                console.log("Server is not connected.");
                return;
            }

            this.webSocketClient.Send(key, value);
        }
    }
}