"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let LightGrid = Carina.LightGrid;
    let Model = Carina.Model;
    let UiUtil = Carina.Core.UiUtil;

    Carina.LightGrid.LightGrid = class extends Core.BaseControl
    {
        constructor()
        {
            super();

            this.onScroll_Vertical_Handler = this.OnScroll_Vertical.bind(this);
            this.onScroll_Horizontal_Handler = this.OnScroll_Horizontal.bind(this);
            this.dataContext_OnPropertyChanged_Handler = this.DataContext_OnPropertyChanged.bind(this);
            this.onResize_Handler = this.OnResize.bind(this);

            this.Element = document.createElement("div");
            this.Attribute("name", "LightGrid");

            // Bar Panel
            this.barPanel = new LightGrid.LightGridBarPanel(this);
            this.AppendChild(this.barPanel);

            // Layout Grid
            this.layoutGrid = new Core.DivControl("LayoutGrid");
            this.layoutGrid.AddClass("lightGrid-layoutGrid");
            this.AppendChild(this.layoutGrid);

            // Layout Grid children
            {
                // vertical scrollbar
                this.verticalScrollbar = new Core.ScollbarControl("v");
                this.verticalScrollbar.AddClass("lightGrid-verticalScrollBar");
                this.verticalScrollbar.AddEvent("scroll", this.onScroll_Vertical_Handler);
                this.layoutGrid.AppendChild(this.verticalScrollbar);

                // header
                this.header = new LightGrid.LightGridHeader(this);
                this.layoutGrid.AppendChild(this.header);

                // menu
                this.menuPanel = new LightGrid.LightGridMenuPanel(this);
                this.layoutGrid.AppendChild(this.menuPanel);

                // filter
                this.filterPanel = new LightGrid.LightGridFiltersPanel(this);
                this.layoutGrid.AppendChild(this.filterPanel);

                // main cell panel
                this.panel = new LightGrid.LightGridPanel(this);
                this.layoutGrid.AppendChild(this.panel);

                // horizontal scrollbar
                this.horizontalScrollBar = new Core.ScollbarControl("h");
                this.horizontalScrollBar.AddClass("lightGrid-horizontalScrollBar");
                this.horizontalScrollBar.AddEvent("scroll", this.onScroll_Horizontal_Handler);
                this.layoutGrid.AppendChild(this.horizontalScrollBar);
            }

            // tool bar
            this.toolBar = new LightGrid.LightGridToolBar(this);
            this.Element.appendChild(this.toolBar.Element);

            //this.onResize_Handler = Core.UiUtil.Throttle(this.OnResize).bind(this);
            window.addEventListener("resize", this.onResize_Handler);

            this.horizontalViewport = new Model.Viewport(0 ,0 ,0);
            this.verticalViewport = new Model.Viewport(0, 0, 0);

            this.scrollTop = 0;
            this.scrollLeft = 0;

            this.viewportChanged = false;

            this.contextMenuCallback_Handler = this.ContextMenuCallback.bind(this);
            this.onContextMenu_Handler = this.OnContextMenu.bind(this);
            this.layoutGrid.AddEvent("contextmenu", this.onContextMenu_Handler);

            this.onMouseWheel_Handler = this.OnMouseWheel.bind(this);
            this.layoutGrid.AddEvent("mousewheel", this.onMouseWheel_Handler);
        }

        static get TypeKey() { return "lgtypekey"; }
        static get TypeCell() { return "lgcell"; }
        static get TypeCol() { return "lgcol"; }
        static get TypeFilter() { return "lgfilter"; }

        static get CellZIndex() { return 0; }
        static get ActiveCellZIndex() { return 1; }
        static get SeparatorZIndex() { return 2; }
        static get EditorZIndex() { return 3; }
        static get LockedCellZIndex() { return 4; }
        static get ColumnThumbZIndex() { return 5; }
        static get LockedActiveCellZIndex() { return 5; }
        static get LockedSeparatorZIndex() { return 6; }
        static get LockedEditorZIndex() { return 7; }
        static get TitleRowZIndex() { return 8; }
        static get ScrollbarZIndex() { return 10; }

        static get GroupColName() { return "_group_"; }

        get Spec() { return this.spec; }
        get Id() { return this.spec.gridRunTimeId; }
        get Header() { return this.header; }

        OnDataContextChanged(oldValue, newValue)
        {
            if (oldValue) oldValue.PropertyChanged.Add(this.dataContext_OnPropertyChanged_Handler);
            if (newValue) newValue.PropertyChanged.Add(this.dataContext_OnPropertyChanged_Handler);
            this.panel.DataContext = newValue;
        }

        DataContext_OnPropertyChanged(e)
        {
            switch (e.PropertyName)
            {
                case "spec": this.DataContext_OnSpecChanged(e.NewValue); break;
                case "snapshot": this.DataContext_OnSnapshotChanged(e.NewValue); break;
                case "contextMenu": Core.ContextMenu.Instance.Render(e.NewValue.Items, e.NewValue.PageX, e.NewValue.PageY, this.contextMenuCallback_Handler); break;
                default: break;
            }
        }

        DataContext_OnSpecChanged(spec)
        {
            this.spec = spec;

            this.spec.ColumnBackground = this.spec.GridSettings.ColumnBackground;
            this.spec.SelectedColumnBackground = this.spec.GridSettings.SelectedColumnBackground;
            this.spec.LockedColorHeader = this.spec.GridSettings.LockedColumnBackground; // 9199A4
            this.spec.GroupedColorHeader = this.spec.GridSettings.GroupedColumnBackground;

            this.header.Reset();
            this.panel.Reset();

            this.ResetViewport();

            this.horizontalScrollBar.SetContentLength(1);
            this.horizontalViewport.Count = 0;
            this.horizontalViewport.Offset = 0;

            this.verticalScrollbar.SetContentLength(1);
            this.verticalViewport.Count = 0;
            this.verticalViewport.Offset = 0;

            this.viewportChanged = true;

            this.DataContext.Scroll(this.GetUpdateViewportRequest());
        }

        OnResize(args)
        {
            this.ResetViewport();
            this.DataContext.Scroll(this.GetUpdateViewportRequest());
        }

        OnContextMenu(e)
        {
            e.preventDefault();

            const lgElement = UiUtil.FindParent(e.target, function (element) { return element.dataset[LightGrid.LightGrid.TypeKey]; }, 10);
            let level = LightGrid.GridMenuLevels.Grid;
            if (lgElement)
            {
                const elementType = lgElement.dataset[LightGrid.LightGrid.TypeKey];
                switch (elementType)
                {
                    case LightGrid.LightGrid.TypeCell: level = LightGrid.GridMenuLevels.Cell; break;
                    case LightGrid.LightGrid.TypeCol: level = LightGrid.GridMenuLevels.Column; break;
                    case LightGrid.LightGrid.TypeFilter: level = LightGrid.GridMenuLevels.Filter; break;
                    default: break;
                }
            }

            this.DataContext.GetContextMenu(level, e.pageX, e.pageY);
        }
        ContextMenuCallback(menuItem)
        {
            this.DataContext.ContextMenuCallback(menuItem);
        }

        ResetViewport()
        {
            if (!this.Spec) return;

            let size = Core.UiUtil.CalculateViewportResolution();
            this.Width = size.Width;
            this.Height = size.Height;

            this.panel.Width = this.Width - this.verticalScrollbar.Width;
            this.panel.Height = this.Height - this.header.Height - this.filterPanel.Height - this.toolBar.Height - this.horizontalScrollBar.Height;

            // Set horizontal scrollbar.
            this.horizontalViewport.Size = this.panel.Width;

            // Set vertical scrollbar
            this.verticalViewport.Size = Math.floor(this.panel.Height / this.Spec.RowHeight);

            this.viewportChanged = true;

            this.Spec.CellIconTop = (this.Spec.RowHeight - 16) / 2;
        }

        GetUpdateViewportRequest()
        {
            // console.log(this.verticalViewport);
            return { HorizontalViewport: this.horizontalViewport, VerticalViewport: this.verticalViewport };
        }

        DataContext_OnSnapshotChanged(snapshot)
        {
            // console.log(snapshot);
            if (this.viewportChanged)
            {
                this.viewportChanged = false;
                this.UpdateVerticalViewport(snapshot);
                this.UpdateHorizontalViewport(snapshot);
            }
            else 
            {
                if (this.verticalViewport.Count !== snapshot.VerticalViewport.Count) this.UpdateVerticalViewport(snapshot);
                if (this.horizontalViewport.Count !== snapshot.HorizontalViewport.Count) this.UpdateHorizontalViewport(snapshot);
            }

            if (snapshot.Columns.length > 0)
            {
                // TODO: Padding for grid menu icon
                if (snapshot.Groups.length > 0) snapshot.Groups[0].PaddingLeft = "16";
                else snapshot.Columns[0].PaddingLeft = "16";

                snapshot.Columns[0].IsGroupColumn = snapshot.Columns[0].Key === LightGrid.LightGrid.GroupColName;
            }

            this.header.Render(snapshot);
            this.panel.Render(snapshot);
            //this.DataContext.SendAcknowldegment();
        }
        UpdateVerticalViewport(snapshot)
        {
            this.verticalViewport.Count = snapshot.VerticalViewport.Count;
            this.verticalScrollbar.SetHeight(snapshot.VerticalViewport.Size * this.spec.RowHeight);
            this.verticalScrollbar.SetContentLength(snapshot.VerticalViewport.Count * this.spec.RowHeight);
        }
        UpdateHorizontalViewport(snapshot)
        {
            this.horizontalViewport.Count = snapshot.HorizontalViewport.Count;
            this.horizontalScrollBar.SetWidth(snapshot.HorizontalViewport.Size);
            this.horizontalScrollBar.Style("margin-left", (this.panel.Width - snapshot.HorizontalViewport.Size) + "px");
            this.horizontalScrollBar.SetContentLength(snapshot.HorizontalViewport.Count);
        }

        OnMouseWheel(e)
        {
            if (e.deltaY > 0) this.verticalScrollbar.Element.scrollTop += 20;
            else this.verticalScrollbar.Element.scrollTop -= 20;
        }

        OnScroll_Vertical(e)
        {
            if (Math.abs(e.target.scrollTop - this.scrollTop) < 20) return;

            this.scrollTop = e.target.scrollTop;
            let offset = Math.round(e.target.scrollTop / this.spec.RowHeight);
            this.verticalViewport.Offset = offset;
            this.DataContext.Scroll(this.GetUpdateViewportRequest());
        }

        OnScroll_Horizontal(e)
        {
            if (Math.abs(e.target.scrollLeft - this.scrollLeft) < 20) return;

            this.scrollLeft = e.target.scrollLeft;
            this.horizontalViewport.Offset = this.scrollLeft;
            this.DataContext.Scroll(this.GetUpdateViewportRequest());
        }

        SelectColumn(columnSpec, ctrlKey, shiftKey){ this.DataContext.ToggleColumnSelected(columnSpec, ctrlKey, shiftKey); }

        SelectRow(rowIndex, columnSpec, ctrlKey, shiftKey){ this.DataContext.ToggleRowSelected(rowIndex, columnSpec, ctrlKey, shiftKey); }

        SortColumn(columnSpec, ctrlKey, shiftKey){ this.DataContext.SortColumn(columnSpec, ctrlKey, shiftKey); }

        ResizeColumn(columnSpec){ this.DataContext.ResizeColumn(columnSpec); }

        DropColumnsToTarget(columnSpec, ctrlKey) { this.DataContext.DropColumnsToTarget(columnSpec, ctrlKey); }

        ToggleGroupExpandCollapse(columnSpec) { this.DataContext.ToggleGroupExpandCollapse(columnSpec); }

        ToggleNodeExpandCollapse(nodeId) { this.DataContext.ToggleNodeExpandCollapse(nodeId); }

        Dispose()
        {
            this.layoutGrid.RemoveEvent("contextmenu", this.onContextMenu_Handler);
            this.layoutGrid.RemoveEvent("mousewheel", this.onMouseWheel_Handler);
            this.verticalScrollbar.RemoveEvent("scroll", this.onScroll_Vertical_Handler);
            this.horizontalScrollBar.RemoveEvent("scroll", this.onScroll_Horizontal_Handler);

            super.Dispose();
        }
    }

    Carina.LightGrid.GridMenuLevels = class
    {
        constructor(){}
        static get None() { return 0; }
        static get Cell() { return 1; }
        static get Column() { return 2; }
        static get Row() { return 4; }
        static get Grid() { return 8; }
        static get Filter() { return 16; }
        static get ToolBar() { return 32; }
        static get Default() { return 2 | 4 | 8; }
        static get All() { return 1 | 2 | 4 | 5 | 16; }
    }
}