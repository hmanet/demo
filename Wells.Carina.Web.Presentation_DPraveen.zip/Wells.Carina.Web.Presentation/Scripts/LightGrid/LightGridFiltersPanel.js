﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.LightGrid.LightGridFiltersPanel = class extends Core.BaseControl
    {
        constructor(parent)
        {
            super();

            this.Parent = parent;
            this.grid = parent;
            this.cells = [];

            this.Element = document.createElement("div");
            this.Attribute("name", "LightGridFilterPanel");
            this.AddClass("lightGrid-filtersPanel");

            this.splitter = new Core.DivControl();
            this.splitter.AddClass("lightGrid-splitter");
            this.splitter.Style("background-color", "rgb(128, 128, 128)");
            this.splitter.Style("z-index", Grid.LightGrid.SeparatorZIndex);
            this.AppendChild(this.splitter);

            this.isMouseDown = false;
            this.onMouseDown_Handler = this.OnMouseDown.bind(this);
            this.AddEvent("mousedown", this.onMouseDown_Handler);
            this.onMouseUp_Handler = this.OnMouseUp.bind(this);
            this.AddEvent("mouseup", this.onMouseUp_Handler);
        }

        get IsMouseDown() { return this.isMouseDown; }

        Reset() {
        }

        Render(snapshot) {
            let index = 0;
            for (; index < snapshot.Cells.length; index++) {
                if (index >= this.cells.length) {
                    let cell = new Grid.LightGridFilterCell(this);
                    cell.SetHeight(this.grid.Spec.RowHeight);
                    cell.Style("line-height", this.grid.Spec.RowHeight + "px");
                    this.cells.push(cell);
                    this.AppendChild(cell);
                }

                this.cells[index].Render(snapshot.Cells[index], snapshot.Columns[snapshot.Cells[index].ColumnIndex]);
                this.cells[index].Show();
            }

            for (; index < this.cells.length; index++) {
                this.cells[index].Hide();
            }

            this.splitter.SetWidth(snapshot.LockedViewportSize + 3);
            this.splitter.SetHeight(this.grid.Spec.RowHeight * snapshot.RowCount);
        }

        OnMouseDown(args) {
            this.isMouseDown = true;
        }

        OnMouseUp(args) {
            this.isMouseDown = false;
        }

        Dispose() {
            this.RemoveEvent("mousedown", this.onMouseDown_Handler);
            this.RemoveEvent("mouseup", this.onMouseUp_Handler);
        }
    }
}