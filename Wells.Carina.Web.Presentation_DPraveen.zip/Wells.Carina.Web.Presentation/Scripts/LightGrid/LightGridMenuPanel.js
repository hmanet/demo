﻿"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.LightGrid.LightGridMenuPanel = class extends Core.BaseControl
    {
        constructor(parent)
        {
            super();

            this.Parent = parent;
            this.Element = document.createElement("div");
            this.AddClass("lightGrid-menuPanel");
        }

        Render(){}
    }
}