"use strict";
{
    // Namespace import
    let Core = Carina.Core;

    Carina.Core.BaseViewModel = class
    {
        constructor()
        {
            this.PropertyChanged = new Core.CarinaEvent();
        }

        SetValue(propertyName, value, callback)
        {
            if (this[propertyName] === value) return;

            const oldValue = this[propertyName];
            this[propertyName] = value;
            if (callback) callback(oldValue, value);

            this.RaisePropertyChanged(propertyName, oldValue, value);
        }

        RaisePropertyChanged(propertyName, oldValue, newValue)
        {
            this.PropertyChanged.Invoke(new Core.PropertyChangedEventArgs(propertyName, oldValue, newValue));
        }

        Dispose()
        {
            this.PropertyChanged.Remove();
        }
    }

    Carina.Core.PropertyChangedEventArgs = class
    {
        constructor(propertyName, oldValue, newValue)
        {
            this.propertyName = propertyName;
            this.oldValue = oldValue;
            this.newValue = newValue;
        }

        get PropertyName() { return this.propertyName; }
        get OldValue() { return this.oldValue; }
        get NewValue() { return this.newValue; }
    }
}