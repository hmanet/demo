"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let instance = null;

    Carina.Core.ContextMenu = class extends Carina.Core.BaseControl
    {
        constructor()
        {
            if (!instance)
            {
                super();
                this.menus = null;
                this.preventClosing = false;
                this.menus_OnMouseDown_handler = this.Menus_OnMouseDown.bind(this);
                document.body.addEventListener("mousedown", this.Document_OnMouseDown.bind(this));
                instance = this;
            }

            return instance;
        }

        static get Instance()
        {
            if (!instance) instance = new Core.ContextMenu();
            return instance;
        }

        Render(menuItems, pageX, pageY, callback)
        {
            this.Hide();

            this.callback = callback;
            this.menus = new Carina.Core.MenuItems(document);
            this.menus.Render(menuItems);
            this.menus.Style("left", pageX + "px");
            this.menus.Style("top", pageY + "px");

            this.menus.AddEvent("mousedown", this.menus_OnMouseDown_handler);
            document.body.appendChild(this.menus.Element);
        }

        Hide()
        {
            if (this.menus)
            {
                this.menus.RemoveEvent("mousedown", this.menus_OnMouseDown_handler);
                document.body.removeChild(this.menus.Element);
                this.menus = null;
            }
        }

        Document_OnMouseDown(e)
        {
            if (this.preventClosing === false)
            {
                this.Hide();
            }

            this.preventClosing = false;
        }

        Menus_OnMouseDown(e)
        {
            this.preventClosing = true;
        }
    }

    Carina.Core.MenuItems = class extends Carina.Core.BaseControl
    {
        constructor(parent)
        {
            super();
            this.parent = parent;

            this.Element = document.createElement("ul");
            this.AddClass("context-menu");
            this.items = [];
        }

        Render(menuItems)
        {
            Core.UiUtil.RemoveChildren(this.Element);

            this.menuItems = menuItems;
            this.items = [];

            if (!this.menuItems) return;

            for (let i = 0; i < this.menuItems.length; i++)
            {
                const menuItem = this.menuItems[i];
                const menu = new Core.MenuItem(this);
                menu.Render(menuItem);
                this.AppendChild(menu);
                this.items.push(menu);
            }
        }
    }

    Carina.Core.MenuItem = class extends Carina.Core.BaseControl
    {
        constructor(parent)
        {
            super();
            this.parent = parent;
            
            this.Element = document.createElement("li");
            this.AddClass("context-menu-item");

            this.childContextMenu = null;
            this.menuItem = null;

            this.onClick_Handler = this.OnClick.bind(this);
            this.AddEvent("click", this.onClick_Handler);
        }

        Render(menuItem)
        {
            Core.UiUtil.RemoveChildren(this.Element);

            this.menuItem = menuItem;
            if (this.menuItem.IsSeparator)
            {
                this.AddClass("context-menu-separator");
            }
            else
            {
                if (this.menuItem.Icon)
                {
                    this.icon = new Core.DivControl();
                    this.icon.AddClass("context-menu-icon");
                    this.icon.Style("background", this.menuItem.Icon);
                    this.AppendChild(this.icon);
                }

                if (this.menuItem.Header)
                {
                    this.header = new Core.GenericControl("span");
                    this.header.Element.textContent = this.menuItem.Header;
                    this.AppendChild(this.header);
                }

                if (this.menuItem.Items && this.menuItem.Items.length > 0)
                {
                    this.childContextMenu = new Core.MenuItems(this);
                    this.childContextMenu.Render(this.menuItem.Items);
                    this.AppendChild(this.childContextMenu);
                    this.AddClass("context-menu-submenu");
                    this.childContextMenu.Hide();

                    this.onMouseEnter_Handler = this.OnMouseEnter.bind(this);
                    this.AddEvent("mouseenter", this.onMouseEnter_Handler);

                    this.onMouseLeave_Handler = this.OnMouseLeave.bind(this);
                    this.AddEvent("mouseleave", this.onMouseLeave_Handler);
                }
            }
        }

        OnMouseEnter(e)
        {
            this.childContextMenu.Style("left", this.Width + "px");
            this.childContextMenu.Show();
        }
        OnMouseLeave(e)
        {
            this.childContextMenu.Hide();
        }

        OnClick()
        {
            if (this.childContextMenu) return;

            if (Core.ContextMenu.Instance.callback) Core.ContextMenu.Instance.callback(this.menuItem);
            Core.ContextMenu.Instance.Hide();
        }
    }
}