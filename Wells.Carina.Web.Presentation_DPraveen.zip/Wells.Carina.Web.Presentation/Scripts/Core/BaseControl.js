"use strict";
{
    Carina.Core.BaseControl = class 
    {
        constructor()
        {
            this.dataContext = null;
            this.element = null;
            this.parent = null;
        }

        get DataContext() { return this.dataContext; }
        set DataContext(value)
        {
            let oldValue = this.dataContext;
            this.dataContext = value;
            this.OnDataContextChanged(oldValue, value);
        }
        OnDataContextChanged(oldValue, newValue){}

        get Element() { return this.element; }
        set Element(value) { this.element = value; }

        get Parent() { return this.parent; }
        set Parent(value) { this.parent = value; }

        GetData(key) { return this.element.dataset[key]; }
        SetData(key, value) { this.element.dataset[key] = value; }

        get Height() { return this.element ? this.element.offsetHeight : 0; }
        set Height(value) { this.element.style["height"] = value + "px"; }
        SetHeight(value) { this.element.style["height"] = value + "px"; }

        get Width() { return this.element ? this.element.offsetWidth : 0; }
        set Width(value) { this.element.style["width"] = value + "px"; }
        SetWidth(value) { this.element.style["width"] = value + "px"; }

        Attribute(key, value) { this.element.setAttribute(key, value); }

        Style(key, value) { this.element.style[key] = value; }

        AddClass(className) { this.element.classList.add(className); }
        RemoveClass(className) { this.element.classList.remove(className); }

        AddEvent(evtName, handler) { this.element.addEventListener(evtName, handler); }
        RemoveEvent(evtName, handler) { this.element.removeEventListener(evtName, handler); }

        Show() { this.Style("display", ""); }
        Hide() { this.Style("display", "none"); }

        AppendChild(child)
        {
            if (child instanceof Carina.Core.BaseControl) this.Element.appendChild(child.Element);
            else this.Element.appendChild(child);
        }
        RemoveChild(child)
        {
            if (child === null || child === undefined) return;

            const childElement = child instanceof Carina.Core.BaseControl ? child.Element : child;
            const children = this.element.children;
            for (let i = 0; i < children.length; i++)
            {
                if (childElement !== children[i]) continue;
                
                this.element.removeChild(childElement);
                return;
            }
        }
        InsertChild(child, index)
        {
            const childElement = child instanceof Carina.Core.BaseControl ? child.Element : child;
            if (this.element.childElementCount <= index) this.element.appendChild(childElement);
            else this.element.insertBefore(childElement, this.element.children[index]);
        }
        InsertChildBefore(child, beforeElement)
        {
            const childElement = child instanceof Carina.Core.BaseControl ? child.Element : child;
            this.element.insertBefore(childElement, beforeElement);
        }

        Dispose() {}
    }

    Carina.Core.GenericControl = class extends Carina.Core.BaseControl
    {
        constructor(elementType)
        {
            super();

            this.Element = document.createElement(elementType);
        }
    }

    Carina.Core.DivControl = class extends Carina.Core.BaseControl
    {
        constructor(id)
        {
            super();
            this.Element = document.createElement("div");
            if (id) this.Element.id = id;
        }
    }

    Carina.Core.ImageControl = class extends Carina.Core.BaseControl
    {
        constructor(id,src)
        {
            super();
            this.Element = document.createElement("img");
            if (id) this.Element.id = id;
            if (src) this.Element.src = src;
        }
    }

    Carina.Core.BaseComponent = class extends Carina.Core.BaseControl
    {
        constructor()
        {
            super();
        }
    }

    Carina.Core.ScollbarControl = class extends Carina.Core.BaseControl
    {
        constructor(scrollDirection)
        {
            super();

            //scrollDirection values - "h" : "v";
            this.scrollDirection = scrollDirection;

            this.Element = document.createElement("div");
            this.Style("overflow", "auto");

            this.contentDiv = new Carina.Core.DivControl();
            this.AppendChild(this.contentDiv);

            if (this.scrollDirection === "h") this.contentDiv.SetHeight(1);
            else this.contentDiv.SetWidth(1);
        }

        SetContentLength(length)
        {
            if (this.scrollDirection === "h") this.contentDiv.SetWidth(length);
            else this.contentDiv.SetHeight(length);
        }
    }
}