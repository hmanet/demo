"use strict";
{
    // Namespace import
    let Core = Carina.Core;
    let Model = Carina.Model;

    Carina.ViewModel.GridViewModel = class extends Core.BaseViewModel
    {
        constructor(source)
        {
            super();
            this.spec = null;
            this.snapshot = null;
            this.contextMenu = null;

            this.source = source;
            this.source_OnGridSpecReceived_Handler = this.Source_OnGridSpecReceived.bind(this);
            this.source.GridSpecReceived.Add(this.source_OnGridSpecReceived_Handler);
            this.source_OnContextMenuReceived_Handler = this.Source_OnContextMenuReceived.bind(this);
            this.source.ContextMenuReceived.Add(this.source_OnContextMenuReceived_Handler);

            this.builder = new Model.TreeBuilderModel(source);
            this.builder_OnSnapshotChanged_Handler = this.Builder_OnSnapshotChanged.bind(this);
            this.builder.SnapshotChanged.Add(this.builder_OnSnapshotChanged_Handler);
        }

        Source_OnGridSpecReceived(newSpec){ this.Spec = newSpec; }
        get Spec() { return this.spec; }
        set Spec(value) { this.SetValue("spec", value); }

        Source_OnContextMenuReceived(value) { this.ContextMenu = value; }
        get ContextMenu() { return this.contextMenu; }
        set ContextMenu(value) { this.SetValue("contextMenu", value); }

        Builder_OnSnapshotChanged(value){ this.Snapshot = value; }
        get Snapshot() { return this.snapshot; }
        set Snapshot(value) { this.SetValue("snapshot", value); }

        Scroll(viewport) { this.builder.Scroll(viewport); }

        SendAcknowldegment()
        {
            console.log("Called SendAcknowldegment");
            this.source.SendSnapshotRecievedAcknowledgement();
        }

        ToggleColumnSelected(columnSpec, ctrlKey, shiftKey) { this.builder.ToggleColumnSelected(columnSpec, ctrlKey, shiftKey); }

        ToggleRowSelected(rowIndex, columnSpec, ctrlKey, shiftKey) { this.builder.ToggleRowSelected(rowIndex, columnSpec, ctrlKey, shiftKey); }

        SortColumn(columnSpec, ctrlKey, shiftKey) { this.builder.SortColumn(columnSpec, ctrlKey, shiftKey); }

        ResizeColumn(columnSpec) { this.builder.ResizeColumn(columnSpec); }

        DropColumnsToTarget(columnSpec, ctrlKey) { this.builder.DropColumnsToTarget(columnSpec, ctrlKey); }

        ToggleGroupExpandCollapse(columnSpec) { this.builder.ToggleGroupExpandCollapse(columnSpec); }

        ToggleNodeExpandCollapse(nodeId) { this.builder.ToggleNodeExpandCollapse(nodeId); }

        GetContextMenu(menuLevel, pageX, pageY) { this.builder.GetContextMenu(menuLevel, pageX, pageY); }

        ContextMenuCallback(menuItem) { this.builder.ContextMenuCallback(menuItem); }

        Dispose()
        {
            this.source.GridSpecReceived.Remove(this.source_OnGridSpecReceived_Handler);
            this.builder.SnapshotChanged.Remove(this.builder_OnSnapshotChanged_Handler);
        }
    }
}