"use strict";
{
    // Namespace import
    let Server = Carina.Server;
    let Model = Carina.Model;
    let Vm = Carina.ViewModel;
    let View = Carina.View;

    Carina.App = class
    {
        constructor(serverUrl, runtimeId)
        {
            const connectionQs = { "gridRuntimeId": runtimeId };
            const server = new Server.CarinaServer(serverUrl, "api/LightGridController/", "webLightGridHub", connectionQs);
            const source = new Model.TreeSource(server);

            this.GridComponentViewModel = new Vm.GridComponetViewModel(source);
            this.GridComponent = new View.GridComponent();
            this.GridComponent.DataContext = this.GridComponentViewModel;

            const mainDiv = document.getElementById("MainDiv");
            mainDiv.appendChild(this.GridComponent.Element);
        }

        // Being called by both Carina CefSharp and Web browser to pass the server address to connect to
        // and runtimeId to identify the signalR connection.
        static LoadGrid(url, gridId)
        {
            const urlParams = new URLSearchParams(window.location.search);
            const serverAddress = urlParams.get("serverAddress");
            const runtimeId = urlParams.get("runtimeId");

            if (serverAddress != null && runtimeId != null)
            {
                return new Carina.App(serverAddress, runtimeId);
            }
            else if (!Carina.App.IsBlank(url) && !Carina.App.IsBlank(gridId))
            {
                console.log("From Carina");
                console.log("Url" + url);
                return new Carina.App(url, gridId);
            }

            return null;
        }

        static IsBlank(str)
        {
            return (!str || /^\s*$/.test(str));
        }
    }
}