﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Threading;
using Wells.Carina.Web.API.Models;
using Wells.Carina.Web.API.Models.Requests;
using Wells.Carina.Web.Presentation.ViewModel;
using Wells.Derivatives.Carina.Core.Metadata;
using Wells.Derivatives.Carina.Core.Presentation.Grid;
using Wells.Derivatives.Carina.Core.Presentation.Utilities;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.Grid;
using Wells.Derivatives.Carina.Core.Presentation.ViewModel.OptionSelector;
using Wells.Derivatives.Carina.Core.Utilities;

namespace Wells.Carina.Web.Presentation
{
    public interface IWebGridRequestProcessor
    {
        void Process(WebGridRequest request);
    }

    /// <summary>
    /// Converts the Web Requests to appropriate Light Grid Commnad objects and executes them on the Grid source.
    /// </summary>
    public class WebGridRequestProcessor : IWebGridRequestProcessor
    {
        private readonly WebLightGridViewModel webGrid;
        private readonly GridViewModel grid;

        public WebGridRequestProcessor(WebLightGridViewModel webGrid)
        {
            this.webGrid = webGrid;
            grid = webGrid.Grid;
        }

        public void Process(WebGridRequest request)
        {
            if(request is UpdateViewPortRequest) ExecuteGridCommand((UpdateViewPortRequest)request);
            else if (request is UserActionRequest) ExecuteGridCommand((UserActionRequest)request);
            else if(request is SnapshotAcknowledgement) ExecuteGridCommand((SnapshotAcknowledgement)request);
        }

        private void ExecuteGridCommand(SnapshotAcknowledgement request)
        {
            grid.Dispatcher.BeginInvoke(() =>
            {
                webGrid.GenerateSnapShot();

            }, DispatcherPriority.Background);
        }

        private void ExecuteGridCommand(UpdateViewPortRequest request)
        {
            if(request.VerticalViewport == null && request.HorizontalViewport == null) return;

            grid.Dispatcher.BeginInvoke(() =>
            {
                if (request.VerticalViewport != null)
                {
                    grid.Tree.ViewportOffset = request.VerticalViewport.Offset;
                    grid.Tree.ViewportSize = request.VerticalViewport.Size;
                    grid.Tree.TotalViewportSize = request.VerticalViewport.Size;
                }

                if (request.HorizontalViewport != null)
                {
                    grid.ViewportOffset = request.HorizontalViewport.Offset;
                    grid.TotalViewportSize = request.HorizontalViewport.Size;
                }
            }, DispatcherPriority.Background);
        }

        
        private void ExecuteGridCommand(UserActionRequest request)
        {
            if (request.UserAction == UserActions.None) return;

            Action action = null;
            switch (request.UserAction)
            {
                case UserActions.ToggleColumnSelection:
                    action = () => SelectColumn(GetColumn(request.Column), request.KeyButtonAction);
                    break;

                case UserActions.ToggleRowSelection:
                    action = () =>
                    {
                        var allColumns = new List<ColumnSpec>(grid.LockedColumns);
                        allColumns.AddRange(grid.Columns);

                        var column = allColumns[request.Cell.ColumnIndex];
                        var row = grid.Tree.Nodes[request.Cell.RowIndex];
                        grid.ToggleSelection(row.Model, column,
                            request.KeyButtonAction == KeyboardButton.Ctrl,
                            request.KeyButtonAction == KeyboardButton.Shift,
                            toggleSelection: !GridHelper.CalculateSelected(grid.Spec.SelectionUnit,
                                grid.SelectionTarget, row, column),
                            summarySelection: grid.SummarySelectionType);
                    };
                    break;

                case UserActions.SortColumn:
                    action = () => grid.Spec.ToggleSort(GetColumn(request.Column), request.KeyButtonAction == KeyboardButton.Ctrl, request.KeyButtonAction == KeyboardButton.Shift);
                    break;

                case UserActions.ToggleGroupExpandCollapse:
                    action = () => grid.ToggleGroupExpandCollapse(GetColumn(request.Column));
                    break;

                case UserActions.ToggleNodeExpandCollapse:
                    action = () => grid.ToggleNodeExpandCollapse(request.NodeId.Value);
                    break;

                case UserActions.ResizeColumn:
                    action = () =>
                    {
                        var column = GetColumn(request.Column, true);
                        column.Width = request.Column.Width;
                    };
                    break;

                case UserActions.DropColumns:
                    action = () => grid.InsertColumns(GetColumn(request.Column), false, grid.Spec.SelectedColumns.ToArray(), request.KeyButtonAction == KeyboardButton.Ctrl ? AttributesAddAction.Copy : AttributesAddAction.Move);
                    break;

                case UserActions.GetContextMenu:
                    action = () => webGrid.PushContextMenu(request);
                    break;

                case UserActions.ContextMenuCallback:
                    if (request.MenuId.HasValue == false) return;
                    action = () =>
                    {
                        var menuAction = GetMenuAction(grid.Menu.Items, request.MenuId.Value);
                        if(menuAction != null) menuAction.Command.Execute(menuAction.CommandParameter);
                    };
                    break;
            }

            if(action != null) grid.Dispatcher.BeginInvoke(action, DispatcherPriority.Background);
        }

        private MenuAction GetMenuAction(IList<MenuAction> items, int id)
        {
            foreach (var item in items)
            {
                if (item.Id == id) return item;

                if (item.Items.Count > 0)
                {
                    var result = GetMenuAction(item.Items, id);
                    if (result != null) return result;
                }
            }

            return null;
        }

        private ColumnSpec GetColumn(ColumnInfo column, bool treatGroupColumnsasOne = false)
        {
            if (column.Grouped && grid.Spec.GroupingMode == GridSpec.GroupingModes.Compact)
            {
                return treatGroupColumnsasOne ? grid.GroupColumnViewModel.Spec : grid.GroupColumnViewModel.Groups[column.Index];
            }

            if (column.Index < grid.LockedColumns.Length) return grid.LockedColumns[column.Index];

            var index = column.Index - grid.LockedColumns.Length;
            return index < grid.Columns.Length ? grid.Columns[index] : null;
        }

        private void SelectColumn(ColumnSpec column, KeyboardButton keyButtonAction)
        {
            if (column == grid.Spec.GroupColumn && keyButtonAction == KeyboardButton.Ctrl && grid.Spec.GroupColumn.Selected)
                return;

            grid.ToggleColumnSelected(column, keyButtonAction == KeyboardButton.Ctrl, keyButtonAction == KeyboardButton.Shift);
        }
    }
}
