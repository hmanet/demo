﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text.RegularExpressions;
using Microsoft.Owin.Hosting;

namespace Wells.Carina.Web.Presentation
{
    public class WebServer
    {
        public WebServer(string urlAddress)
        {
            this.urlAddress = urlAddress;
        }

        private static int fromPort;

        private static int toPort;

        private static int globalPort;
        
        private readonly string urlAddress;
        public bool IsLoaded { get; private set; }

        private string serverAddress;

        public string ServerAddress
        {
            get { return serverAddress; }
        }

        private int GetAvailabePort()
        {
            var selectedPort = 0;

            selectedPort = globalPort == 0 ? GetFreePortInRange(fromPort, toPort) : GetFreePortInRange(++globalPort, toPort);

            globalPort = selectedPort;

            return selectedPort;
        }

        public static void ConfigurePortsRange(int portStartIndex, int portEndIndex)
        {
            fromPort = portStartIndex;
            toPort = portEndIndex;
        }

        public void Start()
        {
            if (!IsLoaded)
            {
                var availabePort = GetAvailabePort();
                serverAddress = string.Format(urlAddress, availabePort);
                WebApp.Start<OwinWebBootStrapper>(serverAddress);
                IsLoaded = true;
            }
        }

        public void Stop()
        {
            // Need to find an API to unload the server listening for the address.
        }

        private int GetFreePortInRange(int portStartIndex, int portEndIndex)
        {
            IPGlobalProperties ipGlobalProperties = IPGlobalProperties.GetIPGlobalProperties();

            IPEndPoint[] tcpEndPoints = ipGlobalProperties.GetActiveTcpListeners();
            List<int> usedServerTCpPorts = tcpEndPoints.Select(p => p.Port).ToList();

            IPEndPoint[] udpEndPoints = ipGlobalProperties.GetActiveUdpListeners();
            List<int> usedServerUdpPorts = udpEndPoints.Select(p => p.Port).ToList();

            TcpConnectionInformation[] tcpConnInfoArray = ipGlobalProperties.GetActiveTcpConnections();
            List<int> usedPorts = tcpConnInfoArray.Where(p => p.State != TcpState.Closed).Select(p => p.LocalEndPoint.Port).ToList();

            usedPorts.AddRange(usedServerTCpPorts.ToArray());
            usedPorts.AddRange(usedServerUdpPorts.ToArray());

            int unusedPort = 0;

            for (int port = portStartIndex; port < portEndIndex; port++)
            {
                if (!usedPorts.Contains(port))
                {
                    unusedPort = port;
                    break;
                }
            }

            if (unusedPort == 0)
            {
                throw new ApplicationException("GetFreePortInRange, Out of ports");
            }

            return unusedPort;
        }

        
    }
}